import { resolve } from 'path'
import { fileURLToPath, URL } from 'node:url'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  main: {
    plugins: [externalizeDepsPlugin()]
  },
  preload: {
    plugins: [externalizeDepsPlugin()]
  },
  renderer: {
    resolve: {
      alias: [
        { find: '@renderer', replacement: fileURLToPath(new URL('./src/renderer/src', import.meta.url)) },
        { find: '@', replacement: fileURLToPath(new URL('./src/renderer/src', import.meta.url)) }
      ]
    },
    plugins: [react()]
  }
})
