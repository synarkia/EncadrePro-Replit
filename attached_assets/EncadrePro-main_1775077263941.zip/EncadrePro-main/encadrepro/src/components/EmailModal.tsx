import { useState } from 'react';
import { X, Send, Paperclip } from 'lucide-react';
import { motion } from 'motion/react';

interface EmailModalProps {
  onClose: () => void;
}

export function EmailModal({ onClose }: EmailModalProps) {
  const [to, setTo] = useState('jean.dupont@email.com');
  const [subject, setSubject] = useState('Devis n°DEV-2026-043 — Atelier Lumière');
  const [message, setMessage] = useState(
    'Bonjour Monsieur Dupont,\n\nSuite à notre échange, veuillez trouver ci-joint le devis n°DEV-2026-043 pour l\'encadrement de votre œuvre.\n\nCe devis est valable 30 jours à compter de ce jour.\n\nJe reste à votre entière disposition pour toute question ou précision.\n\nCordialement,\n\nAntoine Lumière\nAtelier Lumière\nArtisan Encadreur'
  );

  return (
    <>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/40 backdrop-blur-md z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="w-full max-w-2xl glass-panel rounded-3xl overflow-hidden shadow-2xl"
          onClick={e => e.stopPropagation()}
        >
          <div className="p-6 border-b border-[var(--panel-border)] flex items-center justify-between bg-[var(--panel-bg-hover)]">
            <h2 className="text-xl font-semibold">Envoyer le devis</h2>
            <button 
              onClick={onClose}
              className="p-2 rounded-full hover:bg-[var(--panel-border)] transition-colors"
            >
              <X size={20} />
            </button>
          </div>
          
          <div className="p-6 space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <label className="w-16 text-sm font-medium text-[var(--text-muted)] text-right">À :</label>
                <input 
                  type="email" 
                  className="glass-input flex-1" 
                  value={to}
                  onChange={e => setTo(e.target.value)}
                />
              </div>
              <div className="flex items-center gap-4">
                <label className="w-16 text-sm font-medium text-[var(--text-muted)] text-right">Objet :</label>
                <input 
                  type="text" 
                  className="glass-input flex-1" 
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                />
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-16 shrink-0" />
              <div className="flex-1 space-y-4">
                <textarea 
                  className="glass-input w-full min-h-[200px] resize-y"
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                />
                
                <div className="flex items-center gap-3 p-3 rounded-xl border border-[var(--panel-border)] bg-[var(--panel-bg-hover)]">
                  <div className="w-10 h-10 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center">
                    <Paperclip size={20} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">Devis_DEV-2026-043.pdf</p>
                    <p className="text-xs text-[var(--text-muted)]">124 KB</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-6 border-t border-[var(--panel-border)] flex items-center justify-end gap-3 bg-[var(--panel-bg-hover)]">
            <button className="btn-glass" onClick={onClose}>
              Annuler
            </button>
            <button className="btn-primary" onClick={onClose}>
              <Send size={18} />
              Envoyer
            </button>
          </div>
        </motion.div>
      </motion.div>
    </>
  );
}
