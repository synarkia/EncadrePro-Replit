import { useState } from 'react';
import { Search, Plus, MoreHorizontal, Filter, CheckCircle2, Clock, AlertCircle, Download, Send } from 'lucide-react';
import { mockInvoices, mockClients } from '../data';
import { Invoice } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { clsx } from 'clsx';

export function Invoices() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'paid' | 'overdue'>('all');

  const filteredInvoices = mockInvoices.filter(invoice => {
    const client = mockClients.find(c => c.id === invoice.clientId);
    const clientName = client ? `${client.firstName} ${client.lastName}`.toLowerCase() : '';
    const matchesSearch = invoice.number.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          clientName.includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || invoice.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: Invoice['status']) => {
    switch (status) {
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-500/10 text-emerald-500 text-xs font-medium border border-emerald-500/20">
            <CheckCircle2 size={14} />
            Payée
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 text-amber-500 text-xs font-medium border border-amber-500/20">
            <Clock size={14} />
            En attente
          </span>
        );
      case 'overdue':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-rose-500/10 text-rose-500 text-xs font-medium border border-rose-500/20">
            <AlertCircle size={14} />
            En retard
          </span>
        );
    }
  };

  return (
    <div className="h-full flex flex-col">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight mb-2">Factures</h1>
          <p className="text-[var(--text-muted)]">Gérez vos factures et suivez vos paiements.</p>
        </div>
        <button className="btn-primary">
          <Plus size={18} />
          Nouvelle facture
        </button>
      </header>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {[
          { id: 'all', label: 'Toutes' },
          { id: 'pending', label: 'En attente' },
          { id: 'paid', label: 'Payées' },
          { id: 'overdue', label: 'En retard' }
        ].map(filter => (
          <button
            key={filter.id}
            onClick={() => setStatusFilter(filter.id as any)}
            className={clsx(
              "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors",
              statusFilter === filter.id
                ? "bg-primary text-white shadow-lg shadow-primary/20"
                : "glass-panel hover:bg-[var(--panel-bg-hover)] text-[var(--text-muted)] hover:text-[var(--text-main)]"
            )}
          >
            {filter.label}
          </button>
        ))}
      </div>

      <div className="glass-panel rounded-2xl flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-[var(--panel-border)] flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={18} />
            <input 
              type="text" 
              placeholder="Rechercher par numéro ou client..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="glass-input w-full pl-10"
            />
          </div>
          <button className="btn-glass px-3">
            <Filter size={18} />
            <span className="sr-only">Filtrer</span>
          </button>
        </div>

        <div className="flex-1 overflow-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[var(--panel-border)] text-sm font-medium text-[var(--text-muted)]">
                <th className="px-6 py-4 font-medium">Numéro</th>
                <th className="px-6 py-4 font-medium">Date</th>
                <th className="px-6 py-4 font-medium">Client</th>
                <th className="px-6 py-4 font-medium text-right">Montant HT</th>
                <th className="px-6 py-4 font-medium text-right">Montant TTC</th>
                <th className="px-6 py-4 font-medium text-center">Statut</th>
                <th className="px-6 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--panel-border)]">
              {filteredInvoices.map(invoice => {
                const client = mockClients.find(c => c.id === invoice.clientId);
                return (
                  <tr 
                    key={invoice.id} 
                    className="hover:bg-[var(--panel-bg-hover)] transition-colors cursor-pointer group"
                    onClick={() => setSelectedInvoice(invoice)}
                  >
                    <td className="px-6 py-4">
                      <span className="font-mono font-medium">{invoice.number}</span>
                    </td>
                    <td className="px-6 py-4 text-sm text-[var(--text-muted)]">
                      {new Date(invoice.date).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium">{client?.firstName} {client?.lastName}</div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-sm text-[var(--text-muted)]">
                      {invoice.subTotalHT.toFixed(2)} €
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-medium">
                      {invoice.totalTTC.toFixed(2)} €
                    </td>
                    <td className="px-6 py-4 text-center">
                      {getStatusBadge(invoice.status)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 rounded-lg hover:bg-[var(--panel-border)] text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors opacity-0 group-hover:opacity-100">
                        <MoreHorizontal size={18} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {selectedInvoice && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
              onClick={() => setSelectedInvoice(null)}
            />
            <motion.div 
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-[500px] glass-panel border-y-0 border-r-0 z-50 flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-[var(--panel-border)] flex items-center justify-between bg-[var(--panel-bg-hover)]">
                <div>
                  <h2 className="text-xl font-semibold flex items-center gap-3">
                    Facture {selectedInvoice.number}
                    {getStatusBadge(selectedInvoice.status)}
                  </h2>
                  <p className="text-sm text-[var(--text-muted)] mt-1">
                    Émise le {new Date(selectedInvoice.date).toLocaleDateString('fr-FR')} • Échéance le {new Date(selectedInvoice.dueDate).toLocaleDateString('fr-FR')}
                  </p>
                </div>
                <button 
                  onClick={() => setSelectedInvoice(null)}
                  className="p-2 rounded-full hover:bg-[var(--panel-border)] transition-colors"
                >
                  <Plus size={20} className="rotate-45" />
                </button>
              </div>
              
              <div className="p-6 flex-1 overflow-y-auto space-y-8">
                {/* Client Info */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-[var(--text-muted)] uppercase tracking-wider">Facturé à</h4>
                  <div className="glass-panel rounded-xl p-4">
                    {(() => {
                      const client = mockClients.find(c => c.id === selectedInvoice.clientId);
                      return client ? (
                        <div className="text-sm space-y-1">
                          <p className="font-medium text-base">{client.firstName} {client.lastName}</p>
                          <p className="text-[var(--text-muted)]">{client.address}</p>
                          <p className="text-[var(--text-muted)]">{client.city}</p>
                          <p className="text-[var(--text-muted)] mt-2">{client.email}</p>
                        </div>
                      ) : null;
                    })()}
                  </div>
                </div>

                {/* Lines */}
                <div className="space-y-3">
                  <h4 className="text-sm font-medium text-[var(--text-muted)] uppercase tracking-wider">Détail</h4>
                  <div className="glass-panel rounded-xl overflow-hidden">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-[var(--panel-bg-hover)] border-b border-[var(--panel-border)]">
                        <tr>
                          <th className="px-4 py-2 font-medium text-[var(--text-muted)]">Description</th>
                          <th className="px-4 py-2 font-medium text-[var(--text-muted)] text-right">Total HT</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[var(--panel-border)]">
                        {selectedInvoice.lines.map(line => (
                          <tr key={line.id}>
                            <td className="px-4 py-3">
                              <p className="font-medium">{line.productName}</p>
                              <p className="text-xs text-[var(--text-muted)] mt-0.5">
                                {line.quantity || line.surface || line.perimeter || line.hours} {line.unit} × {line.priceHT.toFixed(2)} €
                              </p>
                            </td>
                            <td className="px-4 py-3 text-right font-mono">
                              {line.totalHT.toFixed(2)} €
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="p-4 bg-[var(--panel-bg-hover)] border-t border-[var(--panel-border)] space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-[var(--text-muted)]">Sous-total HT</span>
                        <span className="font-mono">{selectedInvoice.subTotalHT.toFixed(2)} €</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-[var(--text-muted)]">TVA (20%)</span>
                        <span className="font-mono">{selectedInvoice.totalVat20.toFixed(2)} €</span>
                      </div>
                      <div className="flex justify-between items-center pt-2 border-t border-[var(--panel-border)] mt-2">
                        <span className="font-semibold">Total TTC</span>
                        <span className="font-mono text-xl font-bold text-primary">{selectedInvoice.totalTTC.toFixed(2)} €</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-[var(--panel-border)] flex gap-3 bg-[var(--panel-bg-hover)]">
                <button className="btn-glass flex-1">
                  <Download size={18} />
                  PDF
                </button>
                <button className="btn-glass flex-1">
                  <Send size={18} />
                  Envoyer
                </button>
                {selectedInvoice.status !== 'paid' && (
                  <button className="btn-primary flex-1">
                    <CheckCircle2 size={18} />
                    Encaisser
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
