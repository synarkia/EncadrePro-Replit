import { FileText, FileSpreadsheet, TrendingUp, HandCoins, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

export function Dashboard() {
  const kpis = [
    { label: 'Devis en attente', value: '12', amount: '4 520 €', icon: FileText, trend: '+2', trendUp: true },
    { label: 'Factures impayées', value: '3', amount: '1 250 €', icon: FileSpreadsheet, trend: '-1', trendUp: false },
    { label: 'CA du mois', value: '8 450 €', amount: '', icon: TrendingUp, trend: '+15%', trendUp: true },
    { label: 'Acomptes reçus', value: '2 100 €', amount: '', icon: HandCoins, trend: '+5%', trendUp: true },
  ];

  const recentActivity = [
    { id: 1, type: 'quote_created', title: 'Devis DEV-2026-042 créé', client: 'Musée des Beaux-Arts', time: 'Il y a 2 heures', amount: '1 250 €' },
    { id: 2, type: 'invoice_sent', title: 'Facture FAC-2026-015 envoyée', client: 'Galerie Lumière', time: 'Il y a 4 heures', amount: '850 €' },
    { id: 3, type: 'payment_received', title: 'Acompte reçu (30%)', client: 'Jean Dupont', time: 'Hier', amount: '150 €' },
    { id: 4, type: 'quote_accepted', title: 'Devis DEV-2026-038 accepté', client: 'Marie Curie', time: 'Hier', amount: '450 €' },
  ];

  const chartData = [
    { name: 'Oct', total: 4200 },
    { name: 'Nov', total: 5100 },
    { name: 'Déc', total: 6800 },
    { name: 'Jan', total: 4800 },
    { name: 'Fév', total: 7200 },
    { name: 'Mar', total: 8450 },
  ];

  return (
    <div className="space-y-8 pb-12">
      <header>
        <h1 className="text-3xl font-semibold tracking-tight mb-2">Bonjour, Antoine</h1>
        <p className="text-[var(--text-muted)]">Voici un résumé de votre activité aujourd'hui.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, i) => (
          <div key={i} className="glass-panel p-6 rounded-2xl flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <kpi.icon size={20} />
              </div>
              <div className={`flex items-center gap-1 text-sm font-medium ${kpi.trendUp ? 'text-emerald-500' : 'text-rose-500'}`}>
                {kpi.trendUp ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                {kpi.trend}
              </div>
            </div>
            <div>
              <p className="text-sm font-medium text-[var(--text-muted)] mb-1">{kpi.label}</p>
              <div className="flex items-baseline gap-2">
                <h2 className="text-2xl font-semibold tracking-tight">{kpi.value}</h2>
                {kpi.amount && <span className="text-sm font-medium text-[var(--text-muted)]">({kpi.amount})</span>}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel p-6 rounded-2xl">
          <h3 className="text-lg font-semibold mb-6">Chiffre d'affaires (6 derniers mois)</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'var(--text-muted)', fontSize: 12 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'var(--text-muted)', fontSize: 12 }}
                  tickFormatter={(value) => `${value}€`}
                />
                <Tooltip 
                  cursor={{ fill: 'var(--panel-bg-hover)' }}
                  contentStyle={{ 
                    backgroundColor: 'var(--panel-bg)', 
                    borderColor: 'var(--panel-border)',
                    borderRadius: '12px',
                    backdropFilter: 'blur(20px)',
                    color: 'var(--text-main)'
                  }}
                  itemStyle={{ color: 'var(--color-primary)' }}
                />
                <Bar dataKey="total" radius={[6, 6, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === chartData.length - 1 ? 'var(--color-primary)' : 'var(--color-primary-hover)'} fillOpacity={index === chartData.length - 1 ? 1 : 0.4} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-panel p-6 rounded-2xl flex flex-col">
          <h3 className="text-lg font-semibold mb-6">Activité récente</h3>
          <div className="flex-1 space-y-6">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex gap-4">
                <div className="w-2 h-2 mt-2 rounded-full bg-secondary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[var(--text-main)] truncate">{activity.title}</p>
                  <p className="text-xs text-[var(--text-muted)] truncate">{activity.client}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-medium font-mono">{activity.amount}</p>
                  <p className="text-xs text-[var(--text-muted)]">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
          <button className="mt-6 w-full py-2 text-sm font-medium text-primary hover:text-primary-hover transition-colors">
            Voir tout l'historique
          </button>
        </div>
      </div>
    </div>
  );
}
