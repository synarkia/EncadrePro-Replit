import { useState } from 'react';
import { Plus, Trash2, Save, FileText, Send, RefreshCw, ChevronDown } from 'lucide-react';
import { mockProducts, mockClients } from '../data';
import { QuoteLine, Product } from '../types';
import { clsx } from 'clsx';
import { EmailModal } from './EmailModal';
import { AnimatePresence } from 'motion/react';

export function Quotes() {
  const [lines, setLines] = useState<QuoteLine[]>([
    { id: '1', productId: '', productName: '', unit: 'unit', priceHT: 0, vatRate: 20, totalHT: 0 }
  ]);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState(mockClients[0].id);

  const handleProductSelect = (lineId: string, productId: string) => {
    const product = mockProducts.find(p => p.id === productId);
    if (!product) return;

    setLines(lines.map(line => 
      line.id === lineId 
        ? { 
            ...line, 
            productId, 
            productName: product.name, 
            unit: product.unit, 
            priceHT: product.priceHT, 
            vatRate: product.vatRate,
            totalHT: 0,
            width: undefined,
            height: undefined,
            perimeter: undefined,
            surface: undefined,
            quantity: undefined,
            hours: undefined
          } 
        : line
    ));
  };

  const calculateLineTotal = (line: QuoteLine) => {
    let total = 0;
    switch (line.unit) {
      case 'ml':
        if (line.width && line.height) {
          const perimeter = 2 * ((line.width / 100) + (line.height / 100));
          total = perimeter * line.priceHT;
        } else if (line.perimeter) {
          total = line.perimeter * line.priceHT;
        }
        break;
      case 'm2':
        if (line.width && line.height) {
          const surface = (line.width / 100) * (line.height / 100);
          total = surface * line.priceHT;
        } else if (line.surface) {
          total = line.surface * line.priceHT;
        }
        break;
      case 'unit':
        if (line.quantity) {
          total = line.quantity * line.priceHT;
        }
        break;
      case 'hour':
        if (line.hours) {
          total = line.hours * line.priceHT;
        }
        break;
    }
    return total;
  };

  const updateLine = (id: string, updates: Partial<QuoteLine>) => {
    setLines(lines.map(line => {
      if (line.id === id) {
        const updatedLine = { ...line, ...updates };
        updatedLine.totalHT = calculateLineTotal(updatedLine);
        return updatedLine;
      }
      return line;
    }));
  };

  const addLine = () => {
    setLines([...lines, { id: Date.now().toString(), productId: '', productName: '', unit: 'unit', priceHT: 0, vatRate: 20, totalHT: 0 }]);
  };

  const removeLine = (id: string) => {
    if (lines.length > 1) {
      setLines(lines.filter(line => line.id !== id));
    }
  };

  const subTotalHT = lines.reduce((sum, line) => sum + line.totalHT, 0);
  const totalVat10 = lines.filter(l => l.vatRate === 10).reduce((sum, line) => sum + (line.totalHT * 0.1), 0);
  const totalVat20 = lines.filter(l => l.vatRate === 20).reduce((sum, line) => sum + (line.totalHT * 0.2), 0);
  const totalTTC = subTotalHT + totalVat10 + totalVat20;

  return (
    <div className="h-full flex flex-col pb-24">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight mb-2">Créer un devis</h1>
          <p className="text-[var(--text-muted)]">Nouveau devis DEV-2026-043</p>
        </div>
      </header>

      <div className="glass-panel rounded-2xl p-6 mb-8 flex flex-col gap-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-[var(--text-muted)]">Client</label>
            <div className="relative">
              <select 
                className="glass-input w-full appearance-none pr-10"
                value={selectedClient}
                onChange={(e) => setSelectedClient(e.target.value)}
              >
                <option value="">Sélectionner un client</option>
                {mockClients.map(c => (
                  <option key={c.id} value={c.id}>{c.firstName} {c.lastName}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" size={16} />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-[var(--text-muted)]">Date de création</label>
            <input type="date" className="glass-input w-full" defaultValue={new Date().toISOString().split('T')[0]} />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-[var(--text-muted)]">Date de validité</label>
            <input type="date" className="glass-input w-full" defaultValue={new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]} />
          </div>
        </div>
      </div>

      <div className="glass-panel rounded-2xl flex-1 flex flex-col overflow-hidden mb-8">
        <div className="p-6 border-b border-[var(--panel-border)] flex items-center justify-between">
          <h2 className="text-lg font-semibold">Lignes du devis</h2>
          <button onClick={addLine} className="btn-glass text-sm">
            <Plus size={16} />
            Ajouter une ligne
          </button>
        </div>
        
        <div className="flex-1 overflow-auto p-6">
          <div className="space-y-4">
            {lines.map((line, index) => (
              <div key={line.id} className="glass-panel rounded-xl p-4 flex flex-col gap-4 relative group">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 space-y-2">
                    <label className="text-xs font-medium text-[var(--text-muted)] uppercase tracking-wider">Produit</label>
                    <div className="relative">
                      <select 
                        className="glass-input w-full appearance-none pr-10"
                        value={line.productId}
                        onChange={(e) => handleProductSelect(line.id, e.target.value)}
                      >
                        <option value="">Sélectionner un produit</option>
                        {mockProducts.map(p => (
                          <option key={p.id} value={p.id}>{p.reference} — {p.name}</option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" size={16} />
                    </div>
                  </div>
                  
                  <div className="w-32 space-y-2">
                    <label className="text-xs font-medium text-[var(--text-muted)] uppercase tracking-wider">Prix U. HT</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        className="glass-input w-full pr-8 font-mono text-right" 
                        value={line.priceHT || ''} 
                        onChange={(e) => updateLine(line.id, { priceHT: parseFloat(e.target.value) || 0 })}
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]">€</span>
                    </div>
                  </div>

                  <div className="w-24 space-y-2">
                    <label className="text-xs font-medium text-[var(--text-muted)] uppercase tracking-wider">TVA</label>
                    <div className="relative">
                      <select 
                        className="glass-input w-full appearance-none pr-8 text-right"
                        value={line.vatRate}
                        onChange={(e) => updateLine(line.id, { vatRate: parseInt(e.target.value) as 10 | 20 })}
                      >
                        <option value={20}>20%</option>
                        <option value={10}>10%</option>
                      </select>
                      <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" size={14} />
                    </div>
                  </div>

                  <div className="w-32 space-y-2">
                    <label className="text-xs font-medium text-[var(--text-muted)] uppercase tracking-wider">Total HT</label>
                    <div className="glass-input w-full bg-[var(--panel-bg-hover)] flex items-center justify-end font-mono font-medium">
                      {line.totalHT.toFixed(2)} €
                    </div>
                  </div>
                </div>

                {line.productId && (
                  <div className="flex items-end gap-4 pt-4 border-t border-[var(--panel-border)]">
                    {(line.unit === 'ml' || line.unit === 'm2') && (
                      <>
                        <div className="w-32 space-y-2">
                          <label className="text-xs font-medium text-[var(--text-muted)]">Largeur (cm)</label>
                          <input 
                            type="number" 
                            className="glass-input w-full" 
                            value={line.width || ''} 
                            onChange={(e) => updateLine(line.id, { width: parseFloat(e.target.value) || 0 })}
                          />
                        </div>
                        <div className="w-32 space-y-2">
                          <label className="text-xs font-medium text-[var(--text-muted)]">Hauteur (cm)</label>
                          <input 
                            type="number" 
                            className="glass-input w-full" 
                            value={line.height || ''} 
                            onChange={(e) => updateLine(line.id, { height: parseFloat(e.target.value) || 0 })}
                          />
                        </div>
                        <div className="flex-1 flex items-center text-sm text-[var(--text-muted)] px-4 pb-2">
                          {line.unit === 'ml' && line.width && line.height && (
                            <span>Périmètre : {(2 * ((line.width / 100) + (line.height / 100))).toFixed(2)} ml</span>
                          )}
                          {line.unit === 'm2' && line.width && line.height && (
                            <span>Surface : {((line.width / 100) * (line.height / 100)).toFixed(3)} m²</span>
                          )}
                        </div>
                      </>
                    )}
                    
                    {line.unit === 'unit' && (
                      <div className="w-32 space-y-2">
                        <label className="text-xs font-medium text-[var(--text-muted)]">Quantité</label>
                        <input 
                          type="number" 
                          className="glass-input w-full" 
                          value={line.quantity || ''} 
                          onChange={(e) => updateLine(line.id, { quantity: parseInt(e.target.value) || 0 })}
                        />
                      </div>
                    )}

                    {line.unit === 'hour' && (
                      <div className="w-32 space-y-2">
                        <label className="text-xs font-medium text-[var(--text-muted)]">Heures</label>
                        <input 
                          type="number" 
                          step="0.5"
                          className="glass-input w-full" 
                          value={line.hours || ''} 
                          onChange={(e) => updateLine(line.id, { hours: parseFloat(e.target.value) || 0 })}
                        />
                      </div>
                    )}
                  </div>
                )}

                <button 
                  onClick={() => removeLine(line.id)}
                  className="absolute -right-3 -top-3 w-8 h-8 rounded-full bg-rose-500/10 text-rose-500 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all hover:bg-rose-500 hover:text-white shadow-lg"
                  disabled={lines.length === 1}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
        
        <div className="p-6 border-t border-[var(--panel-border)] bg-[var(--panel-bg-hover)]">
          <div className="flex justify-end">
            <div className="w-80 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-[var(--text-muted)]">Sous-total HT</span>
                <span className="font-mono">{subTotalHT.toFixed(2)} €</span>
              </div>
              {totalVat10 > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-[var(--text-muted)]">TVA 10%</span>
                  <span className="font-mono">{totalVat10.toFixed(2)} €</span>
                </div>
              )}
              {totalVat20 > 0 && (
                <div className="flex justify-between text-sm">
                  <span className="text-[var(--text-muted)]">TVA 20%</span>
                  <span className="font-mono">{totalVat20.toFixed(2)} €</span>
                </div>
              )}
              <div className="pt-3 border-t border-[var(--panel-border)] flex justify-between items-center">
                <span className="font-semibold text-lg">Total TTC</span>
                <span className="font-mono text-2xl font-bold text-primary">{totalTTC.toFixed(2)} €</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-60 right-0 p-6 glass-panel border-x-0 border-b-0 flex items-center justify-between z-30">
        <div className="flex gap-3">
          <button className="btn-glass">
            <Save size={18} />
            Enregistrer brouillon
          </button>
          <button className="btn-glass">
            <FileText size={18} />
            Aperçu PDF
          </button>
        </div>
        <div className="flex gap-3">
          <button className="btn-primary" onClick={() => setIsEmailModalOpen(true)}>
            <Send size={18} />
            Envoyer par email
          </button>
          <button className="btn-secondary">
            <RefreshCw size={18} />
            Convertir en facture
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isEmailModalOpen && (
          <EmailModal onClose={() => setIsEmailModalOpen(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
