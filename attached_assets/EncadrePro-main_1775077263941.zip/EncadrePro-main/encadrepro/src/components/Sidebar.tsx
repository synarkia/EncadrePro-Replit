import { Frame, LayoutDashboard, Users, FileText, FileSpreadsheet, Package, Settings, Moon, Sun } from 'lucide-react';
import { Page } from '../App';
import { clsx } from 'clsx';

interface SidebarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export function Sidebar({ currentPage, setCurrentPage, isDarkMode, toggleDarkMode }: SidebarProps) {
  const navItems = [
    { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'quotes', label: 'Devis', icon: FileText },
    { id: 'invoices', label: 'Factures', icon: FileSpreadsheet },
    { id: 'catalog', label: 'Catalogue', icon: Package },
    { id: 'settings', label: 'Réglages', icon: Settings },
  ] as const;

  return (
    <div className="w-60 h-full glass-panel border-y-0 border-l-0 flex flex-col z-10">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white shadow-lg shadow-primary/20">
          <Frame size={18} />
        </div>
        <h1 className="font-semibold text-lg tracking-tight">EncadrePro</h1>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              className={clsx(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-300",
                isActive 
                  ? "bg-primary/10 text-primary" 
                  : "text-[var(--text-muted)] hover:bg-[var(--panel-bg-hover)] hover:text-[var(--text-main)]"
              )}
            >
              <Icon size={18} className={isActive ? "text-primary" : ""} />
              {item.label}
            </button>
          );
        })}
      </nav>

      <div className="p-4 mt-auto border-t border-[var(--panel-border)]">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white text-sm font-medium">
            AL
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">Atelier Lumière</p>
            <p className="text-xs text-[var(--text-muted)] truncate">Artisan Encadreur</p>
          </div>
        </div>
        
        <button 
          onClick={toggleDarkMode}
          className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-sm font-medium text-[var(--text-muted)] hover:bg-[var(--panel-bg-hover)] hover:text-[var(--text-main)] transition-colors"
        >
          <span className="flex items-center gap-2">
            {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
            {isDarkMode ? 'Mode Clair' : 'Mode Sombre'}
          </span>
        </button>
      </div>
    </div>
  );
}
