import { useState } from 'react';
import { Search, Plus, MoreHorizontal, Filter } from 'lucide-react';
import { mockProducts } from '../data';
import { Unit } from '../types';
import { clsx } from 'clsx';

export function Catalog() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Toutes');

  const categories = ['Toutes', ...Array.from(new Set(mockProducts.map(p => p.category)))];

  const filteredProducts = mockProducts.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.reference.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'Toutes' || product.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const getUnitLabel = (unit: Unit) => {
    switch (unit) {
      case 'ml': return 'mètre linéaire';
      case 'm2': return 'mètre carré';
      case 'unit': return 'unité';
      case 'hour': return 'heure';
    }
  };

  return (
    <div className="h-full flex flex-col">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight mb-2">Catalogue</h1>
          <p className="text-[var(--text-muted)]">Gérez vos produits et tarifs.</p>
        </div>
        <button className="btn-primary">
          <Plus size={18} />
          Ajouter un produit
        </button>
      </header>

      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={clsx(
              "px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors",
              activeCategory === category
                ? "bg-primary text-white shadow-lg shadow-primary/20"
                : "glass-panel hover:bg-[var(--panel-bg-hover)] text-[var(--text-muted)] hover:text-[var(--text-main)]"
            )}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="glass-panel rounded-2xl flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-[var(--panel-border)] flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={18} />
            <input 
              type="text" 
              placeholder="Rechercher par nom ou référence..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="glass-input w-full pl-10"
            />
          </div>
          <button className="btn-glass px-3">
            <Filter size={18} />
            <span className="sr-only">Filtrer</span>
          </button>
        </div>

        <div className="flex-1 overflow-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[var(--panel-border)] text-sm font-medium text-[var(--text-muted)]">
                <th className="px-6 py-4 font-medium">Référence</th>
                <th className="px-6 py-4 font-medium">Désignation</th>
                <th className="px-6 py-4 font-medium">Unité de calcul</th>
                <th className="px-6 py-4 font-medium text-right">Prix HT</th>
                <th className="px-6 py-4 font-medium text-right">TVA</th>
                <th className="px-6 py-4 font-medium text-right">Prix TTC</th>
                <th className="px-6 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--panel-border)]">
              {filteredProducts.map(product => {
                const priceTTC = product.priceHT * (1 + product.vatRate / 100);
                
                return (
                  <tr key={product.id} className="hover:bg-[var(--panel-bg-hover)] transition-colors group">
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-[var(--panel-border)] text-xs font-mono font-medium">
                        {product.reference}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium">{product.name}</div>
                      <div className="text-xs text-[var(--text-muted)] mt-0.5">{product.category}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-[var(--text-muted)]">
                      Par {getUnitLabel(product.unit)}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-sm">
                      {product.priceHT.toFixed(2)} €
                    </td>
                    <td className="px-6 py-4 text-right text-sm text-[var(--text-muted)]">
                      {product.vatRate}%
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-medium">
                      {priceTTC.toFixed(2)} €
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 rounded-lg hover:bg-[var(--panel-border)] text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors opacity-0 group-hover:opacity-100">
                        <MoreHorizontal size={18} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
