import { useState } from 'react';
import { Search, Plus, MoreHorizontal, Mail, Phone, MapPin, FileText, FileSpreadsheet } from 'lucide-react';
import { mockClients } from '../data';
import { Client } from '../types';
import { motion, AnimatePresence } from 'motion/react';

export function Clients() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  const filteredClients = mockClients.filter(client => 
    `${client.firstName} ${client.lastName}`.toLowerCase().includes(searchQuery.toLowerCase()) ||
    client.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="h-full flex flex-col">
      <header className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-semibold tracking-tight mb-2">Clients</h1>
          <p className="text-[var(--text-muted)]">Gérez votre répertoire client.</p>
        </div>
        <button className="btn-primary">
          <Plus size={18} />
          Nouveau client
        </button>
      </header>

      <div className="glass-panel rounded-2xl flex-1 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-[var(--panel-border)] flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" size={18} />
            <input 
              type="text" 
              placeholder="Rechercher un client..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="glass-input w-full pl-10"
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[var(--panel-border)] text-sm font-medium text-[var(--text-muted)]">
                <th className="px-6 py-4 font-medium">Nom</th>
                <th className="px-6 py-4 font-medium">Contact</th>
                <th className="px-6 py-4 font-medium">Ville</th>
                <th className="px-6 py-4 font-medium text-center">Devis</th>
                <th className="px-6 py-4 font-medium text-right">Dernier contact</th>
                <th className="px-6 py-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--panel-border)]">
              {filteredClients.map(client => (
                <tr 
                  key={client.id} 
                  className="hover:bg-[var(--panel-bg-hover)] transition-colors cursor-pointer group"
                  onClick={() => setSelectedClient(client)}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-medium text-sm">
                        {client.firstName[0]}{client.lastName[0]}
                      </div>
                      <span className="font-medium">{client.firstName} {client.lastName}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm">
                      <div className="flex items-center gap-2 text-[var(--text-main)] mb-1">
                        <Mail size={14} className="text-[var(--text-muted)]" />
                        {client.email}
                      </div>
                      <div className="flex items-center gap-2 text-[var(--text-muted)]">
                        <Phone size={14} />
                        {client.phone}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-[var(--text-muted)]">
                    <div className="flex items-center gap-2">
                      <MapPin size={14} />
                      {client.city}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-[var(--panel-border)] text-xs font-medium">
                      {client.quoteCount}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-[var(--text-muted)] text-right">
                    {new Date(client.lastContact).toLocaleDateString('fr-FR')}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 rounded-lg hover:bg-[var(--panel-border)] text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors opacity-0 group-hover:opacity-100">
                      <MoreHorizontal size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {selectedClient && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
              onClick={() => setSelectedClient(null)}
            />
            <motion.div 
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 h-full w-[400px] glass-panel border-y-0 border-r-0 z-50 flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-[var(--panel-border)] flex items-center justify-between">
                <h2 className="text-xl font-semibold">Fiche Client</h2>
                <button 
                  onClick={() => setSelectedClient(null)}
                  className="p-2 rounded-full hover:bg-[var(--panel-border)] transition-colors"
                >
                  <Plus size={20} className="rotate-45" />
                </button>
              </div>
              
              <div className="p-6 flex-1 overflow-y-auto space-y-8">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-primary to-secondary flex items-center justify-center text-white text-2xl font-medium shadow-lg">
                    {selectedClient.firstName[0]}{selectedClient.lastName[0]}
                  </div>
                  <div>
                    <h3 className="text-2xl font-semibold tracking-tight">{selectedClient.firstName} {selectedClient.lastName}</h3>
                    <p className="text-[var(--text-muted)]">Client depuis 2024</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-[var(--text-muted)] uppercase tracking-wider">Coordonnées</h4>
                  <div className="glass-panel rounded-xl p-4 space-y-3">
                    <div className="flex items-center gap-3 text-sm">
                      <Mail size={16} className="text-[var(--text-muted)]" />
                      <span className="font-medium">{selectedClient.email}</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <Phone size={16} className="text-[var(--text-muted)]" />
                      <span className="font-medium">{selectedClient.phone}</span>
                    </div>
                    <div className="flex items-start gap-3 text-sm">
                      <MapPin size={16} className="text-[var(--text-muted)] mt-0.5" />
                      <span className="font-medium">{selectedClient.address}<br/>{selectedClient.city}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-[var(--text-muted)] uppercase tracking-wider">Historique récent</h4>
                  <div className="glass-panel rounded-xl p-4 space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <FileText size={16} className="text-primary" />
                        <span className="font-medium">Devis DEV-2026-001</span>
                      </div>
                      <span className="text-[var(--text-muted)]">En attente</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <FileSpreadsheet size={16} className="text-emerald-500" />
                        <span className="font-medium">Facture FAC-2025-089</span>
                      </div>
                      <span className="text-[var(--text-muted)]">Payée</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-[var(--panel-border)] flex gap-3">
                <button className="btn-glass flex-1">Modifier</button>
                <button className="btn-primary flex-1">Créer un devis</button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
