import { Client, Product, Quote, Invoice } from './types';

export const mockClients: Client[] = [
  {
    id: 'c1',
    firstName: 'Jean',
    lastName: 'Dupont',
    email: 'jean.dupont@email.com',
    phone: '06 12 34 56 78',
    address: '12 rue de la Paix',
    city: 'Paris',
    quoteCount: 3,
    lastContact: '2026-03-25'
  },
  {
    id: 'c2',
    firstName: 'Marie',
    lastName: 'Curie',
    email: 'marie.curie@email.com',
    phone: '06 98 76 54 32',
    address: '45 avenue des Champs',
    city: 'Lyon',
    quoteCount: 1,
    lastContact: '2026-03-20'
  }
];

export const mockProducts: Product[] = [
  {
    id: 'p1',
    reference: 'BAG-001',
    name: 'Baguette Chêne Massif 4cm',
    unit: 'ml',
    priceHT: 25.00,
    vatRate: 20,
    category: 'Baguettes & Moulures'
  },
  {
    id: 'p2',
    reference: 'VER-001',
    name: 'Verre Musée Anti-reflet 2mm',
    unit: 'm2',
    priceHT: 120.00,
    vatRate: 20,
    category: 'Verres & Vitrages'
  },
  {
    id: 'p3',
    reference: 'PAS-001',
    name: 'Passe-partout Blanc Cassé 1.5mm',
    unit: 'm2',
    priceHT: 45.00,
    vatRate: 20,
    category: 'Passe-partout & Cartons'
  },
  {
    id: 'p4',
    reference: 'ACC-001',
    name: 'Attache Crocodile Laiton',
    unit: 'unit',
    priceHT: 1.50,
    vatRate: 20,
    category: 'Quincaillerie & Accessoires'
  },
  {
    id: 'p5',
    reference: 'MO-001',
    name: 'Montage et Finition',
    unit: 'hour',
    priceHT: 60.00,
    vatRate: 20,
    category: 'Main d\'œuvre'
  }
];

export const mockQuotes: Quote[] = [
  {
    id: 'q1',
    number: 'DEV-2026-001',
    date: '2026-03-28',
    validityDate: '2026-04-27',
    clientId: 'c1',
    lines: [
      {
        id: 'l1',
        productId: 'p1',
        productName: 'Baguette Chêne Massif 4cm',
        unit: 'ml',
        width: 50,
        height: 70,
        perimeter: 2.4,
        priceHT: 25.00,
        vatRate: 20,
        totalHT: 60.00
      },
      {
        id: 'l2',
        productId: 'p2',
        productName: 'Verre Musée Anti-reflet 2mm',
        unit: 'm2',
        width: 50,
        height: 70,
        surface: 0.35,
        priceHT: 120.00,
        vatRate: 20,
        totalHT: 42.00
      }
    ],
    subTotalHT: 102.00,
    totalVat10: 0,
    totalVat20: 20.40,
    totalTTC: 122.40,
    status: 'draft'
  }
];

export const mockInvoices: Invoice[] = [
  {
    id: 'i1',
    number: 'FAC-2026-015',
    date: '2026-03-15',
    dueDate: '2026-04-14',
    clientId: 'c2',
    quoteId: 'q0',
    lines: [
      {
        id: 'l1',
        productId: 'p3',
        productName: 'Passe-partout Blanc Cassé 1.5mm',
        unit: 'm2',
        width: 40,
        height: 50,
        surface: 0.2,
        priceHT: 45.00,
        vatRate: 20,
        totalHT: 9.00
      },
      {
        id: 'l2',
        productId: 'p5',
        productName: 'Montage et Finition',
        unit: 'hour',
        hours: 1.5,
        priceHT: 60.00,
        vatRate: 20,
        totalHT: 90.00
      }
    ],
    subTotalHT: 99.00,
    totalVat10: 0,
    totalVat20: 19.80,
    totalTTC: 118.80,
    status: 'paid'
  },
  {
    id: 'i2',
    number: 'FAC-2026-016',
    date: '2026-02-20',
    dueDate: '2026-03-20',
    clientId: 'c1',
    lines: [
      {
        id: 'l3',
        productId: 'p1',
        productName: 'Baguette Chêne Massif 4cm',
        unit: 'ml',
        perimeter: 3.2,
        priceHT: 25.00,
        vatRate: 20,
        totalHT: 80.00
      }
    ],
    subTotalHT: 80.00,
    totalVat10: 0,
    totalVat20: 16.00,
    totalTTC: 96.00,
    status: 'overdue'
  },
  {
    id: 'i3',
    number: 'FAC-2026-017',
    date: '2026-03-25',
    dueDate: '2026-04-24',
    clientId: 'c1',
    lines: [
      {
        id: 'l4',
        productId: 'p4',
        productName: 'Attache Crocodile Laiton',
        unit: 'unit',
        quantity: 2,
        priceHT: 1.50,
        vatRate: 20,
        totalHT: 3.00
      }
    ],
    subTotalHT: 3.00,
    totalVat10: 0,
    totalVat20: 0.60,
    totalTTC: 3.60,
    status: 'pending'
  }
];
