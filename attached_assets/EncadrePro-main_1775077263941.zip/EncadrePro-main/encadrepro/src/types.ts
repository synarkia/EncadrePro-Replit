export type Unit = 'ml' | 'm2' | 'unit' | 'hour';
export type VatRate = 10 | 20;

export interface Product {
  id: string;
  reference: string;
  name: string;
  unit: Unit;
  priceHT: number;
  vatRate: VatRate;
  category: string;
  notes?: string;
}

export interface Client {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  notes?: string;
  quoteCount: number;
  lastContact: string;
}

export interface QuoteLine {
  id: string;
  productId: string;
  productName: string;
  unit: Unit;
  // Dimensions
  width?: number; // in cm
  height?: number; // in cm
  perimeter?: number; // in m
  surface?: number; // in m2
  quantity?: number;
  hours?: number;
  
  priceHT: number;
  vatRate: VatRate;
  totalHT: number;
}

export interface Quote {
  id: string;
  number: string;
  date: string;
  validityDate: string;
  clientId: string;
  lines: QuoteLine[];
  subTotalHT: number;
  totalVat10: number;
  totalVat20: number;
  totalTTC: number;
  notes?: string;
  status: 'draft' | 'sent' | 'accepted' | 'invoiced';
}

export interface Invoice {
  id: string;
  number: string;
  date: string;
  dueDate: string;
  clientId: string;
  quoteId?: string;
  lines: QuoteLine[];
  subTotalHT: number;
  totalVat10: number;
  totalVat20: number;
  totalTTC: number;
  notes?: string;
  status: 'pending' | 'paid' | 'overdue';
}
