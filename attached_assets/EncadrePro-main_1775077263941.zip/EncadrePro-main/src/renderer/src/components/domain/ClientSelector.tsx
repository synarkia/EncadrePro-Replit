import React, { useState, useEffect } from 'react'
import { Modal } from '../ui/Modal'
import { DataTable } from '../ui/DataTable'
import { useClientsStore, Client } from '../../store/useClientsStore'
import { Button } from '../ui/Button'

interface ClientSelectorProps {
  isOpen: boolean
  onClose: () => void
  onSelect: (clientId: number) => void
}

export const ClientSelector: React.FC<ClientSelectorProps> = ({ isOpen, onClose, onSelect }) => {
  const { clients, fetchClients } = useClientsStore()
  const [search, setSearch] = useState('')

  useEffect(() => {
    if (isOpen) {
      fetchClients()
      setSearch('')
    }
  }, [isOpen, fetchClients])

  const filtered = clients.filter(c => 
    c.nom.toLowerCase().includes(search.toLowerCase()) || 
    (c.prenom && c.prenom.toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Sélectionner un client" width="lg">
      <div className="flex flex-col gap-4">
        <DataTable
          data={filtered}
          searchPlaceholder="Rechercher un client..."
          searchValue={search}
          onSearchChange={setSearch}
          onRowClick={(c) => onSelect(c.id)}
          columns={[
            { key: 'nom', label: 'Nom', render: c => <span className="font-semibold">{c.nom}</span> },
            { key: 'prenom', label: 'Prénom' },
            { key: 'ville', label: 'Ville' },
            { 
              key: 'actions', 
              label: '', 
              align: 'right',
              render: (c) => <Button size="sm" variant="secondary" onClick={() => onSelect(c.id)}>Choisir</Button> 
            }
          ]}
        />
      </div>
    </Modal>
  )
}
