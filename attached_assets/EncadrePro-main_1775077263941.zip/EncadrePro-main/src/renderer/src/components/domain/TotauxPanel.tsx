import React from 'react'

interface TotauxPanelProps {
  sous_total_ht: number
  total_tva_10: number
  total_tva_20: number
  total_ttc: number
}

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

export const TotauxPanel: React.FC<TotauxPanelProps> = ({ sous_total_ht, total_tva_10, total_tva_20, total_ttc }) => {
  return (
    <div className="flex flex-col gap-2 p-5 bg-glass-hover/50 rounded-lg border border-glass-border">
      <div className="flex justify-between items-center text-sm">
        <span className="text-text-muted">Sous-total HT</span>
        <span className="font-mono text-text-primary">{formatCurrency(sous_total_ht)}</span>
      </div>
      {(total_tva_20 > 0 || total_tva_10 === 0) && (
        <div className="flex justify-between items-center text-sm">
          <span className="text-text-muted">TVA (20%)</span>
          <span className="font-mono text-text-primary">{formatCurrency(total_tva_20)}</span>
        </div>
      )}
      {total_tva_10 > 0 && (
        <div className="flex justify-between items-center text-sm">
          <span className="text-text-muted">TVA (10%)</span>
          <span className="font-mono text-text-primary">{formatCurrency(total_tva_10)}</span>
        </div>
      )}
      <div className="divider my-1" />
      <div className="flex justify-between items-center text-base font-bold">
        <span className="text-text-primary">Total TTC</span>
        <span className="font-mono text-accent-primary text-xl tracking-tight">{formatCurrency(total_ttc)}</span>
      </div>
    </div>
  )
}
