import React from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { useProduitsStore, Produit } from '../../store/useProduitsStore'
import { LigneDevis } from '../../store/useDevisStore'
import { Button } from '../ui/Button'
import { Input, Select } from '../ui/Input'

interface LigneDevisEditorProps {
  lignes: LigneDevis[]
  onChange: (lignes: LigneDevis[]) => void
  disabled?: boolean
}

export const LigneDevisEditor: React.FC<LigneDevisEditorProps> = ({ lignes, onChange, disabled }) => {
  const { produits } = useProduitsStore()
  const actifs = produits.filter(p => p.actif)

  const handleAddLine = () => {
    onChange([...lignes, {
      produit_id: null,
      designation: '',
      unite_calcul: 'unitaire',
      largeur_m: null,
      hauteur_m: null,
      quantite: 1,
      prix_unitaire_ht: 0,
      taux_tva: 20
    }])
  }

  const handleUpdate = (index: number, updates: Partial<LigneDevis>) => {
    const updated = [...lignes]
    updated[index] = { ...updated[index], ...updates }

    // Auto-calculate quantite_calculee based on unite_calcul
    const l = updated[index]
    const larg = l.largeur_m || 0
    const haut = l.hauteur_m || 0
    let qcalc = Number(l.quantite) || 1

    if (l.unite_calcul === 'metre_lineaire') {
      qcalc = (larg + haut) * 2 * (Number(l.quantite) || 1)
    } else if (l.unite_calcul === 'metre_carre') {
      qcalc = (larg * haut) * (Number(l.quantite) || 1)
    }
    
    // round to 3 decimals max
    l.quantite_calculee = Math.round(qcalc * 1000) / 1000

    onChange(updated)
  }

  const handleProductSelect = (index: number, pid: string) => {
    if (!pid) return
    const sel = actifs.find(p => p.id === parseInt(pid))
    if (!sel) return

    handleUpdate(index, {
      produit_id: sel.id,
      designation: sel.designation,
      unite_calcul: sel.unite_calcul,
      prix_unitaire_ht: sel.prix_ht,
      taux_tva: sel.taux_tva
    })
  }

  const handleRemove = (index: number) => {
    onChange(lignes.filter((_, i) => i !== index))
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="overflow-x-auto rounded-lg border border-glass-border bg-glass-bg">
        <table className="w-full text-sm data-table">
          <thead>
            <tr>
              <th className="w-1/4">Prestation / Produit</th>
              <th className="w-[12%] text-center">Larg. (m)</th>
              <th className="w-[12%] text-center">Haut. (m)</th>
              <th className="w-[10%] text-center">Qté base</th>
              <th className="w-[12%] text-center">Unité calc.</th>
              <th className="w-[10%] text-center">Qté finale</th>
              <th className="w-[12%] text-right">PU HT (€)</th>
              <th className="w-[10%] text-right">TVA (%)</th>
              {!disabled && <th className="w-12"></th>}
            </tr>
          </thead>
          <tbody>
            {lignes.length === 0 && (
              <tr>
                <td colSpan={9} className="py-8 text-center text-text-muted">
                  Aucune ligne. Sélectionnez un produit pour commencer.
                </td>
              </tr>
            )}
            {lignes.map((l, i) => (
              <tr key={i} className="hover:bg-transparent">
                <td className="p-2">
                  {disabled ? (
                    <span className="font-medium">{l.designation}</span>
                  ) : (
                    <div className="flex flex-col gap-1">
                      <Select 
                        className="py-1 px-2 text-xs" 
                        value={l.produit_id || ''} 
                        onChange={e => handleProductSelect(i, e.target.value)}
                      >
                        <option value="">-- Choisir --</option>
                        {actifs.map(p => <option key={p.id} value={p.id}>{p.designation}</option>)}
                      </Select>
                      <Input
                        className="py-1 px-2 text-xs"
                        value={l.designation}
                        onChange={e => handleUpdate(i, { designation: e.target.value })}
                        placeholder="Description libre..."
                      />
                    </div>
                  )}
                </td>
                
                <td className="p-2">
                  <Input 
                    type="number" step="0.001" min="0" 
                    className="py-1 px-2 text-xs text-center" 
                    disabled={disabled || l.unite_calcul === 'unitaire' || l.unite_calcul === 'heure'}
                    value={l.largeur_m === null ? '' : l.largeur_m}
                    onChange={e => handleUpdate(i, { largeur_m: e.target.value ? parseFloat(e.target.value) : null })}
                  />
                </td>
                
                <td className="p-2">
                  <Input 
                    type="number" step="0.001" min="0" 
                    className="py-1 px-2 text-xs text-center" 
                    disabled={disabled || l.unite_calcul === 'unitaire' || l.unite_calcul === 'heure'}
                    value={l.hauteur_m === null ? '' : l.hauteur_m}
                    onChange={e => handleUpdate(i, { hauteur_m: e.target.value ? parseFloat(e.target.value) : null })}
                  />
                </td>

                <td className="p-2">
                  <Input 
                    type="number" min="1" 
                    className="py-1 px-2 text-xs text-center" 
                    disabled={disabled}
                    value={l.quantite}
                    onChange={e => handleUpdate(i, { quantite: parseInt(e.target.value) || 1 })}
                  />
                </td>

                <td className="p-2">
                  <Select 
                    className="py-1 px-2 text-xs" 
                    disabled={disabled}
                    value={l.unite_calcul}
                    onChange={e => handleUpdate(i, { unite_calcul: e.target.value })}
                  >
                    <option value="metre_lineaire">ml (Périm.)</option>
                    <option value="metre_carre">m² (Surf.)</option>
                    <option value="unitaire">Unité</option>
                    <option value="heure">Heure</option>
                  </Select>
                </td>

                <td className="p-2 text-center font-mono text-xs font-semibold text-accent-primary">
                  {l.quantite_calculee || '-'}
                </td>

                <td className="p-2">
                  <Input 
                    type="number" step="0.01" min="0" 
                    className="py-1 px-2 text-xs text-right font-mono" 
                    disabled={disabled}
                    value={l.prix_unitaire_ht}
                    onChange={e => handleUpdate(i, { prix_unitaire_ht: parseFloat(e.target.value) || 0 })}
                  />
                </td>

                <td className="p-2">
                  <Select 
                    className="py-1 px-2 text-xs" 
                    disabled={disabled}
                    value={l.taux_tva.toString()}
                    onChange={e => handleUpdate(i, { taux_tva: parseFloat(e.target.value) || 0 })}
                  >
                    <option value="20">20%</option>
                    <option value="10">10%</option>
                    <option value="5.5">5.5%</option>
                    <option value="0">0%</option>
                  </Select>
                </td>

                {!disabled && (
                  <td className="p-2 text-right">
                    <Button variant="ghost" size="icon" className="text-danger hover:bg-danger/10" onClick={() => handleRemove(i)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {!disabled && (
        <div>
          <Button variant="secondary" size="sm" onClick={handleAddLine}>
            <Plus className="w-4 h-4 mr-2" /> Ajouter une ligne
          </Button>
        </div>
      )}
    </div>
  )
}
