import React, { useEffect } from 'react'
import { Sidebar } from './Sidebar'
import { TitleBar } from './TitleBar'
import { useUIStore } from '../../store/useUIStore'
import { AnimatePresence, motion } from 'framer-motion'

// Placeholder Pages (will be replaced by actual components)
const Dashboard = React.lazy(() => import('../../pages/Dashboard').catch(() => ({ default: () => <div>Dashboard Comming Soon</div> })))
const Clients = React.lazy(() => import('../../pages/Clients').catch(() => ({ default: () => <div>Clients Comming Soon</div> })))
const Catalogue = React.lazy(() => import('../../pages/Catalogue').catch(() => ({ default: () => <div>Catalogue Comming Soon</div> })))
const Devis = React.lazy(() => import('../../pages/Devis').catch(() => ({ default: () => <div>Devis Comming Soon</div> })))
const Factures = React.lazy(() => import('../../pages/Factures').catch(() => ({ default: () => <div>Factures Comming Soon</div> })))
const Parametres = React.lazy(() => import('../../pages/Parametres').catch(() => ({ default: () => <div>Parametres Comming Soon</div> })))

const ToastContainer = () => {
  const { toasts, removeToast } = useUIStore()
  if (toasts.length === 0) return null

  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.id} className={`toast toast-${t.type}`} onClick={() => removeToast(t.id)}>
          {t.type === 'success' && <div className="w-2 h-2 rounded-full bg-success" />}
          {t.type === 'error' && <div className="w-2 h-2 rounded-full bg-danger" />}
          {t.type === 'info' && <div className="w-2 h-2 rounded-full bg-accent-primary" />}
          <span>{t.message}</span>
        </div>
      ))}
    </div>
  )
}

export const AppShell: React.FC = () => {
  const { activePage } = useUIStore()

  const renderPage = () => {
    switch (activePage) {
      case 'dashboard': return <Dashboard />
      case 'clients': return <Clients />
      case 'catalogue': return <Catalogue />
      case 'devis': return <Devis />
      case 'factures': return <Factures />
      case 'parametres': return <Parametres />
      default: return <Dashboard />
    }
  }

  return (
    <div className="h-screen w-full flex bg-bg-primary text-text-primary overflow-hidden">
      <Sidebar />
      <div className="flex-1 flex flex-col h-full relative z-0">
        <TitleBar />
        <main className="flex-1 overflow-y-auto px-8 py-6 titlebar-no-drag">
          <React.Suspense fallback={<div className="animate-pulse w-32 h-8 bg-glass-hover rounded-md" />}>
            <AnimatePresence mode="wait">
              <motion.div
                key={activePage}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.2 }}
                className="h-full"
              >
                {renderPage()}
              </motion.div>
            </AnimatePresence>
          </React.Suspense>
        </main>
      </div>
      <ToastContainer />
    </div>
  )
}
