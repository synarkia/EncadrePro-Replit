import React from 'react'
import { LayoutDashboard, FileText, Receipt, Users, Package, Settings, Moon, Sun } from 'lucide-react'
import { useUIStore } from '../../store/useUIStore'

const navItems = [
  { id: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { id: 'devis', label: 'Devis', icon: FileText },
  { id: 'factures', label: 'Factures', icon: Receipt },
  { id: 'clients', label: 'Clients', icon: Users },
  { id: 'catalogue', label: 'Catalogue', icon: Package },
  { id: 'parametres', label: 'Paramètres', icon: Settings },
]

export const Sidebar: React.FC = () => {
  const { activePage, setActivePage, theme, toggleTheme } = useUIStore()

  return (
    <div className="sidebar pt-6 pb-4 flex flex-col justify-between">
      <div className="flex-1 overflow-y-auto">
        <div className="px-5 mb-8 flex items-center gap-3 titlebar-no-drag">
          <div className="w-8 h-8 rounded-lg bg-accent-primary flex items-center justify-center shadow-glass">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="18" height="18" rx="4" />
              <path d="m9 9 6 6" />
              <path d="m15 9-6 6" />
            </svg>
          </div>
          <span className="text-15px font-bold tracking-tight text-text-primary">EncadrePro</span>
        </div>

        <nav className="flex flex-col gap-1 px-2 titlebar-no-drag">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id)}
              className={`sidebar-nav-item ${activePage === item.id ? 'active' : ''}`}
            >
              <item.icon className="nav-icon w-4 h-4 mr-2" />
              {item.label}
            </button>
          ))}
        </nav>
      </div>

      <div className="px-4 mt-auto titlebar-no-drag">
        <button
          onClick={toggleTheme}
          className="w-full flex items-center gap-3 px-3 py-2 text-sm font-medium text-text-secondary rounded-md hover:bg-glass-hover transition-colors"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          <span>{theme === 'dark' ? 'Mode Clair' : 'Mode Sombre'}</span>
        </button>
      </div>
    </div>
  )
}
