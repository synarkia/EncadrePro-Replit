import React from 'react'

export const TitleBar: React.FC = () => {
  return (
    <div className="titlebar">
      <div className="titlebar-traffic-lights-spacer" />
      <div className="flex-1 flex items-center justify-center">
        <span className="text-[13px] font-semibold text-text-muted titlebar-no-drag select-none cursor-default">
          EncadrePro
        </span>
      </div>
      <div className="w-[72px]" /> {/* Symétrie pour centrer le titre */}
    </div>
  )
}
