import React from 'react'
import { Search } from 'lucide-react'
import { cn } from '../../utils/cn'

interface Column<T> {
  key: Extract<keyof T, string> | 'actions'
  label: string
  render?: (item: T) => React.ReactNode
  align?: 'left' | 'center' | 'right'
}

interface DataTableProps<T> {
  data: T[]
  columns: Column<T>[]
  onRowClick?: (item: T) => void
  searchPlaceholder?: string
  searchValue?: string
  onSearchChange?: (val: string) => void
  emptyMessage?: string
}

export function DataTable<T extends { id: number | string }>({
  data,
  columns,
  onRowClick,
  searchPlaceholder,
  searchValue,
  onSearchChange,
  emptyMessage = 'Aucune donnée disponible.'
}: DataTableProps<T>) {
  return (
    <div className="flex flex-col gap-4">
      {searchPlaceholder && onSearchChange && (
        <div className="search-bar max-w-md">
          <Search className="w-4 h-4 text-text-muted" />
          <input
            type="text"
            placeholder={searchPlaceholder}
            value={searchValue || ''}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      )}

      <div className="overflow-x-auto rounded-lg border border-glass-border bg-glass-bg backdrop-blur-3xl shadow-glass">
        <table className="data-table w-full">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key as string} className={cn(col.align === 'right' && 'text-right', col.align === 'center' && 'text-center')}>
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.length === 0 ? (
              <tr>
                <td colSpan={columns.length} className="text-center py-8 text-text-muted">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              data.map(item => (
                <tr key={item.id} onClick={() => onRowClick && onRowClick(item)} className={cn(onRowClick && 'cursor-pointer hover:bg-glass-hover')}>
                  {columns.map(col => (
                    <td key={col.key as string} className={cn(col.align === 'right' && 'text-right', col.align === 'center' && 'text-center')}>
                      {col.render ? col.render(item) : (item as any)[col.key]}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
