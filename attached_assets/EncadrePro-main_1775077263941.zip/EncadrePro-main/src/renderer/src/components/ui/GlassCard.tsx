import React from 'react'
import { cn } from '../../utils/cn'

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  variant?: 'default' | 'small' | 'solid'
}

export const GlassCard = React.forwardRef<HTMLDivElement, GlassCardProps>(
  ({ className, children, variant = 'default', ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          variant === 'default' && 'glass-panel p-6',
          variant === 'small' && 'glass-panel-sm p-4',
          variant === 'solid' && 'bg-bg-secondary rounded-lg border border-glass-border p-5',
          className
        )}
        {...props}
      >
        {children}
      </div>
    )
  }
)
GlassCard.displayName = 'GlassCard'
