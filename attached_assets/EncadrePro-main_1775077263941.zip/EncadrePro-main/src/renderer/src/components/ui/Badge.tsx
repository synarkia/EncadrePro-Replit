import React from 'react'
import { cn } from '../../utils/cn'

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: 
    | 'brouillon' 
    | 'envoye' 
    | 'envoyee' 
    | 'accepte' 
    | 'refuse' 
    | 'converti' 
    | 'partiellement_payee' 
    | 'soldee'
    | 'default'
  children: React.ReactNode
}

export const Badge: React.FC<BadgeProps> = ({ variant = 'default', className, children, ...props }) => {
  return (
    <span 
      className={cn('badge', variant !== 'default' && `badge-${variant}`, className)}
      {...props}
    >
      {children}
    </span>
  )
}
