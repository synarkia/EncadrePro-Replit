import React from 'react'
import { cn } from '../../utils/cn'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="form-group">
        {label && <label className="label">{label}</label>}
        <input
          ref={ref}
          className={cn('input', error && 'border-danger focus:ring-danger', className)}
          {...props}
        />
        {error && <span className="text-danger text-xs mt-1">{error}</span>}
      </div>
    )
  }
)
Input.displayName = 'Input'

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string, error?: string }>(
  ({ className, label, error, ...props }, ref) => {
    return (
      <div className="form-group">
        {label && <label className="label">{label}</label>}
        <textarea
          ref={ref}
          className={cn('input', error && 'border-danger focus:ring-danger', className)}
          {...props}
        />
        {error && <span className="text-danger text-xs mt-1">{error}</span>}
      </div>
    )
  }
)
Textarea.displayName = 'Textarea'

export const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string, error?: string }>(
  ({ className, label, error, children, ...props }, ref) => {
    return (
      <div className="form-group">
        {label && <label className="label">{label}</label>}
        <select
          ref={ref}
          className={cn('select', error && 'border-danger focus:ring-danger', className)}
          {...props}
        >
          {children}
        </select>
        {error && <span className="text-danger text-xs mt-1">{error}</span>}
      </div>
    )
  }
)
Select.displayName = 'Select'
