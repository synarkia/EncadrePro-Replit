import React, { useEffect, useState } from 'react'
import { Trash2 } from 'lucide-react'
import { useFacturesStore, Facture } from '../store/useFacturesStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { DataTable } from '../components/ui/DataTable'
import { Badge } from '../components/ui/Badge'
import { Select } from '../components/ui/Input'
import FactureDetail from './FactureDetail'

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

const Factures: React.FC = () => {
  const { factures, fetchFactures, deleteFacture } = useFacturesStore()
  const { addToast } = useUIStore()

  const [filterStatut, setFilterStatut] = useState<string>('tout')
  const [selectedFacId, setSelectedFacId] = useState<number | null>(null)

  useEffect(() => {
    fetchFactures(filterStatut !== 'tout' ? { statut: filterStatut } : undefined)
  }, [filterStatut, fetchFactures])

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation()
    if (window.confirm("Supprimer cette facture ?")) {
      try {
        await deleteFacture(id)
        if (selectedFacId === id) setSelectedFacId(null)
        addToast({ type: 'info', message: 'Facture supprimée' })
      } catch {
        addToast({ type: 'error', message: 'Erreur de suppression' })
      }
    }
  }

  if (selectedFacId) {
    return <FactureDetail facId={selectedFacId} onBack={() => {
      setSelectedFacId(null)
      fetchFactures(filterStatut !== 'tout' ? { statut: filterStatut } : undefined)
    }} />
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="section-header">
        <div>
          <h1 className="section-title">Factures</h1>
          <p className="section-subtitle">Suivi des paiements et relances</p>
        </div>
      </div>

      <div className="flex items-center gap-4 py-2">
        <Select value={filterStatut} onChange={(e) => setFilterStatut(e.target.value)} className="w-[200px] mb-0 border-glass-border">
          <option value="tout">Tous les statuts</option>
          <option value="brouillon">Brouillon</option>
          <option value="envoyee">Envoyée</option>
          <option value="partiellement_payee">Partiellement payée</option>
          <option value="soldee">Soldée</option>
        </Select>
      </div>

      <DataTable
        data={factures}
        onRowClick={(f) => setSelectedFacId(f.id)}
        emptyMessage="Aucune facture trouvée."
        columns={[
          { key: 'numero', label: 'Numéro', render: f => <span className="font-mono text-sm">{f.numero}</span> },
          { key: 'client_nom', label: 'Client', render: f => <span className="font-semibold">{f.client_prenom} {f.client_nom}</span> },
          { key: 'date_creation', label: 'Date', render: f => new Date(f.date_creation).toLocaleDateString('fr-FR') },
          { key: 'date_echeance', label: 'Échéance', render: f => new Date(f.date_echeance).toLocaleDateString('fr-FR') },
          { key: 'statut', label: 'Statut', render: f => <Badge variant={f.statut}>{f.statut.replace('_', ' ')}</Badge> },
          { key: 'total_restant', label: 'Reste à payer', align: 'right', render: f => 
              <span className={`font-semibold ${f.total_restant > 0 ? 'text-danger' : 'text-success'}`}>
                {formatCurrency(f.total_restant)}
              </span> 
          },
          { 
            key: 'actions', 
            label: '', 
            align: 'right',
            render: (f) => (
              <div className="flex justify-end gap-2" onClick={e => e.stopPropagation()}>
                <Button variant="ghost" size="icon" className="text-danger hover:text-danger hover:bg-danger/10" onClick={(e) => handleDelete(f.id, e)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )
          }
        ]}
      />
    </div>
  )
}

export default Factures
