import React, { useEffect, useState } from 'react'
import { Plus, Edit, Trash2, Power, PowerOff } from 'lucide-react'
import { useProduitsStore, Produit } from '../store/useProduitsStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { Input, Select, Textarea } from '../components/ui/Input'
import { Modal } from '../components/ui/Modal'
import { DataTable } from '../components/ui/DataTable'
import { Badge } from '../components/ui/Badge'

const CATEGORIES = [
  { id: 'baguettes', label: 'Baguettes' },
  { id: 'verres', label: 'Verres' },
  { id: 'passe_partout', label: 'Passe-partout' },
  { id: 'quincaillerie', label: 'Quincaillerie' },
  { id: 'main_oeuvre', label: 'Main d\'œuvre' }
]

const UNITES = [
  { id: 'metre_lineaire', label: 'Mètre linéaire (ml)' },
  { id: 'metre_carre', label: 'Mètre carré (m²)' },
  { id: 'unitaire', label: 'Unité (pièce)' },
  { id: 'heure', label: 'Heure (h)' }
]

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

const Catalogue: React.FC = () => {
  const { produits, fetchProduits, createProduit, updateProduit, deleteProduit, toggleActif } = useProduitsStore()
  const { addToast } = useUIStore()

  const [activeCategory, setActiveCategory] = useState<string>('tout')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingProd, setEditingProd] = useState<Produit | null>(null)

  // Form state
  const [reference, setReference] = useState('')
  const [designation, setDesignation] = useState('')
  const [categorie, setCategorie] = useState('baguettes')
  const [unite, setUnite] = useState('metre_lineaire')
  const [prixHt, setPrixHt] = useState('0')
  const [tva, setTva] = useState('20')
  const [notes, setNotes] = useState('')

  useEffect(() => {
    fetchProduits(activeCategory !== 'tout' ? activeCategory : undefined)
  }, [activeCategory, fetchProduits])

  const openAddModal = () => {
    setEditingProd(null)
    setReference(''); setDesignation('')
    setCategorie(activeCategory !== 'tout' ? activeCategory : 'baguettes')
    setUnite('metre_lineaire'); setPrixHt('0')
    setTva('20'); setNotes('')
    setModalOpen(true)
  }

  const openEditModal = (p: Produit) => {
    setEditingProd(p)
    setReference(p.reference || '')
    setDesignation(p.designation)
    setCategorie(p.categorie)
    setUnite(p.unite_calcul)
    setPrixHt(p.prix_ht.toString())
    setTva(p.taux_tva.toString())
    setNotes(p.notes || '')
    setModalOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!designation) return

    const data = {
      reference: reference || null,
      designation,
      categorie: categorie as any,
      unite_calcul: unite as any,
      prix_ht: parseFloat(prixHt) || 0,
      taux_tva: parseFloat(tva) || 20,
      notes: notes || null
    }

    try {
      if (editingProd) {
        await updateProduit(editingProd.id, data)
        addToast({ type: 'success', message: 'Produit mis à jour' })
      } else {
        await createProduit({ ...data, actif: 1 })
        addToast({ type: 'success', message: 'Nouveau produit ajouté' })
      }
      setModalOpen(false)
    } catch {
      addToast({ type: 'error', message: 'Erreur d’enregistrement' })
    }
  }

  const handleDelete = async (id: number, nom: string) => {
    if (window.confirm(`Supprimer définitivement "${nom}" ?\nAttention, cette action est irréversible (sauf si le produit est lié à un devis, auquel cas il vaut mieux le désactiver).`)) {
      try {
        await deleteProduit(id)
        addToast({ type: 'info', message: 'Produit supprimé' })
      } catch {
        addToast({ type: 'error', message: 'Erreur de suppression ou produit utilisé, essayez de le désactiver.' })
      }
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="section-header">
        <div>
          <h1 className="section-title">Catalogue</h1>
          <p className="section-subtitle">Gérez vos articles, baguettes, verres et tarifs</p>
        </div>
        <Button onClick={openAddModal}><Plus className="w-4 h-4" />Nouveau produit</Button>
      </div>

      <div className="flex gap-2 p-1 bg-glass-bg border border-glass-border rounded-lg w-max mb-2">
        <button
          onClick={() => setActiveCategory('tout')}
          className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${activeCategory === 'tout' ? 'bg-accent-primary text-white shadow-sm' : 'text-text-secondary hover:text-text-primary'}`}
        >
          Tout
        </button>
        {CATEGORIES.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${activeCategory === cat.id ? 'bg-accent-primary text-white shadow-sm' : 'text-text-secondary hover:text-text-primary'}`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      <DataTable
        data={produits}
        columns={[
          { key: 'reference', label: 'Réf.', render: p => <span className="text-text-muted font-mono text-xs">{p.reference || '-'}</span> },
          { key: 'designation', label: 'Désignation', render: p => <span className={p.actif ? 'font-medium' : 'text-text-muted font-medium line-through'}>{p.designation}</span> },
          { key: 'categorie', label: 'Catégorie', render: p => CATEGORIES.find(c => c.id === p.categorie)?.label },
          { key: 'prix_ht', label: 'Prix HT', align: 'right', render: p => formatCurrency(p.prix_ht) },
          { key: 'taux_tva', label: 'TVA', align: 'right', render: p => `${p.taux_tva}%` },
          { key: 'unite_calcul', label: 'Unité', align: 'right', render: p => UNITES.find(u => u.id === p.unite_calcul)?.label },
          { key: 'actif', label: 'Statut', align: 'center', render: p => p.actif ? <Badge variant="accepte">Actif</Badge> : <Badge variant="brouillon">Inactif</Badge> },
          { 
            key: 'actions', 
            label: '', 
            align: 'right',
            render: (p) => (
              <div className="flex justify-end gap-1">
                <Button variant="ghost" size="icon" title={p.actif ? 'Désactiver' : 'Activer'} onClick={() => toggleActif(p.id)}>
                  {p.actif ? <Power className="w-4 h-4 text-warning" /> : <PowerOff className="w-4 h-4 text-success" />}
                </Button>
                <Button variant="ghost" size="icon" onClick={() => openEditModal(p)}><Edit className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" className="text-danger hover:text-danger hover:bg-danger/10" onClick={() => handleDelete(p.id, p.designation)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )
          }
        ]}
      />

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingProd ? "Modifier le produit" : "Ajouter un produit"}
      >
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-3 gap-4">
            <Input className="col-span-1" label="Référence" value={reference} onChange={e => setReference(e.target.value)} />
            <Input className="col-span-2" label="Désignation *" required value={designation} onChange={e => setDesignation(e.target.value)} />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <Select label="Catégorie" value={categorie} onChange={e => setCategorie(e.target.value)}>
              {CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
            </Select>
            <Select label="Unité de calcul" value={unite} onChange={e => setUnite(e.target.value)}>
              {UNITES.map(u => <option key={u.id} value={u.id}>{u.label}</option>)}
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input label="Prix unitaire HT (€)" type="number" step="0.01" value={prixHt} onChange={e => setPrixHt(e.target.value)} />
            <Select label="Taux TVA" value={tva} onChange={e => setTva(e.target.value)}>
              <option value="20">20%</option>
              <option value="10">10%</option>
              <option value="5.5">5.5%</option>
              <option value="0">0%</option>
            </Select>
          </div>

          <Textarea label="Notes / Description" value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
          
          <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-glass-border">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button type="submit">{editingProd ? 'Enregistrer' : 'Ajouter'}</Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

export default Catalogue
