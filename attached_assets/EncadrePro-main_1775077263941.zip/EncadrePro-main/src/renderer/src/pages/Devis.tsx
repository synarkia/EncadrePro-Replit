import React, { useEffect, useState } from 'react'
import { Plus, Trash2, Edit } from 'lucide-react'
import { useDevisStore, Devis as DevisModel } from '../store/useDevisStore'
import { useFacturesStore } from '../store/useFacturesStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { DataTable } from '../components/ui/DataTable'
import { Badge } from '../components/ui/Badge'
import { Select } from '../components/ui/Input'
import { ClientSelector } from '../components/domain/ClientSelector'
import DevisDetail from './DevisDetail'

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

const Devis: React.FC = () => {
  const { devis, fetchDevis, createDevis, deleteDevis, updateStatut } = useDevisStore()
  const { createFacture } = useFacturesStore()
  const { addToast } = useUIStore()

  const [filterStatut, setFilterStatut] = useState<string>('tout')
  const [selectorOpen, setSelectorOpen] = useState(false)
  const [selectedDevisId, setSelectedDevisId] = useState<number | null>(null)

  useEffect(() => {
    fetchDevis(filterStatut !== 'tout' ? { statut: filterStatut } : undefined)
  }, [filterStatut, fetchDevis])

  const handleCreateRequest = () => {
    setSelectorOpen(true)
  }

  const handleClientSelected = async (clientId: number) => {
    setSelectorOpen(false)
    try {
      const nouveauDevis = await createDevis(clientId, '')
      addToast({ type: 'success', message: 'Nouveau devis créé (brouillon)' })
      setSelectedDevisId(nouveauDevis.id)
    } catch {
      addToast({ type: 'error', message: 'Erreur lors de la création du devis' })
    }
  }

  const handleDelete = async (id: number, e: React.MouseEvent) => {
    e.stopPropagation()
    if (window.confirm("Supprimer ce devis ?")) {
      try {
        await deleteDevis(id)
        if (selectedDevisId === id) setSelectedDevisId(null)
        addToast({ type: 'info', message: 'Devis supprimé' })
      } catch {
        addToast({ type: 'error', message: 'Erreur de suppression. Videz d\'abord ses lignes si nécessaire.' })
      }
    }
  }

  const handleConvert = async (d: DevisModel, e: React.MouseEvent) => {
    e.stopPropagation()
    if (window.confirm(`Convertir le devis ${d.numero} en facture ?`)) {
      try {
        // @ts-ignore
        const fac = await window.api.factures.createFromDevis(d.id, d.client_id)
        addToast({ type: 'success', message: `Facture ${fac.numero} créée avec succès !` })
        fetchDevis(filterStatut !== 'tout' ? { statut: filterStatut } : undefined) // refresh list
      } catch (err: any) {
        addToast({ type: 'error', message: err.message || 'Erreur lors de la conversion' })
      }
    }
  }

  if (selectedDevisId) {
    return <DevisDetail devisId={selectedDevisId} onBack={() => {
      setSelectedDevisId(null)
      fetchDevis(filterStatut !== 'tout' ? { statut: filterStatut } : undefined)
    }} />
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="section-header">
        <div>
          <h1 className="section-title">Devis</h1>
          <p className="section-subtitle">Chiffrage et propositions commerciales</p>
        </div>
        <Button onClick={handleCreateRequest}><Plus className="w-4 h-4" />Nouveau devis</Button>
      </div>

      <div className="flex items-center gap-4 py-2">
        <Select value={filterStatut} onChange={(e) => setFilterStatut(e.target.value)} className="w-[200px] mb-0 border-glass-border">
          <option value="tout">Tous les statuts</option>
          <option value="brouillon">Brouillon</option>
          <option value="envoye">Envoyé</option>
          <option value="accepte">Accepté</option>
          <option value="refuse">Refusé</option>
          <option value="converti">Converti en facture</option>
        </Select>
      </div>

      <DataTable
        data={devis}
        onRowClick={(d) => setSelectedDevisId(d.id)}
        emptyMessage="Aucun devis trouvé."
        columns={[
          { key: 'numero', label: 'Numéro', render: d => <span className="font-mono text-sm">{d.numero}</span> },
          { key: 'client_nom', label: 'Client', render: d => <span className="font-semibold">{d.client_prenom} {d.client_nom}</span> },
          { key: 'date_creation', label: 'Créé le', render: d => new Date(d.date_creation).toLocaleDateString('fr-FR') },
          { key: 'statut', label: 'Statut', render: d => <Badge variant={d.statut}>{d.statut}</Badge> },
          { key: 'total_ttc', label: 'Total TTC', align: 'right', render: d => <span className="font-semibold text-text-primary">{formatCurrency(d.total_ttc)}</span> },
          { 
            key: 'actions', 
            label: '', 
            align: 'right',
            render: (d) => (
              <div className="flex justify-end gap-2" onClick={e => e.stopPropagation()}>
                {d.statut === 'accepte' && (
                  <Button size="sm" variant="primary" className="py-1 px-3" onClick={(e) => handleConvert(d, e)}>Convertir</Button>
                )}
                {d.statut !== 'converti' && (
                   <Button variant="ghost" size="icon" className="text-danger hover:text-danger hover:bg-danger/10" onClick={(e) => handleDelete(d.id, e)}>
                     <Trash2 className="w-4 h-4" />
                   </Button>
                )}
              </div>
            )
          }
        ]}
      />

      <ClientSelector isOpen={selectorOpen} onClose={() => setSelectorOpen(false)} onSelect={handleClientSelected} />
    </div>
  )
}

export default Devis
