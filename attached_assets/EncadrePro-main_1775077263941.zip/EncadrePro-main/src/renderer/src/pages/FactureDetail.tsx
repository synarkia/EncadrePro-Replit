import React, { useEffect, useState } from 'react'
import { ArrowLeft, Save, Edit, Download, CheckCircle, RefreshCw } from 'lucide-react'
import { useFacturesStore } from '../store/useFacturesStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { GlassCard } from '../components/ui/GlassCard'
import { Badge } from '../components/ui/Badge'
import { TotauxPanel } from '../components/domain/TotauxPanel'
import { Input, Select } from '../components/ui/Input'

interface FactureDetailProps {
  facId: number
  onBack: () => void
}

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

const FactureDetail: React.FC<FactureDetailProps> = ({ facId, onBack }) => {
  const { factures, addPaiement, updateStatut } = useFacturesStore()
  const { addToast } = useUIStore()

  const doc = factures.find(f => f.id === facId)
  
  const [lignes, setLignes] = useState<any[]>([])
  const [paiements, setPaiements] = useState<any[]>([])
  
  const [montantPaiement, setMontantPaiement] = useState('')
  const [methodePaiement, setMethodePaiement] = useState('virement')

  useEffect(() => {
    async function fetchData() {
      try {
        // @ts-ignore
        const lgs = await window.api.factures.getLignes(facId)
        // @ts-ignore
        const pms = await window.api.factures.getPaiements(facId)
        setLignes(lgs)
        setPaiements(pms)
      } catch (err) {
        addToast({ type: 'error', message: "Erreur lors du chargement des détails" })
      }
    }
    fetchData()
  }, [facId, addToast])

  if (!doc) return <div className="p-8 text-text-muted">Document introuvable.</div>

  const isSoldée = doc.statut === 'soldee'
  const resteAPayer = doc.total_restant

  const handleAddPaiement = async (e: React.FormEvent) => {
    e.preventDefault()
    const m = parseFloat(montantPaiement)
    if (!m || m <= 0) return
    if (m > resteAPayer) {
      addToast({ type: 'error', message: "Le montant ne peut pas dépasser le reste à payer" })
      return
    }

    try {
      await addPaiement(doc.id, { montant: m, methode: methodePaiement, notes: null })
      addToast({ type: 'success', message: "Paiement enregistré" })
      setMontantPaiement('')
      // refresh paiements
      // @ts-ignore
      const pms = await window.api.factures.getPaiements(facId)
      setPaiements(pms)
    } catch {
      addToast({ type: 'error', message: "Erreur lors de l'enregistrement du paiement" })
    }
  }

  const handleStatut = async (s: string) => {
    try {
      await updateStatut(doc.id, s)
      addToast({ type: 'success', message: `Statut passé à : ${s}` })
    } catch {
      addToast({ type: 'error', message: "Erreur lors du changement de statut" })
    }
  }

  return (
    <div className="flex flex-col gap-6 pb-10">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-4">
          <Button variant="secondary" size="icon" onClick={onBack} title="Retour"><ArrowLeft className="w-5 h-5" /></Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-24px font-bold text-text-primary">Facture {doc.numero}</h1>
              <Badge variant={doc.statut}>{doc.statut.replace('_', ' ')}</Badge>
            </div>
            <p className="text-sm text-text-muted">
              Pour <span className="font-medium text-text-secondary">{doc.client_prenom} {doc.client_nom}</span> • Échéance : {new Date(doc.date_echeance).toLocaleDateString('fr-FR')}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
           {!isSoldée && (
             <>
               {doc.statut === 'brouillon' && <Button variant="secondary" onClick={() => handleStatut('envoyee')}><RefreshCw className="w-4 h-4 mr-2"/> Marquer Envoyée</Button>}
               {resteAPayer === 0 && doc.statut !== 'soldee' && (
                 <Button variant="ghost" className="text-success hover:bg-success/10 hover:text-success" onClick={() => handleStatut('soldee')}><CheckCircle className="w-4 h-4 mr-2"/>Clôturer (Solde nul)</Button>
               )}
             </>
           )}
           <Button variant="secondary" onClick={() => {
             // @ts-ignore
             window.api.pdf.generateFacture(doc.id).then((p) => {
               // @ts-ignore
               window.api.pdf.openPdf(p)
             }).catch((e:any) => addToast({type: 'error', message: 'Erreur PDF : '+e.message}))
           }}>
             <Download className="w-4 h-4 mr-2" /> PDF
           </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Colonne Principale: Lignes (Readonly) */}
        <div className="col-span-1 lg:col-span-2 flex flex-col gap-6">
          <GlassCard className="p-0 overflow-hidden flex flex-col">
            <div className="p-4 border-b border-glass-border bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-primary">Lignes de prestation</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm data-table">
                <thead>
                  <tr>
                    <th className="text-left">Désignation</th>
                    <th className="text-center">Quantité</th>
                    <th className="text-right">PU HT</th>
                    <th className="text-right">TVA</th>
                    <th className="text-right">Total HT</th>
                  </tr>
                </thead>
                <tbody>
                  {lignes.map((l, i) => (
                    <tr key={i}>
                      <td className="font-medium text-text-primary">{l.designation}</td>
                      <td className="text-center font-mono text-accent-primary">{l.quantite_calculee} <span className="text-text-muted text-xs capitalize">({l.unite_calcul.replace('_', ' ')})</span></td>
                      <td className="text-right font-mono">{formatCurrency(l.prix_unitaire_ht)}</td>
                      <td className="text-right text-text-muted">{l.taux_tva}%</td>
                      <td className="text-right font-mono font-semibold">{formatCurrency(l.quantite_calculee * l.prix_unitaire_ht)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>

          {/* Table Paiements */}
          <GlassCard className="p-0 overflow-hidden">
            <div className="p-4 border-b border-glass-border bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-primary">Historique des paiements</h3>
            </div>
            <div className="p-2">
              {paiements.length === 0 ? <p className="p-4 text-center text-sm text-text-muted">Aucun paiement enregistré.</p> : (
                <table className="w-full text-sm data-table">
                  <thead>
                    <tr>
                      <th className="text-left">Date</th>
                      <th className="text-center">Méthode</th>
                      <th className="text-right">Montant</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paiements.map(p => (
                      <tr key={p.id}>
                        <td>{new Date(p.date_paiement).toLocaleDateString('fr-FR')}</td>
                        <td className="text-center capitalize">{p.methode_paiement}</td>
                        <td className="text-right font-mono font-bold text-success">+{formatCurrency(p.montant)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </GlassCard>
        </div>

        {/* Sidebar: Totaux & Saisie Acompte */}
        <div className="col-span-1 flex flex-col gap-6">
          <GlassCard className="p-0 overflow-hidden">
            <div className="p-4 border-b border-glass-border bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-primary">Montants</h3>
            </div>
            <div className="p-4 pb-6 flex flex-col gap-4">
              <TotauxPanel 
                sous_total_ht={doc.sous_total_ht}
                total_tva_10={doc.total_tva_10}
                total_tva_20={doc.total_tva_20}
                total_ttc={doc.total_ttc}
              />
              <div className="p-4 bg-danger/10 border border-danger/20 rounded-lg flex justify-between items-center text-danger">
                <span className="font-semibold">Reste à payer</span>
                <span className="font-mono text-xl tracking-tight font-bold">{formatCurrency(resteAPayer)}</span>
              </div>
            </div>
          </GlassCard>

          {!isSoldée && resteAPayer > 0 && (
            <GlassCard>
               <h3 className="text-sm font-semibold uppercase tracking-wider text-text-primary mb-4">Saisir un paiement</h3>
               <form onSubmit={handleAddPaiement} className="flex flex-col gap-4">
                 <Input 
                   label="Montant (€)" 
                   type="number" 
                   step="0.01" 
                   max={resteAPayer} 
                   min="0.01"
                   value={montantPaiement} 
                   onChange={e => setMontantPaiement(e.target.value)} 
                   required
                 />
                 <Select 
                   label="Méthode de paiement"
                   value={methodePaiement}
                   onChange={e => setMethodePaiement(e.target.value)}
                 >
                   <option value="virement">Virement</option>
                   <option value="cb">Carte Bancaire</option>
                   <option value="cheque">Chèque</option>
                   <option value="especes">Espèces</option>
                 </Select>
                 <Button type="submit" variant="primary" className="mt-2 w-full">Enregistrer le paiement</Button>
               </form>
            </GlassCard>
          )}
        </div>
        
      </div>
    </div>
  )
}

export default FactureDetail
