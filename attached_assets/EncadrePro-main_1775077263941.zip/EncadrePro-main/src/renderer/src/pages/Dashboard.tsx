import React, { useEffect, useState } from 'react'
import { GlassCard } from '../components/ui/GlassCard'
import { Users, FileText, Receipt, Euro } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { useUIStore } from '../store/useUIStore'

interface DashboardStats {
  caMois: number
  devisEnAttente: { n: number; montant: number }
  facturesImpayees: { n: number; montant: number }
  nouveauxClients: number
}

interface CAMensuel {
  mois: string
  total: number
}

interface RecentDoc {
  id: number
  numero: string
  client_nom: string
  client_prenom: string
  total_ttc: number
  statut: string
  cree_le: string
}

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)
const formatMonth = (str: string) => {
  const [y, m] = str.split('-')
  const date = new Date(parseInt(y), parseInt(m) - 1, 1)
  return new Intl.DateTimeFormat('fr-FR', { month: 'short', year: '2-digit' }).format(date)
}

const Dashboard: React.FC = () => {
  const { setActivePage } = useUIStore()
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [caData, setCaData] = useState<CAMensuel[]>([])
  const [recentDevis, setRecentDevis] = useState<RecentDoc[]>([])
  const [recentFactures, setRecentFactures] = useState<RecentDoc[]>([])

  useEffect(() => {
    async function loadData() {
      // @ts-ignore
      const [s, c, d, f] = await Promise.all([
        window.api.dashboard.getStats(),
        window.api.dashboard.getCAMensuel(),
        window.api.dashboard.getRecentDevis(),
        window.api.dashboard.getRecentFactures()
      ])
      setStats(s)
      setCaData(c)
      setRecentDevis(d)
      setRecentFactures(f)
    }
    loadData()
  }, [])

  if (!stats) return <div className="p-8 animate-pulse flex gap-4">Chargement des données...</div>

  return (
    <div className="flex flex-col gap-8 pb-10">
      <div className="section-header mb-2">
        <div>
          <h1 className="section-title">Tableau de bord</h1>
          <p className="section-subtitle">Aperçu de l'activité de l'atelier</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="kpi-card text-accent-primary">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-13px font-medium text-text-secondary">CA du mois (TTC)</h3>
            <div className="p-2 bg-accent-primary/10 rounded-lg"><Euro className="w-5 h-5 text-accent-primary" /></div>
          </div>
          <p className="text-2xl font-bold tracking-tight text-text-primary">{formatCurrency(stats.caMois)}</p>
        </GlassCard>

        <GlassCard className="kpi-card text-gold">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-13px font-medium text-text-secondary">Devis en attente</h3>
            <div className="p-2 bg-accent-secondary/10 rounded-lg"><FileText className="w-5 h-5 text-accent-secondary" /></div>
          </div>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-bold tracking-tight text-text-primary">{stats.devisEnAttente.n}</p>
            <p className="text-sm text-text-muted">/ {formatCurrency(stats.devisEnAttente.montant)}</p>
          </div>
        </GlassCard>

        <GlassCard className="kpi-card text-danger">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-13px font-medium text-text-secondary">Factures impayées</h3>
            <div className="p-2 bg-danger/10 rounded-lg"><Receipt className="w-5 h-5 text-danger" /></div>
          </div>
          <div className="flex items-baseline gap-2">
            <p className="text-2xl font-bold tracking-tight text-text-primary">{stats.facturesImpayees.n}</p>
            <p className="text-sm text-text-muted">/ {formatCurrency(stats.facturesImpayees.montant)}</p>
          </div>
        </GlassCard>

        <GlassCard className="kpi-card text-success">
          <div className="flex justify-between items-start mb-2">
            <h3 className="text-13px font-medium text-text-secondary">Nouveaux clients</h3>
            <div className="p-2 bg-success/10 rounded-lg"><Users className="w-5 h-5 text-success" /></div>
          </div>
          <p className="text-2xl font-bold tracking-tight text-text-primary">+{stats.nouveauxClients}</p>
        </GlassCard>
      </div>

      {/* Charts & Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart */}
        <GlassCard className="h-[360px] flex flex-col">
          <h3 className="text-sm font-semibold mb-6 uppercase tracking-wider text-text-muted">Chiffre d'affaires (12 mois)</h3>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={caData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <XAxis dataKey="mois" axisLine={false} tickLine={false} tickFormatter={formatMonth} tick={{ fontSize: 12, fill: 'var(--text-muted)' }} dy={10} />
                <Tooltip
                  cursor={{ fill: 'var(--glass-hover)' }}
                  contentStyle={{ backgroundColor: 'var(--bg-tertiary)', border: '1px solid var(--glass-border)', borderRadius: '12px', boxShadow: '0 8px 32px rgba(0,0,0,0.3)' }}
                  itemStyle={{ color: 'var(--text-primary)', fontWeight: 600 }}
                  labelStyle={{ color: 'var(--text-secondary)', marginBottom: 4 }}
                  formatter={(val: number) => [formatCurrency(val), 'CA TTC']}
                  labelFormatter={formatMonth}
                />
                <Bar dataKey="total" radius={[6, 6, 0, 0]}>
                  {caData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill="var(--accent-primary)" fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Recent Lists */}
        <div className="flex flex-col gap-6">
          <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden">
            <div className="p-5 border-b border-glass-border flex justify-between items-center bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted">Derniers devis</h3>
              <button onClick={() => setActivePage('devis')} className="text-13px text-accent-primary hover:underline">Voir tout</button>
            </div>
            <div className="p-2">
              {recentDevis.length === 0 ? <p className="p-4 text-center text-sm text-text-muted">Aucun devis</p> : null}
              {recentDevis.map(d => (
                <div key={d.id} className="flex justify-between items-center p-3 hover:bg-glass-hover rounded-lg transition-colors cursor-pointer" onClick={() => setActivePage('devis')}>
                  <div>
                    <p className="text-14px font-medium text-text-primary">{d.client_prenom} {d.client_nom}</p>
                    <p className="text-12px text-text-muted">{d.numero} &bull; {new Date(d.cree_le).toLocaleDateString('fr-FR')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-14px font-semibold text-text-primary">{formatCurrency(d.total_ttc)}</p>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          <GlassCard className="flex-1 flex flex-col p-0 overflow-hidden">
            <div className="p-5 border-b border-glass-border flex justify-between items-center bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted">Dernières factures</h3>
              <button onClick={() => setActivePage('factures')} className="text-13px text-accent-primary hover:underline">Voir tout</button>
            </div>
            <div className="p-2">
              {recentFactures.length === 0 ? <p className="p-4 text-center text-sm text-text-muted">Aucune facture</p> : null}
              {recentFactures.map(f => (
                <div key={f.id} className="flex justify-between items-center p-3 hover:bg-glass-hover rounded-lg transition-colors cursor-pointer" onClick={() => setActivePage('factures')}>
                  <div>
                    <p className="text-14px font-medium text-text-primary">{f.client_prenom} {f.client_nom}</p>
                    <p className="text-12px text-text-muted">{f.numero} &bull; {new Date(f.cree_le).toLocaleDateString('fr-FR')}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-14px font-semibold text-text-primary">{formatCurrency(f.total_ttc)}</p>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
