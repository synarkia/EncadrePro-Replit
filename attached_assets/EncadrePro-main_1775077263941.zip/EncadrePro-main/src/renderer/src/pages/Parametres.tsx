import React, { useEffect, useState } from 'react'
import { Save } from 'lucide-react'
import { useAtelierStore } from '../store/useAtelierStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { Input, Textarea } from '../components/ui/Input'
import { GlassCard } from '../components/ui/GlassCard'

const Parametres: React.FC = () => {
  const { config, fetchConfig, saveConfig } = useAtelierStore()
  const { addToast } = useUIStore()

  const [nom, setNom] = useState('')
  const [siret, setSiret] = useState('')
  const [adresse, setAdresse] = useState('')
  const [telephone, setTelephone] = useState('')
  const [email, setEmail] = useState('')
  const [mentions, setMentions] = useState('')
  const [rib, setRib] = useState('')
  
  const [smtpHost, setSmtpHost] = useState('')
  const [smtpPort, setSmtpPort] = useState('')
  const [smtpUser, setSmtpUser] = useState('')
  const [smtpPass, setSmtpPass] = useState('')

  useEffect(() => {
    fetchConfig()
  }, [fetchConfig])

  // Sync state with config
  useEffect(() => {
    if (config) {
      setNom(config.nom_atelier || '')
      setSiret(config.siret || '')
      setAdresse(config.adresse || '')
      setTelephone(config.telephone || '')
      setEmail(config.email || '')
      setMentions(config.mentions_legales || '')
      setRib(config.rib || '')
      setSmtpHost(config.smtp_host || '')
      setSmtpPort(config.smtp_port ? config.smtp_port.toString() : '')
      setSmtpUser(config.smtp_user || '')
      setSmtpPass(config.smtp_pass || '')
    }
  }, [config])

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await saveConfig({
        nom_atelier: nom,
        siret,
        adresse,
        telephone,
        email,
        mentions_legales: mentions,
        rib,
        smtp_host: smtpHost,
        smtp_port: parseInt(smtpPort) || null,
        smtp_user: smtpUser,
        smtp_pass: smtpPass
      })
      addToast({ type: 'success', message: 'Paramètres enregistrés avec succès' })
    } catch {
      addToast({ type: 'error', message: 'Erreur lors de l’enregistrement' })
    }
  }

  return (
    <form onSubmit={handleSave} className="flex flex-col gap-8 pb-10">
      <div className="section-header">
        <div>
          <h1 className="section-title">Paramètres</h1>
          <p className="section-subtitle">Configuration de l'atelier et options d'envoi</p>
        </div>
        <Button type="submit"><Save className="w-4 h-4 mr-2" /> Enregistrer</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Infos Atelier */}
        <div className="flex flex-col gap-6">
          <GlassCard>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted mb-4">Informations de l'Atelier</h3>
            <div className="flex flex-col gap-4">
              <Input label="Nom de l'atelier *" required value={nom} onChange={e => setNom(e.target.value)} />
              <Input label="SIRET" value={siret} onChange={e => setSiret(e.target.value)} />
              <Textarea label="Adresse" value={adresse} onChange={e => setAdresse(e.target.value)} rows={2} />
              <div className="grid grid-cols-2 gap-4">
                <Input label="Téléphone" value={telephone} onChange={e => setTelephone(e.target.value)} />
                <Input label="Email de contact" type="email" value={email} onChange={e => setEmail(e.target.value)} />
              </div>
            </div>
          </GlassCard>

          <GlassCard>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted mb-4">Paiement & Légal</h3>
            <div className="flex flex-col gap-4">
              <Textarea label="Coordonnées bancaires (RIB / IBAN)" value={rib} onChange={e => setRib(e.target.value)} rows={3} placeholder="Sera affiché en bas de vos factures" />
              <Textarea label="Mentions Légales & Conditions (TVA, Délais, etc.)" value={mentions} onChange={e => setMentions(e.target.value)} rows={4} placeholder="Mentions obligatoires sur devis et factures" />
            </div>
          </GlassCard>
        </div>

        {/* Mailing & Backup */}
        <div className="flex flex-col gap-6">
          <GlassCard>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted mb-4">Configuration Email SMTP</h3>
            <p className="text-sm text-text-secondary mb-4">Cette configuration permet l'envoi de devis et factures en PDF directement par e-mail au client.</p>
            <div className="flex flex-col gap-4">
              <div className="grid grid-cols-3 gap-4">
                <Input className="col-span-2" label="Hôte SMTP (ex: smtp.gmail.com)" value={smtpHost} onChange={e => setSmtpHost(e.target.value)} />
                <Input className="col-span-1" label="Port" type="number" value={smtpPort} onChange={e => setSmtpPort(e.target.value)} />
              </div>
              <Input label="Utilisateur SMTP" value={smtpUser} onChange={e => setSmtpUser(e.target.value)} />
              <Input label="Mot de passe SMTP" type="password" value={smtpPass} onChange={e => setSmtpPass(e.target.value)} />
            </div>
          </GlassCard>
        </div>
      </div>
    </form>
  )
}

export default Parametres
