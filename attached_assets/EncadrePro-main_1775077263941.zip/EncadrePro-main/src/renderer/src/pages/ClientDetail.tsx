import React, { useEffect, useState } from 'react'
import { ArrowLeft, Edit, Mail, Phone, MapPin } from 'lucide-react'
import { useClientsStore, Client } from '../store/useClientsStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { GlassCard } from '../components/ui/GlassCard'
import { Badge } from '../components/ui/Badge'
import { DataTable } from '../components/ui/DataTable'

interface ClientDetailProps {
  clientId: number
  onBack: () => void
}

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

export const ClientDetail: React.FC<ClientDetailProps> = ({ clientId, onBack }) => {
  const { getClient } = useClientsStore()
  const { setActivePage } = useUIStore()

  const [client, setClient] = useState<Client | null>(null)
  const [history, setHistory] = useState<{ devis: any[]; factures: any[] }>({ devis: [], factures: [] })

  useEffect(() => {
    async function load() {
      const c = await getClient(clientId)
      setClient(c)
      // @ts-ignore
      const h = await window.api.clients.getHistory(clientId)
      setHistory(h)
    }
    load()
  }, [clientId, getClient])

  if (!client) return <div className="p-8 animate-pulse text-text-muted">Chargement de la fiche client...</div>

  return (
    <div className="flex flex-col gap-6 pb-10">
      <div className="flex items-center gap-4 mb-2">
        <Button variant="secondary" size="icon" onClick={onBack} title="Retour à la liste"><ArrowLeft className="w-5 h-5" /></Button>
        <div>
          <h1 className="text-24px font-bold text-text-primary mb-1">{client.prenom} {client.nom}</h1>
          <p className="text-sm text-text-muted">Client depuis le {new Date(client.cree_le).toLocaleDateString('fr-FR')}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassCard className="col-span-1 flex flex-col gap-5">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted">Contact & Adresse</h3>
          
          <div className="flex flex-col gap-4">
             {client.email && (
               <div className="flex items-center gap-3 text-sm text-text-primary">
                 <div className="p-1.5 rounded-md bg-accent-primary/10 text-accent-primary"><Mail className="w-4 h-4" /></div>
                 <a href={`mailto:${client.email}`} className="hover:underline">{client.email}</a>
               </div>
             )}
             {client.telephone && (
               <div className="flex items-center gap-3 text-sm text-text-primary">
                 <div className="p-1.5 rounded-md bg-accent-primary/10 text-accent-primary"><Phone className="w-4 h-4" /></div>
                 <a href={`tel:${client.telephone}`} className="hover:underline">{client.telephone}</a>
               </div>
             )}
             {(client.adresse || client.ville) && (
               <div className="flex items-start gap-3 text-sm text-text-primary">
                 <div className="p-1.5 rounded-md bg-accent-primary/10 text-accent-primary mt-0.5"><MapPin className="w-4 h-4" /></div>
                 <div>
                   <p>{client.adresse}</p>
                   <p>{client.code_postal} {client.ville}</p>
                 </div>
               </div>
             )}
          </div>

          {client.notes && (
            <>
              <div className="divider my-0" />
              <div>
                <h4 className="text-xs font-semibold text-text-muted uppercase mb-2">Notes internes</h4>
                <p className="text-sm text-text-primary whitespace-pre-wrap">{client.notes}</p>
              </div>
            </>
          )}
        </GlassCard>

        <div className="col-span-1 lg:col-span-2 flex flex-col gap-6">
          <GlassCard className="p-0 overflow-hidden">
             <div className="p-5 border-b border-glass-border">
               <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted">Factures récentes</h3>
             </div>
             <div className="p-2">
                <DataTable
                  data={history.factures}
                  columns={[
                    { key: 'numero', label: 'N° Facture', render: f => <span className="font-mono text-sm">{f.numero}</span> },
                    { key: 'date_echeance', label: 'Echéance', render: f => new Date(f.date_echeance).toLocaleDateString('fr-FR') },
                    { key: 'total_ttc', label: 'Total TTC', align: 'right', render: f => <span className="font-semibold">{formatCurrency(f.total_ttc)}</span> },
                    { key: 'statut', label: 'Statut', align: 'right', render: f => <Badge variant={f.statut}>{f.statut.replace('_', ' ')}</Badge> }
                  ]}
                />
             </div>
          </GlassCard>

          <GlassCard className="p-0 overflow-hidden">
             <div className="p-5 border-b border-glass-border">
               <h3 className="text-sm font-semibold uppercase tracking-wider text-text-muted">Devis récents</h3>
             </div>
             <div className="p-2">
                <DataTable
                  data={history.devis}
                  columns={[
                    { key: 'numero', label: 'N° Devis', render: d => <span className="font-mono text-sm">{d.numero}</span> },
                    { key: 'date_validite', label: 'Validité', render: d => new Date(d.date_validite).toLocaleDateString('fr-FR') },
                    { key: 'total_ttc', label: 'Total TTC', align: 'right', render: d => <span className="font-semibold">{formatCurrency(d.total_ttc)}</span> },
                    { key: 'statut', label: 'Statut', align: 'right', render: d => <Badge variant={d.statut}>{d.statut}</Badge> }
                  ]}
                />
             </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}

export default ClientDetail
