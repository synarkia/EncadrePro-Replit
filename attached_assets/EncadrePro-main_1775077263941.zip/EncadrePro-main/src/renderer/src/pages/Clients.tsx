import React, { useEffect, useState } from 'react'
import { Plus, Trash2, Edit } from 'lucide-react'
import { useClientsStore, Client } from '../store/useClientsStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { Input, Textarea } from '../components/ui/Input'
import { Modal } from '../components/ui/Modal'
import { DataTable } from '../components/ui/DataTable'
import ClientDetail from './ClientDetail'

const Clients: React.FC = () => {
  const { clients, fetchClients, createClient, updateClient, deleteClient } = useClientsStore()
  const { addToast } = useUIStore()

  const [search, setSearch] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingClient, setEditingClient] = useState<Client | null>(null)
  
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null)

  const [nom, setNom] = useState('')
  const [prenom, setPrenom] = useState('')
  const [email, setEmail] = useState('')
  const [telephone, setTelephone] = useState('')
  const [adresse, setAdresse] = useState('')
  const [cp, setCp] = useState('')
  const [ville, setVille] = useState('')
  const [notes, setNotes] = useState('')

  useEffect(() => {
    fetchClients()
  }, [fetchClients])

  // Debounced search
  useEffect(() => {
    const t = setTimeout(() => fetchClients(search), 300)
    return () => clearTimeout(t)
  }, [search, fetchClients])

  const openAddModal = () => {
    setEditingClient(null)
    setNom(''); setPrenom(''); setEmail(''); setTelephone('')
    setAdresse(''); setCp(''); setVille(''); setNotes('')
    setModalOpen(true)
  }

  const openEditModal = (c: Client) => {
    setEditingClient(c)
    setNom(c.nom)
    setPrenom(c.prenom || '')
    setEmail(c.email || '')
    setTelephone(c.telephone || '')
    setAdresse(c.adresse || '')
    setCp(c.code_postal || '')
    setVille(c.ville || '')
    setNotes(c.notes || '')
    setModalOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!nom) return

    const data = {
      nom, prenom: prenom || null, email: email || null, telephone: telephone || null,
      adresse: adresse || null, code_postal: cp || null, ville: ville || null, notes: notes || null
    }

    try {
      if (editingClient) {
        await updateClient(editingClient.id, data)
        addToast({ type: 'success', message: 'Client mis à jour avec succès' })
      } else {
        await createClient(data)
        addToast({ type: 'success', message: 'Client ajouté avec succès' })
      }
      setModalOpen(false)
    } catch {
      addToast({ type: 'error', message: 'Erreur lors de l’enregistrement du client' })
    }
  }

  const handleDelete = async (id: number, nomClient: string) => {
    if (window.confirm(`Êtes-vous sûr de vouloir supprimer définitivement le client ${nomClient} ?\nTous ses devis et factures seront supprimés en cascade.`)) {
      try {
        await deleteClient(id)
        if (selectedClientId === id) setSelectedClientId(null)
        addToast({ type: 'info', message: 'Client supprimé' })
      } catch {
        addToast({ type: 'error', message: 'Erreur lors de la suppression' })
      }
    }
  }

  if (selectedClientId) {
    return <ClientDetail clientId={selectedClientId} onBack={() => setSelectedClientId(null)} />
  }

  return (
    <div>
      <div className="section-header">
        <div>
          <h1 className="section-title">Clients</h1>
          <p className="section-subtitle">Gérez la base de données de vos clients</p>
        </div>
        <Button onClick={openAddModal}><Plus className="w-4 h-4" />Nouveau client</Button>
      </div>

      <DataTable
        data={clients}
        searchPlaceholder="Rechercher par nom, prénom, email ou téléphone..."
        searchValue={search}
        onSearchChange={setSearch}
        emptyMessage="Aucun client trouvé."
        onRowClick={(c) => setSelectedClientId(c.id)}
        columns={[
          { key: 'nom', label: 'Nom', render: c => <span className="font-semibold">{c.nom}</span> },
          { key: 'prenom', label: 'Prénom' },
          { key: 'email', label: 'Email' },
          { key: 'telephone', label: 'Téléphone' },
          { key: 'ville', label: 'Ville' },
          { 
            key: 'actions', 
            label: '', 
            align: 'right',
            render: (c) => (
              <div className="flex justify-end gap-2" onClick={e => e.stopPropagation()}>
                <Button variant="ghost" size="icon" onClick={() => openEditModal(c)}><Edit className="w-4 h-4" /></Button>
                <Button variant="ghost" size="icon" className="text-danger hover:text-danger hover:bg-danger/10" onClick={() => handleDelete(c.id, c.nom)}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )
          }
        ]}
      />

      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingClient ? "Modifier un client" : "Ajouter un client"}
      >
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-2 gap-4">
            <Input label="Nom *" required value={nom} onChange={e => setNom(e.target.value)} />
            <Input label="Prénom" value={prenom} onChange={e => setPrenom(e.target.value)} />
            <Input label="Email" type="email" value={email} onChange={e => setEmail(e.target.value)} />
            <Input label="Téléphone" value={telephone} onChange={e => setTelephone(e.target.value)} />
          </div>
          <Input label="Adresse" value={adresse} onChange={e => setAdresse(e.target.value)} />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Code postal" value={cp} onChange={e => setCp(e.target.value)} />
            <Input label="Ville" value={ville} onChange={e => setVille(e.target.value)} />
          </div>
          <Textarea label="Notes internes" value={notes} onChange={e => setNotes(e.target.value)} rows={3} />
          
          <div className="flex justify-end gap-3 mt-4 pt-4 border-t border-glass-border">
            <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>Annuler</Button>
            <Button type="submit">{editingClient ? 'Enregistrer' : 'Créer le client'}</Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

export default Clients
