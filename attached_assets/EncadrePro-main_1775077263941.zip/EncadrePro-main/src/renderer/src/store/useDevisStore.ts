import { create } from 'zustand'

export interface LigneDevis {
  id?: number
  devis_id?: number
  produit_id: number | null
  designation: string
  unite_calcul: string
  largeur_m: number | null
  hauteur_m: number | null
  quantite: number
  quantite_calculee?: number
  prix_unitaire_ht: number
  taux_tva: number
  total_ht?: number
  total_ttc?: number
  ordre?: number
}

export interface Devis {
  id: number
  numero: string
  client_id: number
  client_nom?: string
  client_prenom?: string
  date_creation: string
  date_validite: string | null
  statut: 'brouillon' | 'envoye' | 'accepte' | 'refuse' | 'converti'
  sous_total_ht: number
  total_tva_10: number
  total_tva_20: number
  total_ttc: number
  notes: string | null
  conditions: string | null
  facture_id: number | null
  cree_le: string
  modifie_le: string
}

interface DevisState {
  devis: Devis[]
  isLoading: boolean
  fetchDevis: (filters?: { statut?: string; client_id?: number }) => Promise<void>
  createDevis: (clientId: number, notes?: string) => Promise<Devis>
  updateStatut: (id: number, statut: string) => Promise<void>
  deleteDevis: (id: number) => Promise<void>
  saveLignes: (id: number, lignes: LigneDevis[]) => Promise<Devis>
}

export const useDevisStore = create<DevisState>((set) => ({
  devis: [],
  isLoading: false,

  fetchDevis: async (filters) => {
    set({ isLoading: true })
    try {
      // @ts-ignore
      const data = await window.api.devis.list(filters)
      set({ devis: data })
    } finally {
      set({ isLoading: false })
    }
  },

  createDevis: async (client_id, notes) => {
    // @ts-ignore
    const newDevis = await window.api.devis.create({ client_id, notes })
    set((state) => ({ devis: [newDevis, ...state.devis] }))
    return newDevis
  },

  updateStatut: async (id, statut) => {
    // @ts-ignore
    await window.api.devis.updateStatut(id, statut)
    set((state) => ({
      devis: state.devis.map(d => d.id === id ? { ...d, statut } : d) as Devis[]
    }))
  },

  deleteDevis: async (id) => {
    // @ts-ignore
    await window.api.devis.delete(id)
    set((state) => ({ devis: state.devis.filter(d => d.id !== id) }))
  },

  saveLignes: async (id, lignes) => {
    // @ts-ignore
    const updated = await window.api.devis.saveLignes(id, lignes)
    set((state) => ({ devis: state.devis.map(d => d.id === id ? { ...d, ...updated } : d) }))
    return updated
  }
}))
