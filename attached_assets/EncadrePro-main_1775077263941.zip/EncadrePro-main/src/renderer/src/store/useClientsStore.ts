import { create } from 'zustand'

export interface Client {
  id: number
  nom: string
  prenom: string | null
  email: string | null
  telephone: string | null
  adresse: string | null
  ville: string | null
  code_postal: string | null
  notes: string | null
  cree_le: string
  modifie_le: string
}

interface ClientsState {
  clients: Client[]
  isLoading: boolean
  fetchClients: (search?: string) => Promise<void>
  getClient: (id: number) => Promise<Client | null>
  createClient: (data: Partial<Client>) => Promise<Client>
  updateClient: (id: number, data: Partial<Client>) => Promise<Client>
  deleteClient: (id: number) => Promise<void>
}

export const useClientsStore = create<ClientsState>((set) => ({
  clients: [],
  isLoading: false,

  fetchClients: async (search) => {
    set({ isLoading: true })
    try {
      // @ts-ignore - IPC exposed in preload
      const data = await window.api.clients.list(search)
      set({ clients: data })
    } finally {
      set({ isLoading: false })
    }
  },

  getClient: async (id) => {
    // @ts-ignore
    return await window.api.clients.get(id)
  },

  createClient: async (data) => {
    // @ts-ignore
    const newClient = await window.api.clients.create(data)
    set((state) => ({ clients: [...state.clients, newClient].sort((a, b) => a.nom.localeCompare(b.nom)) }))
    return newClient
  },

  updateClient: async (id, data) => {
    // @ts-ignore
    const updatedClient = await window.api.clients.update(id, data)
    set((state) => ({
      clients: state.clients.map(c => c.id === id ? updatedClient : c).sort((a, b) => a.nom.localeCompare(b.nom))
    }))
    return updatedClient
  },

  deleteClient: async (id) => {
    // @ts-ignore
    await window.api.clients.delete(id)
    set((state) => ({ clients: state.clients.filter(c => c.id !== id) }))
  }
}))
