import { create } from 'zustand'

export interface Atelier {
  id: number
  nom: string
  siret: string | null
  adresse: string | null
  telephone: string | null
  email: string | null
  logo_path: string | null
  conditions_generales: string | null
  prefixe_devis: string
  prefixe_facture: string
  tva_defaut: number
  email_template: string | null
  smtp_host: string | null
  smtp_port: number | null
  smtp_user: string | null
  smtp_pass: string | null
}

interface AtelierState {
  atelier: Atelier | null
  isLoading: boolean
  fetchAtelier: () => Promise<void>
  saveAtelier: (data: Partial<Atelier>) => Promise<void>
}

export const useAtelierStore = create<AtelierState>((set) => ({
  atelier: null,
  isLoading: false,

  fetchAtelier: async () => {
    set({ isLoading: true })
    try {
      // @ts-ignore
      const data = await window.api.atelier.get()
      set({ atelier: data })
    } finally {
      set({ isLoading: false })
    }
  },

  saveAtelier: async (data) => {
    // @ts-ignore
    const updated = await window.api.atelier.save(data)
    set({ atelier: updated })
  }
}))
