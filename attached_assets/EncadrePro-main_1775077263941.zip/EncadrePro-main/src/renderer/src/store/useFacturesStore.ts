import { create } from 'zustand'

export interface Acompte {
  id: number
  facture_id: number
  numero_facture_acompte: string | null
  montant: number
  date_paiement: string
  mode_paiement: string | null
  notes: string | null
}

export interface Facture {
  id: number
  numero: string
  devis_id: number | null
  client_id: number
  client_nom?: string
  client_prenom?: string
  date_creation: string
  date_echeance: string | null
  statut: 'brouillon' | 'envoyee' | 'partiellement_payee' | 'soldee' | 'annulee'
  sous_total_ht: number
  total_tva_10: number
  total_tva_20: number
  total_ttc: number
  total_paye: number
  solde_restant: number
  notes: string | null
  conditions: string | null
  cree_le: string
  modifie_le: string
}

interface FacturesState {
  factures: Facture[]
  isLoading: boolean
  fetchFactures: (filters?: { statut?: string; client_id?: number }) => Promise<void>
  createFacture: (clientId: number, notes?: string) => Promise<Facture>
  updateStatut: (id: number, statut: string) => Promise<void>
  deleteFacture: (id: number) => Promise<void>
}

export const useFacturesStore = create<FacturesState>((set) => ({
  factures: [],
  isLoading: false,

  fetchFactures: async (filters) => {
    set({ isLoading: true })
    try {
      // @ts-ignore
      const data = await window.api.factures.list(filters)
      set({ factures: data })
    } finally {
      set({ isLoading: false })
    }
  },

  createFacture: async (client_id, notes) => {
    // @ts-ignore
    const newFac = await window.api.factures.create({ client_id, notes })
    set((state) => ({ factures: [newFac, ...state.factures] }))
    return newFac
  },

  updateStatut: async (id, statut) => {
    // @ts-ignore
    await window.api.factures.updateStatut(id, statut)
    set((state) => ({
      factures: state.factures.map(f => f.id === id ? { ...f, statut } : f) as Facture[]
    }))
  },

  deleteFacture: async (id) => {
    // @ts-ignore
    await window.api.factures.delete(id)
    set((state) => ({ factures: state.factures.filter(f => f.id !== id) }))
  }
}))
