import { create } from 'zustand'

export interface Produit {
  id: number
  reference: string | null
  designation: string
  categorie: 'baguettes' | 'verres' | 'passe_partout' | 'quincaillerie' | 'main_oeuvre'
  unite_calcul: 'metre_lineaire' | 'metre_carre' | 'unitaire' | 'heure'
  prix_ht: number
  taux_tva: number
  actif: number
  notes: string | null
  cree_le: string
}

interface ProduitsState {
  produits: Produit[]
  isLoading: boolean
  fetchProduits: (categorie?: string) => Promise<void>
  createProduit: (data: Partial<Produit>) => Promise<Produit>
  updateProduit: (id: number, data: Partial<Produit>) => Promise<Produit>
  deleteProduit: (id: number) => Promise<void>
  toggleActif: (id: number) => Promise<Produit>
}

export const useProduitsStore = create<ProduitsState>((set) => ({
  produits: [],
  isLoading: false,

  fetchProduits: async (categorie) => {
    set({ isLoading: true })
    try {
      // @ts-ignore
      const data = await window.api.produits.list(categorie)
      set({ produits: data })
    } finally {
      set({ isLoading: false })
    }
  },

  createProduit: async (data) => {
    // @ts-ignore
    const newProduit = await window.api.produits.create(data)
    set((state) => ({ produits: [...state.produits, newProduit] }))
    return newProduit
  },

  updateProduit: async (id, data) => {
    // @ts-ignore
    const updated = await window.api.produits.update(id, data)
    set((state) => ({ produits: state.produits.map(p => p.id === id ? updated : p) }))
    return updated
  },

  deleteProduit: async (id) => {
    // @ts-ignore
    await window.api.produits.delete(id)
    set((state) => ({ produits: state.produits.filter(p => p.id !== id) }))
  },

  toggleActif: async (id) => {
    // @ts-ignore
    const updated = await window.api.produits.toggleActif(id)
    set((state) => ({ produits: state.produits.map(p => p.id === id ? updated : p) }))
    return updated
  }
}))
