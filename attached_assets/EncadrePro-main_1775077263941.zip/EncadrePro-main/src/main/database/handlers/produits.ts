import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerProduitsHandlers(): void {
  ipcMain.handle('produits:list', (_, categorie?: string) => {
    const db = getDB()
    if (categorie) {
      return db.prepare('SELECT * FROM produits WHERE categorie = ? ORDER BY designation ASC').all(categorie)
    }
    return db.prepare('SELECT * FROM produits ORDER BY categorie, designation ASC').all()
  })

  ipcMain.handle('produits:get', (_, id: number) => {
    return getDB().prepare('SELECT * FROM produits WHERE id = ?').get(id)
  })

  ipcMain.handle('produits:create', (_, data: Record<string, unknown>) => {
    const db = getDB()
    const result = db.prepare(`
      INSERT INTO produits (reference, designation, categorie, unite_calcul, prix_ht, taux_tva, notes)
      VALUES (@reference, @designation, @categorie, @unite_calcul, @prix_ht, @taux_tva, @notes)
    `).run(data)
    return db.prepare('SELECT * FROM produits WHERE id = ?').get(result.lastInsertRowid)
  })

  ipcMain.handle('produits:update', (_, id: number, data: Record<string, unknown>) => {
    const db = getDB()
    db.prepare(`
      UPDATE produits SET
        reference = @reference, designation = @designation,
        categorie = @categorie, unite_calcul = @unite_calcul,
        prix_ht = @prix_ht, taux_tva = @taux_tva, notes = @notes
      WHERE id = @id
    `).run({ ...data, id })
    return db.prepare('SELECT * FROM produits WHERE id = ?').get(id)
  })

  ipcMain.handle('produits:delete', (_, id: number) => {
    getDB().prepare('DELETE FROM produits WHERE id = ?').run(id)
    return { success: true }
  })

  ipcMain.handle('produits:toggleActif', (_, id: number) => {
    const db = getDB()
    db.prepare('UPDATE produits SET actif = CASE WHEN actif = 1 THEN 0 ELSE 1 END WHERE id = ?').run(id)
    return db.prepare('SELECT * FROM produits WHERE id = ?').get(id)
  })
}
