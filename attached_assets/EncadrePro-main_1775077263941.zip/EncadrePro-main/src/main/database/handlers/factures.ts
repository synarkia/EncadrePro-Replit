import { ipcMain } from 'electron'
import { getDB } from '../db'

function calcLigne(ligne: Record<string, unknown>) {
  const unite = ligne.unite_calcul as string
  const largeur = Number(ligne.largeur_m || 0)
  const hauteur = Number(ligne.hauteur_m || 0)
  const quantite = Number(ligne.quantite || 1)
  const prixHT = Number(ligne.prix_unitaire_ht)
  const tva = Number(ligne.taux_tva)

  let quantiteCalculee: number
  if (unite === 'metre_lineaire') {
    quantiteCalculee = (largeur + hauteur) * 2 * quantite
  } else if (unite === 'metre_carre') {
    quantiteCalculee = largeur * hauteur * quantite
  } else {
    quantiteCalculee = quantite
  }

  return {
    quantiteCalculee,
    totalHT: quantiteCalculee * prixHT,
    totalTTC: quantiteCalculee * prixHT * (1 + tva / 100)
  }
}

function updateFactureTotaux(factureId: number): void {
  const db = getDB()
  const lignes = db.prepare('SELECT * FROM lignes_facture WHERE facture_id = ?').all(factureId) as Record<string, number>[]
  const acomptes = db.prepare('SELECT COALESCE(SUM(montant), 0) as total FROM acomptes WHERE facture_id = ?').get(factureId) as { total: number }

  let sousTotal = 0, tva10 = 0, tva20 = 0
  for (const l of lignes) {
    sousTotal += l.total_ht
    if (l.taux_tva === 10) tva10 += l.total_ht * 0.1
    else tva20 += l.total_ht * 0.2
  }

  const totalTTC = sousTotal + tva10 + tva20
  const totalPaye = acomptes.total
  const soldeRestant = Math.max(0, totalTTC - totalPaye)

  let statut = 'brouillon'
  if (totalPaye > 0 && soldeRestant > 0) statut = 'partiellement_payee'
  else if (totalPaye >= totalTTC && totalTTC > 0) statut = 'soldee'

  db.prepare(`
    UPDATE factures SET
      sous_total_ht = ?, total_tva_10 = ?, total_tva_20 = ?,
      total_ttc = ?, total_paye = ?, solde_restant = ?,
      statut = CASE WHEN statut = 'brouillon' THEN statut ELSE ? END,
      modifie_le = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(sousTotal, tva10, tva20, totalTTC, totalPaye, soldeRestant, statut, factureId)
}

export function registerFacturesHandlers(): void {
  ipcMain.handle('factures:list', (_, filters?: { statut?: string; client_id?: number }) => {
    const db = getDB()
    let query = `
      SELECT f.*, c.nom as client_nom, c.prenom as client_prenom
      FROM factures f LEFT JOIN clients c ON c.id = f.client_id
    `
    const conditions: string[] = []
    const params: unknown[] = []
    if (filters?.statut) { conditions.push('f.statut = ?'); params.push(filters.statut) }
    if (filters?.client_id) { conditions.push('f.client_id = ?'); params.push(filters.client_id) }
    if (conditions.length) query += ' WHERE ' + conditions.join(' AND ')
    query += ' ORDER BY f.cree_le DESC'
    return db.prepare(query).all(...params)
  })

  ipcMain.handle('factures:get', (_, id: number) => {
    const db = getDB()
    const facture = db.prepare(`
      SELECT f.*, c.nom as client_nom, c.prenom as client_prenom,
             c.email as client_email, c.telephone as client_telephone,
             c.adresse as client_adresse, c.ville as client_ville, c.code_postal as client_cp
      FROM factures f LEFT JOIN clients c ON c.id = f.client_id WHERE f.id = ?
    `).get(id)
    const lignes = db.prepare('SELECT * FROM lignes_facture WHERE facture_id = ? ORDER BY ordre').all(id)
    const acomptes = db.prepare('SELECT * FROM acomptes WHERE facture_id = ? ORDER BY date_paiement').all(id)
    return { ...facture as Record<string, unknown>, lignes, acomptes }
  })

  ipcMain.handle('factures:create', (_, data: Record<string, unknown>) => {
    const db = getDB()
    const atelier = db.prepare('SELECT prefixe_facture, compteur_facture FROM atelier WHERE id = 1').get() as {
      prefixe_facture: string; compteur_facture: number
    }
    const next = atelier.compteur_facture + 1
    db.prepare('UPDATE atelier SET compteur_facture = ? WHERE id = 1').run(next)
    const year = new Date().getFullYear()
    const numero = `${atelier.prefixe_facture}-${year}-${String(next).padStart(3, '0')}`

    const echeance = new Date()
    echeance.setDate(echeance.getDate() + 30)

    const result = db.prepare(`
      INSERT INTO factures (numero, client_id, date_echeance, statut, notes, conditions)
      VALUES (?, ?, ?, 'brouillon', ?, ?)
    `).run(numero, data.client_id, echeance.toISOString().split('T')[0], data.notes || null, data.conditions || null)

    return db.prepare('SELECT * FROM factures WHERE id = ?').get(result.lastInsertRowid)
  })

  ipcMain.handle('factures:update', (_, id: number, data: Record<string, unknown>) => {
    const db = getDB()
    db.prepare(`
      UPDATE factures SET
        client_id = @client_id, date_echeance = @date_echeance,
        notes = @notes, conditions = @conditions, modifie_le = CURRENT_TIMESTAMP
      WHERE id = @id
    `).run({ ...data, id })
    return db.prepare('SELECT * FROM factures WHERE id = ?').get(id)
  })

  ipcMain.handle('factures:delete', (_, id: number) => {
    getDB().prepare('DELETE FROM factures WHERE id = ?').run(id)
    return { success: true }
  })

  ipcMain.handle('factures:updateStatut', (_, id: number, statut: string) => {
    getDB().prepare('UPDATE factures SET statut = ?, modifie_le = CURRENT_TIMESTAMP WHERE id = ?').run(statut, id)
    return { success: true }
  })

  ipcMain.handle('factures:saveLignes', (_, factureId: number, lignes: Record<string, unknown>[]) => {
    const db = getDB()
    db.prepare('DELETE FROM lignes_facture WHERE facture_id = ?').run(factureId)

    const insert = db.prepare(`
      INSERT INTO lignes_facture
        (facture_id, produit_id, designation, unite_calcul, largeur_m, hauteur_m,
         quantite, quantite_calculee, prix_unitaire_ht, taux_tva, total_ht, total_ttc, ordre)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)

    for (let i = 0; i < lignes.length; i++) {
      const l = lignes[i]
      const { quantiteCalculee, totalHT, totalTTC } = calcLigne(l)
      insert.run(
        factureId, l.produit_id || null, l.designation, l.unite_calcul,
        l.largeur_m || null, l.hauteur_m || null, l.quantite || 1,
        quantiteCalculee, l.prix_unitaire_ht, l.taux_tva, totalHT, totalTTC, i
      )
    }

    updateFactureTotaux(factureId)
    return db.prepare('SELECT * FROM factures WHERE id = ?').get(factureId)
  })

  ipcMain.handle('factures:getLignes', (_, factureId: number) => {
    return getDB().prepare('SELECT * FROM lignes_facture WHERE facture_id = ? ORDER BY ordre').all(factureId)
  })

  ipcMain.handle('factures:addAcompte', (_, data: Record<string, unknown>) => {
    const db = getDB()
    const result = db.prepare(`
      INSERT INTO acomptes (facture_id, montant, date_paiement, mode_paiement, notes)
      VALUES (@facture_id, @montant, @date_paiement, @mode_paiement, @notes)
    `).run(data)
    updateFactureTotaux(data.facture_id as number)
    return db.prepare('SELECT * FROM acomptes WHERE id = ?').get(result.lastInsertRowid)
  })

  ipcMain.handle('factures:getAcomptes', (_, factureId: number) => {
    return getDB().prepare('SELECT * FROM acomptes WHERE facture_id = ? ORDER BY date_paiement').all(factureId)
  })

  ipcMain.handle('factures:deleteAcompte', (_, id: number) => {
    const db = getDB()
    const acompte = db.prepare('SELECT facture_id FROM acomptes WHERE id = ?').get(id) as { facture_id: number }
    db.prepare('DELETE FROM acomptes WHERE id = ?').run(id)
    if (acompte) updateFactureTotaux(acompte.facture_id)
    return { success: true }
  })
}
