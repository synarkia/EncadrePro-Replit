import { ipcMain } from 'electron'
import * as nodemailer from 'nodemailer'
import * as path from 'path'
import * as fs from 'fs'
import { app } from 'electron'
import { db } from '../db'

function getTransporter(config: any) {
  if (!config.smtp_host || !config.smtp_user || !config.smtp_pass) {
    throw new Error("Configuration SMTP incomplète dans les paramètres.")
  }
  return nodemailer.createTransport({
    host: config.smtp_host,
    port: config.smtp_port || 587,
    secure: config.smtp_port === 465, // true for 465, false for other ports
    auth: {
      user: config.smtp_user,
      pass: config.smtp_pass
    }
  })
}

export function registerEmailHandlers() {
  ipcMain.handle('email:test', async (_, configTest: any) => {
    const transporter = getTransporter(configTest)
    await transporter.verify()
    
    await transporter.sendMail({
      from: `"${configTest.nom_atelier || 'Atelier'}" <${configTest.email || configTest.smtp_user}>`,
      to: configTest.email || configTest.smtp_user,
      subject: "Test de configuration SMTP EncadrePro",
      text: "Bonjour,\n\nCeci est un test de configuration SMTP depuis EncadrePro. Si vous recevez ce message, la configuration est correcte.\n\nCordialement,\nEncadrePro."
    })
    
    return true
  })

  ipcMain.handle('email:sendDevis', async (_, devisId: number, to: string) => {
    const config = db.prepare(`SELECT * FROM atelier_config LIMIT 1`).get() as any
    const devis = db.prepare(`SELECT * FROM devis WHERE id = ?`).get(devisId) as any
    if (!devis) throw new Error("Devis introuvable")

    const pdfPath = path.join(app.getPath('userData'), `Devis_${devis.numero}.pdf`)
    if (!fs.existsSync(pdfPath)) {
      throw new Error("Le PDF du devis n'a pas encore été généré.")
    }

    const transporter = getTransporter(config)

    await transporter.sendMail({
      from: `"${config.nom_atelier || 'Atelier'}" <${config.email || config.smtp_user}>`,
      to,
      subject: `Votre Devis N° ${devis.numero} - ${config.nom_atelier || 'Atelier'}`,
      text: `Bonjour,\n\nVeuillez trouver ci-joint votre devis N° ${devis.numero}.\n\nRestant à votre disposition,\n\nCordialement,\n${config.nom_atelier}`,
      attachments: [
        {
          filename: `Devis_${devis.numero}.pdf`,
          path: pdfPath
        }
      ]
    })
    
    // Update status automatically if it's draft
    if (devis.statut === 'brouillon') {
      db.prepare(`UPDATE devis SET statut = 'envoye' WHERE id = ?`).run(devisId)
    }

    return true
  })

  ipcMain.handle('email:sendFacture', async (_, factureId: number, to: string) => {
    const config = db.prepare(`SELECT * FROM atelier_config LIMIT 1`).get() as any
    const fac = db.prepare(`SELECT * FROM factures WHERE id = ?`).get(factureId) as any
    if (!fac) throw new Error("Facture introuvable")

    const pdfPath = path.join(app.getPath('userData'), `Facture_${fac.numero}.pdf`)
    if (!fs.existsSync(pdfPath)) {
      throw new Error("Le PDF de la facture n'a pas encore été généré.")
    }

    const transporter = getTransporter(config)

    await transporter.sendMail({
      from: `"${config.nom_atelier || 'Atelier'}" <${config.email || config.smtp_user}>`,
      to,
      subject: `Votre Facture N° ${fac.numero} - ${config.nom_atelier || 'Atelier'}`,
      text: `Bonjour,\n\nVeuillez trouver ci-joint votre facture N° ${fac.numero}.\n\nRestant à votre disposition,\n\nCordialement,\n${config.nom_atelier}`,
      attachments: [
        {
          filename: `Facture_${fac.numero}.pdf`,
          path: pdfPath
        }
      ]
    })

    // Update status
    if (fac.statut === 'brouillon') {
      db.prepare(`UPDATE factures SET statut = 'envoyee' WHERE id = ?`).run(factureId)
    }

    return true
  })
}
