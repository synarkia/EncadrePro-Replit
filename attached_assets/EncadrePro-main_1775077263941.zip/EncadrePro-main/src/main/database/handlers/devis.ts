import { ipcMain } from 'electron'
import { getDB } from '../db'

function getNextNumero(type: 'devis'): string {
  const db = getDB()
  const atelier = db.prepare('SELECT prefixe_devis, compteur_devis FROM atelier WHERE id = 1').get() as {
    prefixe_devis: string
    compteur_devis: number
  }
  const next = atelier.compteur_devis + 1
  db.prepare('UPDATE atelier SET compteur_devis = ? WHERE id = 1').run(next)
  const year = new Date().getFullYear()
  return `${atelier.prefixe_devis}-${year}-${String(next).padStart(3, '0')}`
}

function calcLigne(ligne: Record<string, unknown>) {
  const unite = ligne.unite_calcul as string
  const largeur = Number(ligne.largeur_m || 0)
  const hauteur = Number(ligne.hauteur_m || 0)
  const quantite = Number(ligne.quantite || 1)
  const prixHT = Number(ligne.prix_unitaire_ht)
  const tva = Number(ligne.taux_tva)

  let quantiteCalculee: number
  if (unite === 'metre_lineaire') {
    quantiteCalculee = (largeur + hauteur) * 2 * quantite
  } else if (unite === 'metre_carre') {
    quantiteCalculee = largeur * hauteur * quantite
  } else {
    quantiteCalculee = quantite
  }

  const totalHT = quantiteCalculee * prixHT
  const totalTTC = totalHT * (1 + tva / 100)
  return { quantiteCalculee, totalHT, totalTTC }
}

function updateDevisTotaux(devisId: number): void {
  const db = getDB()
  const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ?').all(devisId) as Record<string, number>[]

  let sousTotal = 0, tva10 = 0, tva20 = 0
  for (const l of lignes) {
    sousTotal += l.total_ht
    if (l.taux_tva === 10) tva10 += l.total_ht * 0.1
    else tva20 += l.total_ht * 0.2
  }

  db.prepare(`
    UPDATE devis SET
      sous_total_ht = ?, total_tva_10 = ?, total_tva_20 = ?,
      total_ttc = ?, modifie_le = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(sousTotal, tva10, tva20, sousTotal + tva10 + tva20, devisId)
}

export function registerDevisHandlers(): void {
  ipcMain.handle('devis:list', (_, filters?: { statut?: string; client_id?: number }) => {
    const db = getDB()
    let query = `
      SELECT d.*, c.nom as client_nom, c.prenom as client_prenom
      FROM devis d LEFT JOIN clients c ON c.id = d.client_id
    `
    const conditions: string[] = []
    const params: unknown[] = []
    if (filters?.statut) { conditions.push('d.statut = ?'); params.push(filters.statut) }
    if (filters?.client_id) { conditions.push('d.client_id = ?'); params.push(filters.client_id) }
    if (conditions.length) query += ' WHERE ' + conditions.join(' AND ')
    query += ' ORDER BY d.cree_le DESC'
    return db.prepare(query).all(...params)
  })

  ipcMain.handle('devis:get', (_, id: number) => {
    const db = getDB()
    const devis = db.prepare(`
      SELECT d.*, c.nom as client_nom, c.prenom as client_prenom,
             c.email as client_email, c.telephone as client_telephone,
             c.adresse as client_adresse, c.ville as client_ville, c.code_postal as client_cp
      FROM devis d LEFT JOIN clients c ON c.id = d.client_id WHERE d.id = ?
    `).get(id)
    const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(id)
    return { ...devis as Record<string, unknown>, lignes }
  })

  ipcMain.handle('devis:create', (_, data: Record<string, unknown>) => {
    const db = getDB()
    const numero = getNextNumero('devis')
    const validite = new Date()
    validite.setDate(validite.getDate() + 30)
    const dateValidite = validite.toISOString().split('T')[0]

    const result = db.prepare(`
      INSERT INTO devis (numero, client_id, date_validite, statut, notes, conditions)
      VALUES (?, ?, ?, 'brouillon', ?, ?)
    `).run(numero, data.client_id, dateValidite, data.notes || null, data.conditions || null)

    return db.prepare(`
      SELECT d.*, c.nom as client_nom FROM devis d
      JOIN clients c ON c.id = d.client_id WHERE d.id = ?
    `).get(result.lastInsertRowid)
  })

  ipcMain.handle('devis:update', (_, id: number, data: Record<string, unknown>) => {
    const db = getDB()
    db.prepare(`
      UPDATE devis SET client_id = @client_id, date_validite = @date_validite,
        notes = @notes, conditions = @conditions, modifie_le = CURRENT_TIMESTAMP
      WHERE id = @id
    `).run({ ...data, id })
    return db.prepare('SELECT * FROM devis WHERE id = ?').get(id)
  })

  ipcMain.handle('devis:delete', (_, id: number) => {
    getDB().prepare('DELETE FROM devis WHERE id = ?').run(id)
    return { success: true }
  })

  ipcMain.handle('devis:updateStatut', (_, id: number, statut: string) => {
    getDB().prepare('UPDATE devis SET statut = ?, modifie_le = CURRENT_TIMESTAMP WHERE id = ?').run(statut, id)
    return { success: true }
  })

  ipcMain.handle('devis:saveLignes', (_, devisId: number, lignes: Record<string, unknown>[]) => {
    const db = getDB()
    db.prepare('DELETE FROM lignes_devis WHERE devis_id = ?').run(devisId)

    const insert = db.prepare(`
      INSERT INTO lignes_devis
        (devis_id, produit_id, designation, unite_calcul, largeur_m, hauteur_m,
         quantite, quantite_calculee, prix_unitaire_ht, taux_tva, total_ht, total_ttc, ordre)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)

    for (let i = 0; i < lignes.length; i++) {
      const l = lignes[i]
      const { quantiteCalculee, totalHT, totalTTC } = calcLigne(l)
      insert.run(
        devisId, l.produit_id || null, l.designation, l.unite_calcul,
        l.largeur_m || null, l.hauteur_m || null, l.quantite || 1,
        quantiteCalculee, l.prix_unitaire_ht, l.taux_tva, totalHT, totalTTC, i
      )
    }

    updateDevisTotaux(devisId)
    return db.prepare('SELECT * FROM devis WHERE id = ?').get(devisId)
  })

  ipcMain.handle('devis:getLignes', (_, devisId: number) => {
    return getDB().prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(devisId)
  })

  ipcMain.handle('devis:convertToFacture', (_, id: number) => {
    const db = getDB()
    const devis = db.prepare('SELECT * FROM devis WHERE id = ?').get(id) as Record<string, unknown>
    if (!devis) throw new Error('Devis introuvable')

    const atelier = db.prepare('SELECT prefixe_facture, compteur_facture FROM atelier WHERE id = 1').get() as {
      prefixe_facture: string; compteur_facture: number
    }
    const next = atelier.compteur_facture + 1
    db.prepare('UPDATE atelier SET compteur_facture = ? WHERE id = 1').run(next)
    const year = new Date().getFullYear()
    const numero = `${atelier.prefixe_facture}-${year}-${String(next).padStart(3, '0')}`

    const echeance = new Date()
    echeance.setDate(echeance.getDate() + 30)

    const factureResult = db.prepare(`
      INSERT INTO factures (numero, devis_id, client_id, date_echeance, statut,
        sous_total_ht, total_tva_10, total_tva_20, total_ttc, solde_restant, notes, conditions)
      VALUES (?, ?, ?, ?, 'brouillon', ?, ?, ?, ?, ?, ?, ?)
    `).run(
      numero, id, devis.client_id,
      echeance.toISOString().split('T')[0],
      devis.sous_total_ht, devis.total_tva_10, devis.total_tva_20, devis.total_ttc,
      devis.total_ttc, devis.notes, devis.conditions
    )

    const factureId = factureResult.lastInsertRowid
    const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(id) as Record<string, unknown>[]

    const insertLigne = db.prepare(`
      INSERT INTO lignes_facture
        (facture_id, produit_id, designation, unite_calcul, largeur_m, hauteur_m,
         quantite, quantite_calculee, prix_unitaire_ht, taux_tva, total_ht, total_ttc, ordre)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)

    for (const l of lignes) {
      insertLigne.run(
        factureId, l.produit_id, l.designation, l.unite_calcul,
        l.largeur_m, l.hauteur_m, l.quantite, l.quantite_calculee,
        l.prix_unitaire_ht, l.taux_tva, l.total_ht, l.total_ttc, l.ordre
      )
    }

    db.prepare('UPDATE devis SET statut = ?, facture_id = ?, modifie_le = CURRENT_TIMESTAMP WHERE id = ?').run('converti', factureId, id)
    return { factureId, numero }
  })
}
