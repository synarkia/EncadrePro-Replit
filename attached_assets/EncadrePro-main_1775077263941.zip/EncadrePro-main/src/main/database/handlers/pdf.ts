import { ipcMain, shell, app } from 'electron'
import * as path from 'path'
import * as fs from 'fs'
import { renderToFile } from '@react-pdf/renderer'
import React from 'react'

import { db } from '../db'
import { TemplateDevis } from '../../pdf/TemplateDevis'
import { TemplateFacture } from '../../pdf/TemplateFacture'

export function registerPdfHandlers() {
  ipcMain.handle('generate-pdf-devis', async (_, devisId: number) => {
    // 1. Fetch data
    const devis = db.prepare(`
      SELECT d.*, c.nom as client_nom, c.prenom as client_prenom, c.adresse as client_adresse, 
             c.code_postal as client_cp, c.ville as client_ville
      FROM devis d JOIN clients c ON d.client_id = c.id WHERE d.id = ?
    `).get(devisId) as any

    if (!devis) throw new Error("Devis introuvable")

    const client = { adresse: devis.client_adresse, code_postal: devis.client_cp, ville: devis.client_ville }
    devis.client = client

    const lignes = db.prepare(`SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY id ASC`).all(devisId)
    devis.lignes = lignes

    const config = db.prepare(`SELECT * FROM atelier_config LIMIT 1`).get() || {}

    // 2. Build PDF path
    const pdfPath = path.join(app.getPath('userData'), `Devis_${devis.numero}.pdf`)

    // 3. Render
    await renderToFile(React.createElement(TemplateDevis, { data: devis, config }), pdfPath)

    return pdfPath
  })

  ipcMain.handle('generate-pdf-facture', async (_, factureId: number) => {
    // 1. Fetch data
    const fac = db.prepare(`
      SELECT f.*, c.nom as client_nom, c.prenom as client_prenom, c.adresse as client_adresse, 
             c.code_postal as client_cp, c.ville as client_ville
      FROM factures f JOIN clients c ON f.client_id = c.id WHERE f.id = ?
    `).get(factureId) as any

    if (!fac) throw new Error("Facture introuvable")

    const client = { adresse: fac.client_adresse, code_postal: fac.client_cp, ville: fac.client_ville }
    fac.client = client

    const lignes = db.prepare(`SELECT * FROM lignes_facture WHERE facture_id = ? ORDER BY id ASC`).all(factureId)
    fac.lignes = lignes

    const paiements = db.prepare(`SELECT * FROM paiements WHERE facture_id = ? ORDER BY date_paiement ASC`).all(factureId)
    const config = db.prepare(`SELECT * FROM atelier_config LIMIT 1`).get() || {}

    // 2. Build PDF path
    const pdfPath = path.join(app.getPath('userData'), `Facture_${fac.numero}.pdf`)

    // 3. Render
    await renderToFile(React.createElement(TemplateFacture, { data: fac, config, paiements }), pdfPath)

    return pdfPath
  })

  ipcMain.handle('open-pdf', async (_, pdfPath: string) => {
    if (fs.existsSync(pdfPath)) {
      await shell.openPath(pdfPath)
      return true
    }
    throw new Error("Fichier introuvable : " + pdfPath)
  })
}
