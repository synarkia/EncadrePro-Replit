import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerAtelierHandlers(): void {
  ipcMain.handle('atelier:get', () => {
    const db = getDB()
    return db.prepare('SELECT * FROM atelier WHERE id = 1').get()
  })

  ipcMain.handle('atelier:save', (_, data: Record<string, unknown>) => {
    const db = getDB()
    const fields = Object.keys(data)
      .filter(k => k !== 'id')
      .map(k => `${k} = ?`)
      .join(', ')
    const values = Object.keys(data)
      .filter(k => k !== 'id')
      .map(k => data[k])

    db.prepare(`UPDATE atelier SET ${fields} WHERE id = 1`).run(...values)

    // Register dashboard stats handler here
    return db.prepare('SELECT * FROM atelier WHERE id = 1').get()
  })

  ipcMain.handle('dashboard:getStats', () => {
    const db = getDB()
    const now = new Date()
    const firstOfMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`

    const caMois = (db.prepare(`
      SELECT COALESCE(SUM(total_ttc), 0) as total
      FROM factures
      WHERE statut IN ('envoyee', 'partiellement_payee', 'soldee')
        AND date_creation >= ?
    `).get(firstOfMonth) as { total: number }).total

    const devisEnAttente = db.prepare(`
      SELECT COUNT(*) as n, COALESCE(SUM(total_ttc), 0) as montant
      FROM devis WHERE statut IN ('brouillon', 'envoye')
    `).get() as { n: number; montant: number }

    const facturesImpayees = db.prepare(`
      SELECT COUNT(*) as n, COALESCE(SUM(solde_restant), 0) as montant
      FROM factures WHERE statut IN ('envoyee', 'partiellement_payee')
    `).get() as { n: number; montant: number }

    const nouveauxClients = (db.prepare(`
      SELECT COUNT(*) as n FROM clients WHERE cree_le >= ?
    `).get(firstOfMonth) as { n: number }).n

    return { caMois, devisEnAttente, facturesImpayees, nouveauxClients }
  })

  ipcMain.handle('dashboard:getCAMensuel', () => {
    const db = getDB()
    const rows = db.prepare(`
      SELECT strftime('%Y-%m', date_creation) as mois,
             COALESCE(SUM(total_ttc), 0) as total
      FROM factures
      WHERE statut IN ('envoyee', 'partiellement_payee', 'soldee')
        AND date_creation >= date('now', '-12 months')
      GROUP BY mois
      ORDER BY mois ASC
    `).all()
    return rows
  })

  ipcMain.handle('dashboard:getRecentDevis', () => {
    const db = getDB()
    return db.prepare(`
      SELECT d.*, c.nom as client_nom, c.prenom as client_prenom
      FROM devis d
      LEFT JOIN clients c ON c.id = d.client_id
      ORDER BY d.cree_le DESC LIMIT 5
    `).all()
  })

  ipcMain.handle('dashboard:getRecentFactures', () => {
    const db = getDB()
    return db.prepare(`
      SELECT f.*, c.nom as client_nom, c.prenom as client_prenom
      FROM factures f
      LEFT JOIN clients c ON c.id = f.client_id
      ORDER BY f.cree_le DESC LIMIT 5
    `).all()
  })
}
