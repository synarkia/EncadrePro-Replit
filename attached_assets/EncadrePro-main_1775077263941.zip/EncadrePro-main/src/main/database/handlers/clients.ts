import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerClientsHandlers(): void {
  ipcMain.handle('clients:list', (_, search?: string) => {
    const db = getDB()
    if (search) {
      return db.prepare(`
        SELECT * FROM clients
        WHERE nom LIKE ? OR prenom LIKE ? OR email LIKE ? OR telephone LIKE ?
        ORDER BY nom ASC
      `).all(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`)
    }
    return db.prepare('SELECT * FROM clients ORDER BY nom ASC').all()
  })

  ipcMain.handle('clients:get', (_, id: number) => {
    return getDB().prepare('SELECT * FROM clients WHERE id = ?').get(id)
  })

  ipcMain.handle('clients:create', (_, data: Record<string, unknown>) => {
    const db = getDB()
    const result = db.prepare(`
      INSERT INTO clients (nom, prenom, email, telephone, adresse, ville, code_postal, notes)
      VALUES (@nom, @prenom, @email, @telephone, @adresse, @ville, @code_postal, @notes)
    `).run(data)
    return db.prepare('SELECT * FROM clients WHERE id = ?').get(result.lastInsertRowid)
  })

  ipcMain.handle('clients:update', (_, id: number, data: Record<string, unknown>) => {
    const db = getDB()
    db.prepare(`
      UPDATE clients SET
        nom = @nom, prenom = @prenom, email = @email,
        telephone = @telephone, adresse = @adresse, ville = @ville,
        code_postal = @code_postal, notes = @notes,
        modifie_le = CURRENT_TIMESTAMP
      WHERE id = @id
    `).run({ ...data, id })
    return db.prepare('SELECT * FROM clients WHERE id = ?').get(id)
  })

  ipcMain.handle('clients:delete', (_, id: number) => {
    getDB().prepare('DELETE FROM clients WHERE id = ?').run(id)
    return { success: true }
  })

  ipcMain.handle('clients:getStats', (_, id: number) => {
    const db = getDB()
    const devisCount = (db.prepare('SELECT COUNT(*) as n FROM devis WHERE client_id = ?').get(id) as { n: number }).n
    const facturesCount = (db.prepare('SELECT COUNT(*) as n FROM factures WHERE client_id = ?').get(id) as { n: number }).n
    const caTotal = (db.prepare(`
      SELECT COALESCE(SUM(total_ttc), 0) as total FROM factures
      WHERE client_id = ? AND statut IN ('envoyee', 'partiellement_payee', 'soldee')
    `).get(id) as { total: number }).total
    const devis = db.prepare('SELECT * FROM devis WHERE client_id = ? ORDER BY cree_le DESC').all(id)
    const factures = db.prepare('SELECT * FROM factures WHERE client_id = ? ORDER BY cree_le DESC').all(id)
    return { devisCount, facturesCount, caTotal, devis, factures }
  })
}
