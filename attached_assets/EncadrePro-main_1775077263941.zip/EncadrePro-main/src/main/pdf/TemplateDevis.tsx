import React from 'react'
import { Document, Page, Text, View, StyleSheet, Font } from '@react-pdf/renderer'

// Define styles
const styles = StyleSheet.create({
  page: { padding: 40, fontSize: 10, fontFamily: 'Helvetica', color: '#1B1B1B' },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 40 },
  companyBlock: { maxWidth: 250 },
  companyName: { fontSize: 16, fontWeight: 'bold', marginBottom: 4 },
  clientBlock: { maxWidth: 250, padding: 15, backgroundColor: '#FAFAFA', borderRadius: 4 },
  clientTitle: { fontSize: 10, color: '#666', marginBottom: 4 },
  clientName: { fontSize: 12, fontWeight: 'bold', marginBottom: 2 },
  
  docInfo: { marginBottom: 30 },
  docTitle: { fontSize: 20, fontWeight: 'bold', letterSpacing: 1, marginBottom: 8 },
  
  table: { width: '100%', border: '1pt solid #E5E5E5', marginBottom: 20 },
  tableHeaderRow: { flexDirection: 'row', backgroundColor: '#F5F5F5', borderBottom: '1pt solid #E5E5E5', padding: 8, fontWeight: 'bold' },
  tableRow: { flexDirection: 'row', borderBottom: '1pt solid #EEEEEE', padding: 8 },
  col1: { width: '40%' },
  col2: { width: '15%', textAlign: 'center' },
  col3: { width: '15%', textAlign: 'right' },
  col4: { width: '10%', textAlign: 'right' },
  col5: { width: '20%', textAlign: 'right' },
  
  totalsContainer: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 10 },
  totalsBox: { width: 200 },
  totalsRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  totalTtRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderTop: '1pt solid #000', marginTop: 4, fontWeight: 'bold', fontSize: 12 },
  
  footer: { position: 'absolute', bottom: 30, left: 40, right: 40, textAlign: 'center', color: '#888', fontSize: 8, borderTop: '1pt solid #EEEEEE', paddingTop: 10 },
  notes: { marginTop: 30, fontSize: 9, color: '#444' }
})

const formatCurrency = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n)

export const TemplateDevis = ({ data, config }: { data: any, config: any }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      
      <View style={styles.header}>
        <View style={styles.companyBlock}>
          <Text style={styles.companyName}>{config.nom_atelier || 'Mon Atelier'}</Text>
          <Text>{config.adresse}</Text>
          {config.telephone && <Text>Tél: {config.telephone}</Text>}
          {config.email && <Text>Email: {config.email}</Text>}
          {config.siret && <Text>SIRET: {config.siret}</Text>}
        </View>

        <View style={styles.clientBlock}>
          <Text style={styles.clientTitle}>Adressez à :</Text>
          <Text style={styles.clientName}>{data.client_prenom} {data.client_nom}</Text>
          <Text>{data.client.adresse}</Text>
          <Text>{data.client.code_postal} {data.client.ville}</Text>
        </View>
      </View>

      <View style={styles.docInfo}>
        <Text style={styles.docTitle}>DEVIS N° {data.numero}</Text>
        <Text>Date de création : {new Date(data.cree_le).toLocaleDateString('fr-FR')}</Text>
        <Text>Date de validité : {new Date(data.date_validite).toLocaleDateString('fr-FR')}</Text>
      </View>

      <View style={styles.table}>
        <View style={styles.tableHeaderRow}>
          <Text style={styles.col1}>Désignation</Text>
          <Text style={styles.col2}>Quantité</Text>
          <Text style={styles.col3}>P.U. HT</Text>
          <Text style={styles.col4}>TVA</Text>
          <Text style={styles.col5}>Total HT</Text>
        </View>
        
        {data.lignes.map((l: any, i: number) => (
          <View style={styles.tableRow} key={i}>
            <Text style={styles.col1}>{l.designation}</Text>
            <Text style={styles.col2}>{l.quantite_calculee}</Text>
            <Text style={styles.col3}>{formatCurrency(l.prix_unitaire_ht)}</Text>
            <Text style={styles.col4}>{l.taux_tva}%</Text>
            <Text style={styles.col5}>{formatCurrency(l.quantite_calculee * l.prix_unitaire_ht)}</Text>
          </View>
        ))}
      </View>

      <View style={styles.totalsContainer}>
        <View style={styles.totalsBox}>
          <View style={styles.totalsRow}>
             <Text>Sous-total HT</Text>
             <Text>{formatCurrency(data.sous_total_ht)}</Text>
          </View>
          {data.total_tva_20 > 0 && (
             <View style={styles.totalsRow}>
               <Text>TVA 20%</Text>
               <Text>{formatCurrency(data.total_tva_20)}</Text>
             </View>
          )}
          {data.total_tva_10 > 0 && (
             <View style={styles.totalsRow}>
               <Text>TVA 10%</Text>
               <Text>{formatCurrency(data.total_tva_10)}</Text>
             </View>
          )}
          <View style={styles.totalTtRow}>
             <Text>TOTAL TTC</Text>
             <Text>{formatCurrency(data.total_ttc)}</Text>
          </View>
        </View>
      </View>

      {data.notes && (
        <View style={styles.notes}>
          <Text style={{ fontWeight: 'bold', marginBottom: 4 }}>Notes :</Text>
          <Text>{data.notes}</Text>
        </View>
      )}

      <View style={styles.footer}>
        {config.rib && <Text style={{ marginBottom: 4 }}>RIB: {config.rib}</Text>}
        {config.mentions_legales && <Text>{config.mentions_legales}</Text>}
        <Text style={{ marginTop: 8 }}>Devis généré le {new Date().toLocaleDateString('fr-FR')} par {config.nom_atelier || 'EncadrePro'}</Text>
      </View>
      
    </Page>
  </Document>
)
