import { contextBridge, ipcRenderer } from 'electron'

// Expose safe IPC bridge to renderer
const api = {
  // Atelier
  atelier: {
    get: () => ipcRenderer.invoke('atelier:get'),
    save: (data: unknown) => ipcRenderer.invoke('atelier:save', data),
  },
  // Clients
  clients: {
    list: (search?: string) => ipcRenderer.invoke('clients:list', search),
    get: (id: number) => ipcRenderer.invoke('clients:get', id),
    create: (data: unknown) => ipcRenderer.invoke('clients:create', data),
    update: (id: number, data: unknown) => ipcRenderer.invoke('clients:update', id, data),
    delete: (id: number) => ipcRenderer.invoke('clients:delete', id),
    getStats: (id: number) => ipcRenderer.invoke('clients:getStats', id),
  },
  // Produits
  produits: {
    list: (categorie?: string) => ipcRenderer.invoke('produits:list', categorie),
    get: (id: number) => ipcRenderer.invoke('produits:get', id),
    create: (data: unknown) => ipcRenderer.invoke('produits:create', data),
    update: (id: number, data: unknown) => ipcRenderer.invoke('produits:update', id, data),
    delete: (id: number) => ipcRenderer.invoke('produits:delete', id),
    toggleActif: (id: number) => ipcRenderer.invoke('produits:toggleActif', id),
  },
  // Devis
  devis: {
    list: (filters?: unknown) => ipcRenderer.invoke('devis:list', filters),
    get: (id: number) => ipcRenderer.invoke('devis:get', id),
    create: (data: unknown) => ipcRenderer.invoke('devis:create', data),
    update: (id: number, data: unknown) => ipcRenderer.invoke('devis:update', id, data),
    delete: (id: number) => ipcRenderer.invoke('devis:delete', id),
    updateStatut: (id: number, statut: string) => ipcRenderer.invoke('devis:updateStatut', id, statut),
    convertToFacture: (id: number) => ipcRenderer.invoke('devis:convertToFacture', id),
    saveLignes: (devisId: number, lignes: unknown[]) => ipcRenderer.invoke('devis:saveLignes', devisId, lignes),
    getLignes: (devisId: number) => ipcRenderer.invoke('devis:getLignes', devisId),
  },
  // Factures
  factures: {
    list: (filters?: unknown) => ipcRenderer.invoke('factures:list', filters),
    get: (id: number) => ipcRenderer.invoke('factures:get', id),
    create: (data: unknown) => ipcRenderer.invoke('factures:create', data),
    update: (id: number, data: unknown) => ipcRenderer.invoke('factures:update', id, data),
    delete: (id: number) => ipcRenderer.invoke('factures:delete', id),
    updateStatut: (id: number, statut: string) => ipcRenderer.invoke('factures:updateStatut', id, statut),
    saveLignes: (factureId: number, lignes: unknown[]) => ipcRenderer.invoke('factures:saveLignes', factureId, lignes),
    getLignes: (factureId: number) => ipcRenderer.invoke('factures:getLignes', factureId),
    addAcompte: (data: unknown) => ipcRenderer.invoke('factures:addAcompte', data),
    getAcomptes: (factureId: number) => ipcRenderer.invoke('factures:getAcomptes', factureId),
    deleteAcompte: (id: number) => ipcRenderer.invoke('factures:deleteAcompte', id),
  },
  // Dashboard
  dashboard: {
    getStats: () => ipcRenderer.invoke('dashboard:getStats'),
    getCAMensuel: () => ipcRenderer.invoke('dashboard:getCAMensuel'),
    getRecentDevis: () => ipcRenderer.invoke('dashboard:getRecentDevis'),
    getRecentFactures: () => ipcRenderer.invoke('dashboard:getRecentFactures'),
  },
  // PDF — generation is done in renderer process (React-PDF)
  pdf: {
    generateDevis: (devisId: number) => ipcRenderer.invoke('pdf:generateDevis', devisId),
    generateFacture: (factureId: number) => ipcRenderer.invoke('pdf:generateFacture', factureId),
    // Renderer listens for requests from main process
    onGenerateRequest: (cb: (payload: { requestId: string; type: string; data: Record<string, unknown> }) => void) => {
      const handler = (_: Electron.IpcRendererEvent, payload: unknown) => cb(payload as { requestId: string; type: string; data: Record<string, unknown> })
      ipcRenderer.on('pdf:generate-request', handler)
      return () => ipcRenderer.off('pdf:generate-request', handler)
    },
    // Renderer sends bytes back to main
    sendBytesResponse: (payload: { requestId: string; bytes?: number[]; error?: string }) => {
      ipcRenderer.send('pdf:bytes-response', payload)
    },
  },
  // Email
  email: {
    sendDevis: (devisId: number, to: string) => ipcRenderer.invoke('email:sendDevis', devisId, to),
    sendFacture: (factureId: number, to: string) => ipcRenderer.invoke('email:sendFacture', factureId, to),
    test: (config: unknown) => ipcRenderer.invoke('email:test', config),
  },
  // Dialog & Shell
  dialog: {
    showSaveDialog: (options: unknown) => ipcRenderer.invoke('dialog:showSaveDialog', options),
    showOpenDialog: (options: unknown) => ipcRenderer.invoke('dialog:showOpenDialog', options),
  },
  shell: {
    openPath: (path: string) => ipcRenderer.invoke('shell:openPath', path),
  },
}

contextBridge.exposeInMainWorld('api', api)

export type API = typeof api
