import React from 'react'
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer'

const styles = StyleSheet.create({
  page: { padding: 40, fontSize: 10, fontFamily: 'Helvetica', color: '#1B1B1B' },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 40 },
  companyBlock: { maxWidth: 250 },
  companyName: { fontSize: 16, fontWeight: 'bold', marginBottom: 4 },
  clientBlock: { maxWidth: 250, padding: 15, backgroundColor: '#FAFAFA', borderRadius: 4 },
  clientTitle: { fontSize: 10, color: '#666', marginBottom: 4 },
  clientName: { fontSize: 12, fontWeight: 'bold', marginBottom: 2 },
  docInfo: { marginBottom: 30 },
  docTitle: { fontSize: 20, fontWeight: 'bold', letterSpacing: 1, marginBottom: 8 },
  table: { width: '100%', borderWidth: 1, borderColor: '#E5E5E5', marginBottom: 20 },
  tableHeaderRow: { flexDirection: 'row', backgroundColor: '#F5F5F5', borderBottomWidth: 1, borderBottomColor: '#E5E5E5', padding: 8, fontWeight: 'bold' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: '#EEEEEE', padding: 8 },
  col1: { width: '40%' },
  col2: { width: '15%', textAlign: 'center' },
  col3: { width: '15%', textAlign: 'right' },
  col4: { width: '10%', textAlign: 'right' },
  col5: { width: '20%', textAlign: 'right' },
  totalsContainer: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 10 },
  totalsBox: { width: 200 },
  totalsRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  totalTtRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6, borderTopWidth: 1, borderTopColor: '#000', marginTop: 4, fontWeight: 'bold', fontSize: 12 },
  footer: { position: 'absolute', bottom: 30, left: 40, right: 40, textAlign: 'center', color: '#888', fontSize: 8, borderTopWidth: 1, borderTopColor: '#EEEEEE', paddingTop: 10 },
  notes: { marginTop: 30, fontSize: 9, color: '#444' }
})

const fmt = (n: number) => new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(n ?? 0)

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const TemplateDevis = ({ data, atelier }: { data: any; atelier: any }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.header}>
        <View style={styles.companyBlock}>
          <Text style={styles.companyName}>{atelier?.nom || 'Mon Atelier d\'Encadrement'}</Text>
          {atelier?.adresse && <Text>{atelier.adresse}</Text>}
          {atelier?.code_postal && <Text>{atelier.code_postal} {atelier.ville}</Text>}
          {atelier?.telephone && <Text>Tél : {atelier.telephone}</Text>}
          {atelier?.email && <Text>Email : {atelier.email}</Text>}
          {atelier?.siret && <Text>SIRET : {atelier.siret}</Text>}
        </View>
        <View style={styles.clientBlock}>
          <Text style={styles.clientTitle}>Adressé à :</Text>
          <Text style={styles.clientName}>{data.client_prenom} {data.client_nom}</Text>
          {data.client_adresse && <Text>{data.client_adresse}</Text>}
          {data.client_cp && <Text>{data.client_cp} {data.client_ville}</Text>}
          {data.client_email && <Text>{data.client_email}</Text>}
        </View>
      </View>

      <View style={styles.docInfo}>
        <Text style={styles.docTitle}>DEVIS N° {data.numero}</Text>
        <Text>Date : {new Date(data.cree_le).toLocaleDateString('fr-FR')}</Text>
        <Text>Valable jusqu'au : {new Date(data.date_validite).toLocaleDateString('fr-FR')}</Text>
      </View>

      <View style={styles.table}>
        <View style={styles.tableHeaderRow}>
          <Text style={styles.col1}>Désignation</Text>
          <Text style={styles.col2}>Qté calculée</Text>
          <Text style={styles.col3}>P.U. HT</Text>
          <Text style={styles.col4}>TVA</Text>
          <Text style={styles.col5}>Total HT</Text>
        </View>
        {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
        {(data.lignes || []).map((l: any, i: number) => (
          <View style={styles.tableRow} key={i}>
            <Text style={styles.col1}>{l.designation}</Text>
            <Text style={styles.col2}>{Number(l.quantite_calculee).toFixed(2)}</Text>
            <Text style={styles.col3}>{fmt(l.prix_unitaire_ht)}</Text>
            <Text style={styles.col4}>{l.taux_tva}%</Text>
            <Text style={styles.col5}>{fmt(l.total_ht)}</Text>
          </View>
        ))}
      </View>

      <View style={styles.totalsContainer}>
        <View style={styles.totalsBox}>
          <View style={styles.totalsRow}><Text>Sous-total HT</Text><Text>{fmt(data.sous_total_ht)}</Text></View>
          {Number(data.total_tva_10) > 0 && <View style={styles.totalsRow}><Text>TVA 10%</Text><Text>{fmt(data.total_tva_10)}</Text></View>}
          {Number(data.total_tva_20) > 0 && <View style={styles.totalsRow}><Text>TVA 20%</Text><Text>{fmt(data.total_tva_20)}</Text></View>}
          <View style={styles.totalTtRow}><Text>TOTAL TTC</Text><Text>{fmt(data.total_ttc)}</Text></View>
        </View>
      </View>

      {data.notes && (
        <View style={styles.notes}>
          <Text style={{ fontWeight: 'bold', marginBottom: 4 }}>Notes :</Text>
          <Text>{data.notes}</Text>
        </View>
      )}
      {data.conditions && (
        <View style={[styles.notes, { marginTop: 10 }]}>
          <Text style={{ fontWeight: 'bold', marginBottom: 4 }}>Conditions :</Text>
          <Text>{data.conditions}</Text>
        </View>
      )}

      <View style={styles.footer}>
        {atelier?.rib && <Text style={{ marginBottom: 4 }}>RIB / IBAN : {atelier.rib}</Text>}
        {atelier?.mentions_legales && <Text>{atelier.mentions_legales}</Text>}
        <Text style={{ marginTop: 6 }}>Devis généré le {new Date().toLocaleDateString('fr-FR')} • EncadrePro v1.1</Text>
      </View>
    </Page>
  </Document>
)
