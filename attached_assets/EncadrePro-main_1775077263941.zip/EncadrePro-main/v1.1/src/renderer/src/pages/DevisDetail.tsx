import React, { useEffect, useState, useMemo } from 'react'
import { ArrowLeft, Save, Edit, Trash2, Download, RefreshCw, CheckCircle, XCircle } from 'lucide-react'
import { useDevisStore, Devis, LigneDevis } from '../store/useDevisStore'
import { useProduitsStore } from '../store/useProduitsStore'
import { useUIStore } from '../store/useUIStore'
import { Button } from '../components/ui/Button'
import { GlassCard } from '../components/ui/GlassCard'
import { Badge } from '../components/ui/Badge'
import { LigneDevisEditor } from '../components/domain/LigneDevisEditor'
import { TotauxPanel } from '../components/domain/TotauxPanel'
import { Textarea } from '../components/ui/Input'

interface DevisDetailProps {
  devisId: number
  onBack: () => void
}

const DevisDetail: React.FC<DevisDetailProps> = ({ devisId, onBack }) => {
  const { devis, saveLignes, updateStatut } = useDevisStore()
  const { fetchProduits } = useProduitsStore()
  const { addToast } = useUIStore()

  const doc = devis.find(d => d.id === devisId)
  
  const [lignes, setLignes] = useState<LigneDevis[]>([])
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  // Computed totals for preview
  const previewTotaux = useMemo(() => {
    let ht = 0, tva10 = 0, tva20 = 0
    lignes.forEach(l => {
      const q = l.quantite_calculee || 1
      const pht = q * l.prix_unitaire_ht
      ht += pht
      if (l.taux_tva === 20) tva20 += pht * 0.20
      else if (l.taux_tva === 10) tva10 += pht * 0.10
      else if (l.taux_tva === 5.5) tva10 += pht * 0.055 // Grouped for simplicity if needed, but UI uses exact names. Wait, logic does simple sum.
    })
    return {
      sous_total_ht: ht,
      total_tva_10: tva10,
      total_tva_20: tva20,
      total_ttc: ht + tva10 + tva20
    }
  }, [lignes])

  useEffect(() => {
    fetchProduits()
    async function fetchLignes() {
      try {
        // @ts-ignore
        const lgs = (await window.api.devis.getLignes(devisId)) as unknown as LigneDevis[]
        setLignes(lgs)
      } catch (err) {
        addToast({ type: 'error', message: "Erreur lors du chargement des lignes" })
      }
    }
    fetchLignes()
  }, [devisId, fetchProduits, addToast])

  if (!doc) return <div className="p-8 text-text-muted">Document introuvable.</div>

  const handleSaveLignes = async () => {
    setIsSaving(true)
    try {
      if (lignes.length === 0) {
        addToast({ type: 'error', message: "Le devis doit contenir au moins une ligne." })
        return
      }
      await saveLignes(doc.id, lignes)
      addToast({ type: 'success', message: "Devis sauvegardé et recalculé" })
      setIsEditing(false)
    } catch (err: any) {
      addToast({ type: 'error', message: err.message || "Erreur lors de la sauvegarde" })
    } finally {
      setIsSaving(false)
    }
  }

  const handleStatut = async (s: string) => {
    try {
      await updateStatut(doc.id, s)
      addToast({ type: 'success', message: `Statut passé à : ${s}` })
    } catch {
      addToast({ type: 'error', message: "Erreur lors du changement de statut" })
    }
  }

  const isLocked = doc.statut === 'accepte' || doc.statut === 'converti'

  return (
    <div className="flex flex-col gap-6 pb-10">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-4">
          <Button variant="secondary" size="icon" onClick={onBack} title="Retour"><ArrowLeft className="w-5 h-5" /></Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-24px font-bold text-text-primary">Devis {doc.numero}</h1>
              <Badge variant={doc.statut}>{doc.statut}</Badge>
            </div>
            <p className="text-sm text-text-muted">
              Pour <span className="font-medium text-text-secondary">{doc.client_prenom} {doc.client_nom}</span> • Créé le {new Date(doc.cree_le).toLocaleDateString('fr-FR')}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
           {!isLocked && (
             <>
               {doc.statut === 'brouillon' && <Button variant="secondary" onClick={() => handleStatut('envoye')}><RefreshCw className="w-4 h-4 mr-2"/> Marquer Envoyé</Button>}
               {doc.statut === 'envoye' && (
                 <>
                   <Button variant="ghost" className="text-success hover:bg-success/10 hover:text-success" onClick={() => handleStatut('accepte')}><CheckCircle className="w-4 h-4 mr-2"/>Accepté</Button>
                   <Button variant="ghost" className="text-danger hover:bg-danger/10 hover:text-danger" onClick={() => handleStatut('refuse')}><XCircle className="w-4 h-4 mr-2"/>Refusé</Button>
                 </>
               )}
             </>
           )}
            <Button variant="secondary" onClick={() => {
              // @ts-ignore
              window.api.pdf.generateDevis(doc.id).catch((e:any) => addToast({type: 'error', message: 'Erreur PDF : '+e.message}))
            }}>
             <Download className="w-4 h-4 mr-2" /> PDF
           </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="col-span-1 lg:col-span-3 flex flex-col gap-6">
          <GlassCard className="p-0 overflow-hidden flex flex-col">
            <div className="p-4 border-b border-glass-border flex justify-between items-center bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-primary">Lignes de prestation</h3>
              {!isLocked && !isEditing && (
                <Button variant="ghost" size="sm" onClick={() => setIsEditing(true)}><Edit className="w-4 h-4 mr-2" /> Modifier</Button>
              )}
            </div>
            <div className="p-4">
              <LigneDevisEditor 
                lignes={lignes} 
                onChange={setLignes} 
                disabled={!isEditing} 
              />
            </div>
            {isEditing && (
              <div className="p-4 bg-bg-secondary border-t border-glass-border flex justify-end gap-3">
                <Button variant="secondary" onClick={() => setIsEditing(false)}>Annuler</Button>
                <Button variant="primary" onClick={handleSaveLignes} isLoading={isSaving}><Save className="w-4 h-4 mr-2" /> Enregistrer les lignes</Button>
              </div>
            )}
          </GlassCard>

          <div className="grid grid-cols-2 gap-6">
            <GlassCard>
              <h4 className="text-sm font-semibold text-text-muted uppercase mb-3">Notes & Conditions</h4>
              <p className="text-sm min-h-[100px] text-text-primary whitespace-pre-wrap">{doc.notes || 'Aucune note.'}</p>
            </GlassCard>
          </div>
        </div>

        <div className="col-span-1">
          <GlassCard className="sticky top-6 p-0 overflow-hidden">
            <div className="p-4 border-b border-glass-border bg-glass-hover/30">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-text-primary">Résumé financier</h3>
            </div>
            <div className="p-4 pb-6">
              <TotauxPanel 
                sous_total_ht={isEditing ? previewTotaux.sous_total_ht : doc.sous_total_ht}
                total_tva_10={isEditing ? previewTotaux.total_tva_10 : doc.total_tva_10}
                total_tva_20={isEditing ? previewTotaux.total_tva_20 : doc.total_tva_20}
                total_ttc={isEditing ? previewTotaux.total_ttc : doc.total_ttc}
              />
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  )
}

export default DevisDetail
