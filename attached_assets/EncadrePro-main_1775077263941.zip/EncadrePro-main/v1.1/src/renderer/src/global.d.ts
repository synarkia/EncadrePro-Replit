// Déclaration globale de l'API exposée par le preload Electron
// Mise à jour automatiquement en sync avec src/preload/index.ts

interface PdfGenerateRequest {
  requestId: string
  type: 'devis' | 'facture'
  data: Record<string, unknown>
}

interface WindowAPI {
  atelier: {
    get: () => Promise<Record<string, unknown>>
    save: (data: unknown) => Promise<Record<string, unknown>>
  }
  clients: {
    list: (search?: string) => Promise<Record<string, unknown>[]>
    get: (id: number) => Promise<Record<string, unknown>>
    create: (data: unknown) => Promise<Record<string, unknown>>
    update: (id: number, data: unknown) => Promise<Record<string, unknown>>
    delete: (id: number) => Promise<{ success: boolean }>
    getStats: (id: number) => Promise<Record<string, unknown>>
  }
  produits: {
    list: (categorie?: string) => Promise<Record<string, unknown>[]>
    get: (id: number) => Promise<Record<string, unknown>>
    create: (data: unknown) => Promise<Record<string, unknown>>
    update: (id: number, data: unknown) => Promise<Record<string, unknown>>
    delete: (id: number) => Promise<{ success: boolean }>
    toggleActif: (id: number) => Promise<Record<string, unknown>>
  }
  devis: {
    list: (filters?: unknown) => Promise<Record<string, unknown>[]>
    get: (id: number) => Promise<Record<string, unknown>>
    create: (data: unknown) => Promise<Record<string, unknown>>
    update: (id: number, data: unknown) => Promise<Record<string, unknown>>
    delete: (id: number) => Promise<{ success: boolean }>
    updateStatut: (id: number, statut: string) => Promise<{ success: boolean }>
    convertToFacture: (id: number) => Promise<{ factureId: number; numero: string }>
    saveLignes: (devisId: number, lignes: unknown[]) => Promise<Record<string, unknown>>
    getLignes: (devisId: number) => Promise<Record<string, unknown>[]>
  }
  factures: {
    list: (filters?: unknown) => Promise<Record<string, unknown>[]>
    get: (id: number) => Promise<Record<string, unknown>>
    create: (data: unknown) => Promise<Record<string, unknown>>
    update: (id: number, data: unknown) => Promise<Record<string, unknown>>
    delete: (id: number) => Promise<{ success: boolean }>
    updateStatut: (id: number, statut: string) => Promise<{ success: boolean }>
    saveLignes: (factureId: number, lignes: unknown[]) => Promise<Record<string, unknown>>
    getLignes: (factureId: number) => Promise<Record<string, unknown>[]>
    addAcompte: (data: unknown) => Promise<Record<string, unknown>>
    getAcomptes: (factureId: number) => Promise<Record<string, unknown>[]>
    deleteAcompte: (id: number) => Promise<{ success: boolean }>
  }
  dashboard: {
    getStats: () => Promise<Record<string, unknown>>
    getCAMensuel: () => Promise<Record<string, unknown>[]>
    getRecentDevis: () => Promise<Record<string, unknown>[]>
    getRecentFactures: () => Promise<Record<string, unknown>[]>
  }
  pdf: {
    generateDevis: (devisId: number) => Promise<{ success: boolean; path: string }>
    generateFacture: (factureId: number) => Promise<{ success: boolean; path: string }>
    onGenerateRequest: (cb: (payload: PdfGenerateRequest) => void) => () => void
    sendBytesResponse: (payload: { requestId: string; bytes?: number[]; error?: string }) => void
  }
  email: {
    sendDevis: (devisId: number, to: string) => Promise<{ success: boolean }>
    sendFacture: (factureId: number, to: string) => Promise<{ success: boolean }>
    test: (config: unknown) => Promise<{ success: boolean }>
  }
  dialog: {
    showSaveDialog: (options: unknown) => Promise<unknown>
    showOpenDialog: (options: unknown) => Promise<unknown>
  }
  shell: {
    openPath: (path: string) => Promise<void>
  }
}

declare global {
  interface Window {
    api: WindowAPI
  }
}

export {}
