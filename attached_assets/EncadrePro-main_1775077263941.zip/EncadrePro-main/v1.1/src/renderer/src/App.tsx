import { AppShell } from './components/layout/AppShell'
import { PdfWorker } from './components/PdfWorker'

export default function App() {
  return (
    <>
      <PdfWorker />
      <AppShell />
    </>
  )
}
