import { create } from 'zustand'

export interface Atelier {
  id: number
  nom: string
  siret: string | null
  adresse: string | null
  telephone: string | null
  email: string | null
  logo_path: string | null
  conditions_generales: string | null
  prefixe_devis: string
  prefixe_facture: string
  tva_defaut: number
  email_template: string | null
  smtp_host: string | null
  smtp_port: number | null
  smtp_user: string | null
  smtp_pass: string | null
  rib: string | null
}

interface AtelierState {
  config: Atelier | null
  isLoading: boolean
  fetchConfig: () => Promise<void>
  saveConfig: (data: Partial<Atelier>) => Promise<void>
}

export const useAtelierStore = create<AtelierState>((set) => ({
  config: null,
  isLoading: false,

  fetchConfig: async () => {
    set({ isLoading: true })
    try {
      // @ts-ignore
      const data = await window.api.atelier.get()
      set({ config: data })
    } catch (err) {
      console.error('[fetchConfig]', err)
    } finally {
      set({ isLoading: false })
    }
  },

  saveConfig: async (data) => {
    try {
      // @ts-ignore
      const updated = await window.api.atelier.save(data)
      set({ config: updated })
    } catch (err) {
      console.error('[saveConfig]', err)
      throw err
    }
  }
}))
