import { create } from 'zustand'

export interface Acompte {
  id: number
  facture_id: number
  numero_facture_acompte: string | null
  montant: number
  date_paiement: string
  mode_paiement: string | null
  notes: string | null
}

export interface Facture {
  id: number
  numero: string
  devis_id: number | null
  client_id: number
  client_nom?: string
  client_prenom?: string
  date_creation: string
  date_echeance: string | null
  statut: 'brouillon' | 'envoyee' | 'partiellement_payee' | 'soldee' | 'annulee' | 'default'
  sous_total_ht: number
  total_tva_10: number
  total_tva_20: number
  total_ttc: number
  total_paye: number
  solde_restant: number
  total_restant: number // UI name
  notes: string | null
  conditions: string | null
  cree_le: string
  modifie_le: string
}

interface FacturesState {
  factures: Facture[]
  isLoading: boolean
  fetchFactures: (filters?: { statut?: string; client_id?: number }) => Promise<void>
  createFacture: (clientId: number, notes?: string) => Promise<Facture>
  updateStatut: (id: number, statut: string) => Promise<void>
  deleteFacture: (id: number) => Promise<void>
  addPaiement: (factureId: number, data: { montant: number; mode_paiement: string; notes: string | null }) => Promise<void>
}

export const useFacturesStore = create<FacturesState>((set) => ({
  factures: [],
  isLoading: false,

  fetchFactures: async (filters) => {
    set({ isLoading: true })
    try {
      const raw = (await window.api.factures.list(filters)) as unknown as Facture[]
      const data = raw.map(f => ({ ...f, total_restant: f.solde_restant }))
      set({ factures: data })
    } finally {
      set({ isLoading: false })
    }
  },

  createFacture: async (client_id, notes) => {
    // @ts-ignore
    const f = (await window.api.factures.create({ client_id, notes })) as unknown as Facture
    const newFac = { ...f, total_restant: f.solde_restant }
    set((state) => ({ factures: [newFac, ...state.factures] }))
    return newFac
  },

  updateStatut: async (id, statut) => {
    // @ts-ignore
    await window.api.factures.updateStatut(id, statut)
    set((state) => ({
      factures: state.factures.map(f => f.id === id ? { ...f, statut } : f) as Facture[]
    }))
  },

  deleteFacture: async (id) => {
    // @ts-ignore
    await window.api.factures.delete(id)
    set((state) => ({ factures: state.factures.filter(f => f.id !== id) }))
  },

  addPaiement: async (factureId, data) => {
    // @ts-ignore
    await window.api.factures.addAcompte({ facture_id: factureId, ...data })
    // Refresh factures list to get new totals from DB
    // @ts-ignore
    const raw = (await window.api.factures.list()) as unknown as Facture[]
    const factures = raw.map(f => ({ ...f, total_restant: f.solde_restant }))
    set({ factures })
  }
}))
