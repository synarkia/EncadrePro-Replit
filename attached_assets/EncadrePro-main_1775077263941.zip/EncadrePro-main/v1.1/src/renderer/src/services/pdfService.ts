// src/renderer/src/services/pdfService.ts
// Ce service est appelé depuis le preload/main via ipcRenderer
// Il génère des PDFs côté renderer (là où React-PDF peut fonctionner)

import { pdf } from '@react-pdf/renderer'
import { createElement } from 'react'
import { TemplateDevisDoc } from '@renderer/pdf/TemplateDevisDoc'
import { TemplateFactureDoc } from '@renderer/pdf/TemplateFactureDoc'

export async function generateDevisPdf(data: Record<string, unknown>): Promise<Uint8Array> {
  const instance = pdf(createElement(TemplateDevisDoc, { data }))
  const blob = await instance.toBlob()
  const arrayBuffer = await blob.arrayBuffer()
  return new Uint8Array(arrayBuffer)
}

export async function generateFacturePdf(data: Record<string, unknown>): Promise<Uint8Array> {
  const instance = pdf(createElement(TemplateFactureDoc, { data }))
  const blob = await instance.toBlob()
  const arrayBuffer = await blob.arrayBuffer()
  return new Uint8Array(arrayBuffer)
}

// Expose to window for electron main process to call via executeJavaScript
;(window as Window & { __pdfService?: typeof pdfService })..__pdfService = {
  generateDevisPdf,
  generateFacturePdf
}

const pdfService = { generateDevisPdf, generateFacturePdf }
export default pdfService
