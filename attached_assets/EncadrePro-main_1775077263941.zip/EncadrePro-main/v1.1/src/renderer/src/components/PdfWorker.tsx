// PdfWorker.tsx - Composant invisible monté une fois dans App.tsx
// Écoute les demandes PDF du main process, génère le PDF côté renderer
// (là où @react-pdf/renderer fonctionne), et retourne les bytes au main.

import React, { useEffect } from 'react'
import { pdf } from '@react-pdf/renderer'
import { createElement } from 'react'
import { TemplateDevis } from '../pdf/TemplateDevis'
import { TemplateFacture } from '../pdf/TemplateFacture'

export const PdfWorker: React.FC = () => {
  useEffect(() => {
    if (!window.api?.pdf?.onGenerateRequest) return

    const cleanup = window.api.pdf.onGenerateRequest(async ({ requestId, type, data }) => {
      try {
        let element: React.ReactElement

        if (type === 'devis') {
          element = createElement(TemplateDevis, { data, atelier: data.atelier as Record<string, unknown> })
        } else if (type === 'facture') {
          element = createElement(TemplateFacture, { data, atelier: data.atelier as Record<string, unknown> })
        } else {
          throw new Error(`Type PDF inconnu: ${type}`)
        }

        const instance = pdf(element)
        const blob = await instance.toBlob()
        const arrayBuffer = await blob.arrayBuffer()
        const bytes = Array.from(new Uint8Array(arrayBuffer))

        window.api.pdf.sendBytesResponse({ requestId, bytes })
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Erreur inconnue lors de la génération PDF'
        window.api.pdf.sendBytesResponse({ requestId, error: msg })
      }
    })

    return cleanup
  }, [])

  // Invisible — no DOM output
  return null
}
