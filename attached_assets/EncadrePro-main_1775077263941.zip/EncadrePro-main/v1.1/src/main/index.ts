import { app, BrowserWindow, ipcMain, shell, dialog } from 'electron'
import { join } from 'path'
import { initDatabase } from './database/db'
import { registerAtelierHandlers } from './database/handlers/atelier'
import { registerClientsHandlers } from './database/handlers/clients'
import { registerProduitsHandlers } from './database/handlers/produits'
import { registerDevisHandlers } from './database/handlers/devis'
import { registerFacturesHandlers } from './database/handlers/factures'
import { registerDashboardHandlers } from './database/handlers/dashboard'
import { registerPdfHandlers } from './database/handlers/pdf'
import { registerEmailHandlers } from './database/handlers/email'

let mainWindow: BrowserWindow | null = null

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 640,
    icon: join(__dirname, '../../resources/icon.png'),
    titleBarStyle: 'hiddenInset',
    trafficLightPosition: { x: 16, y: 16 },
    backgroundColor: '#0A0A0F',
    vibrancy: 'under-window',
    visualEffectState: 'active',
    show: false,
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false,
    }
  })

  mainWindow.on('ready-to-show', () => {
    mainWindow?.show()
  })

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url)
    return { action: 'deny' }
  })

  if (process.env.ELECTRON_RENDERER_URL) {
    mainWindow.loadURL(process.env.ELECTRON_RENDERER_URL)
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }
}

app.whenReady().then(() => {
  // Init database
  initDatabase()

  // Register all IPC handlers
  registerAtelierHandlers()
  registerClientsHandlers()
  registerProduitsHandlers()
  registerDevisHandlers()
  registerFacturesHandlers()
  registerDashboardHandlers()
  registerPdfHandlers()
  registerEmailHandlers()

  // Global IPC error tracer
  ipcMain.on('error', (_, err) => console.error('[IPC Error]', err))

  // Window management IPC
  ipcMain.handle('dialog:showSaveDialog', async (_, options) => {
    return dialog.showSaveDialog(mainWindow!, options)
  })
  ipcMain.handle('dialog:showOpenDialog', async (_, options) => {
    return dialog.showOpenDialog(mainWindow!, options)
  })
  ipcMain.handle('shell:openPath', async (_, path: string) => {
    return shell.openPath(path)
  })

  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit()
})
