import { ipcMain } from 'electron'
import * as nodemailer from 'nodemailer'
import { getDB } from '../db'

function getTransporter(config: Record<string, unknown>) {
  const host = config.smtp_host as string
  const user = config.smtp_user as string
  const pass = config.smtp_pass as string
  const port = (config.smtp_port as number) || 587

  if (!host || !user || !pass) {
    throw new Error('Configuration SMTP incomplète. Vérifiez les Paramètres.')
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass }
  })
}

export function registerEmailHandlers() {
  ipcMain.handle('email:test', async (_, configTest: Record<string, unknown>) => {
    const transporter = getTransporter(configTest)
    await transporter.verify()
    const to = (configTest.email || configTest.smtp_user) as string
    await transporter.sendMail({
      from: `"${configTest.nom || 'EncadrePro'}" <${to}>`,
      to,
      subject: 'Test de configuration SMTP — EncadrePro',
      text: 'Bonjour,\n\nCeci est un test de configuration SMTP depuis EncadrePro. La configuration est correcte.\n\nCordialement,\nEncadrePro.'
    })
    return { success: true }
  })

  ipcMain.handle('email:sendDevis', async (_, devisId: number, to: string) => {
    const db = getDB()
    const atelier = db.prepare('SELECT * FROM atelier WHERE id = 1').get() as Record<string, unknown>
    const devis = db.prepare('SELECT * FROM devis WHERE id = ?').get(devisId) as Record<string, unknown>
    if (!devis) throw new Error('Devis introuvable')

    const { app } = await import('electron')
    const { existsSync } = await import('fs')
    const path = await import('path')
    const pdfPath = path.join(app.getPath('userData'), 'EncadrePro', `Devis_${devis.numero}.pdf`)
    if (!existsSync(pdfPath)) throw new Error("Générez d'abord le PDF avant d'envoyer ce devis.")

    const transporter = getTransporter(atelier)
    await transporter.sendMail({
      from: `"${atelier.nom || 'Atelier'}" <${atelier.email || atelier.smtp_user}>`,
      to,
      subject: `Votre Devis N° ${devis.numero} — ${atelier.nom || 'Atelier'}`,
      text: `Bonjour,\n\nVeuillez trouver ci-joint votre devis N° ${devis.numero}.\n\nCordialement,\n${atelier.nom}`,
      attachments: [{ filename: `Devis_${devis.numero}.pdf`, path: pdfPath }]
    })

    if (devis.statut === 'brouillon') {
      db.prepare("UPDATE devis SET statut = 'envoye', modifie_le = CURRENT_TIMESTAMP WHERE id = ?").run(devisId)
    }
    return { success: true }
  })

  ipcMain.handle('email:sendFacture', async (_, factureId: number, to: string) => {
    const db = getDB()
    const atelier = db.prepare('SELECT * FROM atelier WHERE id = 1').get() as Record<string, unknown>
    const facture = db.prepare('SELECT * FROM factures WHERE id = ?').get(factureId) as Record<string, unknown>
    if (!facture) throw new Error('Facture introuvable')

    const { app } = await import('electron')
    const { existsSync } = await import('fs')
    const path = await import('path')
    const pdfPath = path.join(app.getPath('userData'), 'EncadrePro', `Facture_${facture.numero}.pdf`)
    if (!existsSync(pdfPath)) throw new Error("Générez d'abord le PDF avant d'envoyer cette facture.")

    const transporter = getTransporter(atelier)
    await transporter.sendMail({
      from: `"${atelier.nom || 'Atelier'}" <${atelier.email || atelier.smtp_user}>`,
      to,
      subject: `Votre Facture N° ${facture.numero} — ${atelier.nom || 'Atelier'}`,
      text: `Bonjour,\n\nVeuillez trouver ci-joint votre facture N° ${facture.numero}.\n\nCordialement,\n${atelier.nom}`,
      attachments: [{ filename: `Facture_${facture.numero}.pdf`, path: pdfPath }]
    })

    if (facture.statut === 'brouillon') {
      db.prepare("UPDATE factures SET statut = 'envoyee', modifie_le = CURRENT_TIMESTAMP WHERE id = ?").run(factureId)
    }
    return { success: true }
  })
}
