import { ipcMain } from 'electron'
import { getDB } from '../db'

function calcLigne(ligne: Record<string, unknown>) {
  const unite = (ligne.unite_calcul as string) || 'unitaire'
  const largeur = Number(ligne.largeur_m || 0)
  const hauteur = Number(ligne.hauteur_m || 0)
  const quantite = Number(ligne.quantite || 1)
  const prixHT = Number(ligne.prix_unitaire_ht || 0)
  const tva = Number(ligne.taux_tva || 20)

  let quantiteCalculee: number
  if (unite === 'metre_lineaire') {
    quantiteCalculee = (largeur + hauteur) * 2 * quantite
  } else if (unite === 'metre_carre') {
    quantiteCalculee = largeur * hauteur * quantite
  } else {
    quantiteCalculee = quantite
  }

  return {
    quantiteCalculee,
    totalHT: quantiteCalculee * prixHT,
    totalTTC: quantiteCalculee * prixHT * (1 + tva / 100)
  }
}

function updateFactureTotaux(factureId: number): void {
  try {
    const db = getDB()
    const lignes = db.prepare('SELECT * FROM lignes_facture WHERE facture_id = ?').all(factureId) as Record<string, any>[]
    const acomptes = db.prepare('SELECT COALESCE(SUM(montant), 0) as total FROM acomptes WHERE facture_id = ?').get(factureId) as { total: number }

    let sousTotal = 0, tva10 = 0, tva20 = 0, tva55 = 0
    for (const l of lignes) {
      const tht = Number(l.total_ht || 0)
      sousTotal += tht
      const rate = Number(l.taux_tva)
      if (rate === 10) tva10 += tht * 0.1
      else if (rate === 5.5) tva55 += tht * 0.055
      else tva20 += tht * 0.2
    }

    const totalTTC = sousTotal + tva10 + tva20 + tva55
    const totalPaye = Number(acomptes.total || 0)
    const soldeRestant = Math.max(0, totalTTC - totalPaye)

    let statutPaiement = 'brouillon'
    // Don't auto-update status to soldee if it was manually set to something else? 
    // Usually we want to reflect payment state.
    if (totalPaye > 0 && soldeRestant > 0.01) statutPaiement = 'partiellement_payee'
    else if (totalPaye >= totalTTC - 0.01 && totalTTC > 0) statutPaiement = 'soldee'

    db.prepare(`
      UPDATE factures SET
        sous_total_ht = ?, total_tva_10 = ?, total_tva_20 = ?,
        total_ttc = ?, total_paye = ?, solde_restant = ?,
        statut = CASE WHEN statut = 'brouillon' THEN 'envoyee' ELSE statut END,
        modifie_le = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(sousTotal, tva10, tva20, totalTTC, totalPaye, soldeRestant, factureId)
    
    // Final check for status update based on balance
    if (statutPaiement !== 'brouillon') {
       db.prepare("UPDATE factures SET statut = ? WHERE id = ? AND statut != 'brouillon'").run(statutPaiement, factureId)
    }
  } catch (err) {
    console.error('[updateFactureTotaux]', err)
  }
}

export function registerFacturesHandlers(): void {
  ipcMain.handle('factures:list', (_, filters?: { statut?: string; client_id?: number }) => {
    try {
      const db = getDB()
      let query = `
        SELECT f.*, c.nom as client_nom, c.prenom as client_prenom
        FROM factures f LEFT JOIN clients c ON c.id = f.client_id
      `
      const conditions: string[] = []
      const params: unknown[] = []
      if (filters?.statut) { conditions.push('f.statut = ?'); params.push(filters.statut) }
      if (filters?.client_id) { conditions.push('f.client_id = ?'); params.push(filters.client_id) }
      if (conditions.length) query += ' WHERE ' + conditions.join(' AND ')
      query += ' ORDER BY f.cree_le DESC'
      return db.prepare(query).all(...params)
    } catch (err) {
      console.error('[factures:list]', err)
      throw err
    }
  })

  ipcMain.handle('factures:get', (_, id: number) => {
    try {
      const db = getDB()
      const facture = db.prepare(`
        SELECT f.*, c.nom as client_nom, c.prenom as client_prenom,
               c.email as client_email, c.telephone as client_telephone,
               c.adresse as client_adresse, c.ville as client_ville, c.code_postal as client_cp
        FROM factures f LEFT JOIN clients c ON c.id = f.client_id WHERE f.id = ?
      `).get(id)
      const lignes = db.prepare('SELECT * FROM lignes_facture WHERE facture_id = ? ORDER BY ordre').all(id)
      const acomptes = db.prepare('SELECT * FROM acomptes WHERE facture_id = ? ORDER BY date_paiement').all(id)
      return { ...facture as Record<string, unknown>, lignes, acomptes }
    } catch (err) {
      console.error('[factures:get]', err)
      throw err
    }
  })

  ipcMain.handle('factures:create', (_, data: Record<string, unknown>) => {
    try {
      const db = getDB()
      const atelier = db.prepare('SELECT prefixe_facture, compteur_facture FROM atelier WHERE id = 1').get() as {
        prefixe_facture: string; compteur_facture: number
      }
      const next = (atelier.compteur_facture || 0) + 1
      db.prepare('UPDATE atelier SET compteur_facture = ? WHERE id = 1').run(next)
      const year = new Date().getFullYear()
      const numero = `${atelier.prefixe_facture || 'FAC'}-${year}-${String(next).padStart(3, '0')}`

      const echeance = new Date()
      echeance.setDate(echeance.getDate() + 30)

      const result = db.prepare(`
        INSERT INTO factures (numero, client_id, date_echeance, statut, notes, conditions)
        VALUES (?, ?, ?, 'brouillon', ?, ?)
      `).run(numero, data.client_id, echeance.toISOString().split('T')[0], data.notes || null, data.conditions || null)

      return db.prepare('SELECT * FROM factures WHERE id = ?').get(result.lastInsertRowid)
    } catch (err) {
      console.error('[factures:create]', err)
      throw err
    }
  })

  ipcMain.handle('factures:update', (_, id: number, data: Record<string, unknown>) => {
    try {
      const db = getDB()
      db.prepare(`
        UPDATE factures SET
          client_id = @client_id, date_echeance = @date_echeance,
          notes = @notes, conditions = @conditions, modifie_le = CURRENT_TIMESTAMP
        WHERE id = @id
      `).run({
        client_id: data.client_id,
        date_echeance: data.date_echeance,
        notes: data.notes || null,
        conditions: data.conditions || null,
        id
      })
      return db.prepare('SELECT * FROM factures WHERE id = ?').get(id)
    } catch (err) {
      console.error('[factures:update]', err)
      throw err
    }
  })

  ipcMain.handle('factures:delete', (_, id: number) => {
    try {
      getDB().prepare('DELETE FROM factures WHERE id = ?').run(id)
      return { success: true }
    } catch (err) {
      console.error('[factures:delete]', err)
      throw err
    }
  })

  ipcMain.handle('factures:updateStatut', (_, id: number, statut: string) => {
    try {
      getDB().prepare('UPDATE factures SET statut = ?, modifie_le = CURRENT_TIMESTAMP WHERE id = ?').run(statut, id)
      return { success: true }
    } catch (err) {
      console.error('[factures:updateStatut]', err)
      throw err
    }
  })

  ipcMain.handle('factures:saveLignes', (_, factureId: number, lignes: Record<string, unknown>[]) => {
    try {
      const db = getDB()
      db.prepare('DELETE FROM lignes_facture WHERE facture_id = ?').run(factureId)

      const insert = db.prepare(`
        INSERT INTO lignes_facture
          (facture_id, produit_id, designation, unite_calcul, largeur_m, hauteur_m,
           quantite, quantite_calculee, prix_unitaire_ht, taux_tva, total_ht, total_ttc, ordre)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)

      for (let i = 0; i < lignes.length; i++) {
        const l = lignes[i]
        const { quantiteCalculee, totalHT, totalTTC } = calcLigne(l)
        insert.run(
          factureId, l.produit_id || null, l.designation, l.unite_calcul || 'unitaire',
          l.largeur_m || null, l.hauteur_m || null, l.quantite || 1,
          quantiteCalculee, l.prix_unitaire_ht || 0, l.taux_tva || 20, totalHT, totalTTC, i
        )
      }

      updateFactureTotaux(factureId)
      return db.prepare('SELECT * FROM factures WHERE id = ?').get(factureId)
    } catch (err) {
      console.error('[factures:saveLignes]', err)
      throw err
    }
  })

  ipcMain.handle('factures:getLignes', (_, factureId: number) => {
    try {
      return getDB().prepare('SELECT * FROM lignes_facture WHERE facture_id = ? ORDER BY ordre').all(factureId)
    } catch (err) {
      console.error('[factures:getLignes]', err)
      throw err
    }
  })

  ipcMain.handle('factures:addAcompte', (_, data: Record<string, unknown>) => {
    try {
      const db = getDB()
      const result = db.prepare(`
        INSERT INTO acomptes (facture_id, montant, date_paiement, mode_paiement, notes)
        VALUES (@facture_id, @montant, @date_paiement, @mode_paiement, @notes)
      `).run({
        facture_id: data.facture_id,
        montant: Number(data.montant || 0),
        date_paiement: data.date_paiement || new Date().toISOString().split('T')[0],
        mode_paiement: data.mode_paiement || 'virement',
        notes: data.notes || null
      })
      updateFactureTotaux(data.facture_id as number)
      return db.prepare('SELECT * FROM acomptes WHERE id = ?').get(result.lastInsertRowid)
    } catch (err) {
      console.error('[factures:addAcompte]', err)
      throw err
    }
  })

  ipcMain.handle('factures:getAcomptes', (_, factureId: number) => {
    try {
      return getDB().prepare('SELECT * FROM acomptes WHERE facture_id = ? ORDER BY date_paiement').all(factureId)
    } catch (err) {
      console.error('[factures:getAcomptes]', err)
      throw err
    }
  })

  ipcMain.handle('factures:deleteAcompte', (_, id: number) => {
    try {
      const db = getDB()
      const acompte = db.prepare('SELECT facture_id FROM acomptes WHERE id = ?').get(id) as { facture_id: number }
      db.prepare('DELETE FROM acomptes WHERE id = ?').run(id)
      if (acompte) updateFactureTotaux(acompte.facture_id)
      return { success: true }
    } catch (err) {
      console.error('[factures:deleteAcompte]', err)
      throw err
    }
  })
}
