import { ipcMain } from 'electron'
import { getDB } from '../db'

function getNextNumero(type: 'devis'): string {
  const db = getDB()
  const atelier = db.prepare('SELECT prefixe_devis, compteur_devis FROM atelier WHERE id = 1').get() as {
    prefixe_devis: string
    compteur_devis: number
  }
  const next = (atelier.compteur_devis || 0) + 1
  db.prepare('UPDATE atelier SET compteur_devis = ? WHERE id = 1').run(next)
  const year = new Date().getFullYear()
  return `${atelier.prefixe_devis || 'DEV'}-${year}-${String(next).padStart(3, '0')}`
}

function calcLigne(ligne: Record<string, unknown>) {
  const unite = (ligne.unite_calcul as string) || 'unitaire'
  const largeur = Number(ligne.largeur_m || 0)
  const hauteur = Number(ligne.hauteur_m || 0)
  const quantite = Number(ligne.quantite || 1)
  const prixHT = Number(ligne.prix_unitaire_ht || 0)
  const tva = Number(ligne.taux_tva || 20)

  let quantiteCalculee: number
  if (unite === 'metre_lineaire') {
    quantiteCalculee = (largeur + hauteur) * 2 * quantite
  } else if (unite === 'metre_carre') {
    quantiteCalculee = largeur * hauteur * quantite
  } else {
    quantiteCalculee = quantite
  }

  const totalHT = quantiteCalculee * prixHT
  const totalTTC = totalHT * (1 + tva / 100)
  return { quantiteCalculee, totalHT, totalTTC }
}

function updateDevisTotaux(devisId: number): void {
  try {
    const db = getDB()
    const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ?').all(devisId) as Record<string, any>[]

    let sousTotal = 0, tva10 = 0, tva20 = 0, tva55 = 0
    for (const l of lignes) {
      const tht = Number(l.total_ht || 0)
      sousTotal += tht
      const rate = Number(l.taux_tva)
      if (rate === 10) tva10 += tht * 0.1
      else if (rate === 5.5) tva55 += tht * 0.055
      else tva20 += tht * 0.2
    }

    db.prepare(`
      UPDATE devis SET
        sous_total_ht = ?, total_tva_10 = ?, total_tva_20 = ?,
        total_ttc = ?, modifie_le = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(sousTotal, tva10, tva20, sousTotal + tva10 + tva20 + tva55, devisId)
  } catch (err) {
    console.error('[updateDevisTotaux]', err)
  }
}

export function registerDevisHandlers(): void {
  ipcMain.handle('devis:list', (_, filters?: { statut?: string; client_id?: number }) => {
    try {
      const db = getDB()
      let query = `
        SELECT d.*, c.nom as client_nom, c.prenom as client_prenom
        FROM devis d LEFT JOIN clients c ON c.id = d.client_id
      `
      const conditions: string[] = []
      const params: unknown[] = []
      if (filters?.statut) { conditions.push('d.statut = ?'); params.push(filters.statut) }
      if (filters?.client_id) { conditions.push('d.client_id = ?'); params.push(filters.client_id) }
      if (conditions.length) query += ' WHERE ' + conditions.join(' AND ')
      query += ' ORDER BY d.cree_le DESC'
      return db.prepare(query).all(...params)
    } catch (err) {
      console.error('[devis:list]', err)
      throw err
    }
  })

  ipcMain.handle('devis:get', (_, id: number) => {
    try {
      const db = getDB()
      const devis = db.prepare(`
        SELECT d.*, c.nom as client_nom, c.prenom as client_prenom,
               c.email as client_email, c.telephone as client_telephone,
               c.adresse as client_adresse, c.ville as client_ville, c.code_postal as client_cp
        FROM devis d LEFT JOIN clients c ON c.id = d.client_id WHERE d.id = ?
      `).get(id)
      const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(id)
      return { ...devis as Record<string, unknown>, lignes }
    } catch (err) {
      console.error('[devis:get]', err)
      throw err
    }
  })

  ipcMain.handle('devis:create', (_, data: Record<string, unknown>) => {
    console.log('[devis:create] data:', JSON.stringify(data))
    try {
      const db = getDB()
      const numero = getNextNumero('devis')
      const validite = new Date()
      validite.setDate(validite.getDate() + 30)
      const dateValidite = validite.toISOString().split('T')[0]

      const result = db.prepare(`
        INSERT INTO devis (numero, client_id, date_validite, statut, notes, conditions)
        VALUES (?, ?, ?, 'brouillon', ?, ?)
      `).run(numero, data.client_id, dateValidite, data.notes || null, data.conditions || null)

      return db.prepare(`
        SELECT d.*, c.nom as client_nom FROM devis d
        JOIN clients c ON c.id = d.client_id WHERE d.id = ?
      `).get(result.lastInsertRowid)
    } catch (err) {
      console.error('[devis:create] ERROR:', err)
      throw err
    }
  })

  ipcMain.handle('devis:update', (_, id: number, data: Record<string, unknown>) => {
    console.log('[devis:update] id:', id, 'data:', JSON.stringify(data))
    try {
      const db = getDB()
      db.prepare(`
        UPDATE devis SET client_id = @client_id, date_validite = @date_validite,
          notes = @notes, conditions = @conditions, modifie_le = CURRENT_TIMESTAMP
        WHERE id = @id
      `).run({
        client_id: data.client_id,
        date_validite: data.date_validite,
        notes: data.notes || null,
        conditions: data.conditions || null,
        id
      })
      return db.prepare('SELECT * FROM devis WHERE id = ?').get(id)
    } catch (err) {
      console.error('[devis:update] ERROR:', err)
      throw err
    }
  })

  ipcMain.handle('devis:delete', (_, id: number) => {
    try {
      getDB().prepare('DELETE FROM devis WHERE id = ?').run(id)
      return { success: true }
    } catch (err) {
      console.error('[devis:delete]', err)
      throw err
    }
  })

  ipcMain.handle('devis:updateStatut', (_, id: number, statut: string) => {
    try {
      getDB().prepare('UPDATE devis SET statut = ?, modifie_le = CURRENT_TIMESTAMP WHERE id = ?').run(statut, id)
      return { success: true }
    } catch (err) {
      console.error('[devis:updateStatut]', err)
      throw err
    }
  })

  ipcMain.handle('devis:saveLignes', (_, devisId: number, lignes: Record<string, unknown>[]) => {
    try {
      const db = getDB()
      db.prepare('DELETE FROM lignes_devis WHERE devis_id = ?').run(devisId)

      const insert = db.prepare(`
        INSERT INTO lignes_devis
          (devis_id, produit_id, designation, unite_calcul, largeur_m, hauteur_m,
           quantite, quantite_calculee, prix_unitaire_ht, taux_tva, total_ht, total_ttc, ordre)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)

      for (let i = 0; i < lignes.length; i++) {
        const l = lignes[i]
        const { quantiteCalculee, totalHT, totalTTC } = calcLigne(l)
        insert.run(
          devisId, l.produit_id || null, l.designation, l.unite_calcul || 'unitaire',
          l.largeur_m || null, l.hauteur_m || null, l.quantite || 1,
          quantiteCalculee, l.prix_unitaire_ht || 0, l.taux_tva || 20, totalHT, totalTTC, i
        )
      }

      updateDevisTotaux(devisId)
      return db.prepare('SELECT * FROM devis WHERE id = ?').get(devisId)
    } catch (err) {
      console.error('[devis:saveLignes]', err)
      throw err
    }
  })

  ipcMain.handle('devis:getLignes', (_, devisId: number) => {
    try {
      return getDB().prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(devisId)
    } catch (err) {
      console.error('[devis:getLignes]', err)
      throw err
    }
  })

  ipcMain.handle('devis:convertToFacture', (_, id: number) => {
    try {
      const db = getDB()
      const devis = db.prepare('SELECT * FROM devis WHERE id = ?').get(id) as Record<string, any>
      if (!devis) throw new Error('Devis introuvable')

      const atelier = db.prepare('SELECT prefixe_facture, compteur_facture FROM atelier WHERE id = 1').get() as {
        prefixe_facture: string; compteur_facture: number
      }
      const next = (atelier.compteur_facture || 0) + 1
      db.prepare('UPDATE atelier SET compteur_facture = ? WHERE id = 1').run(next)
      const year = new Date().getFullYear()
      const numero = `${atelier.prefixe_facture || 'FAC'}-${year}-${String(next).padStart(3, '0')}`

      const echeance = new Date()
      echeance.setDate(echeance.getDate() + 30)

      const factureResult = db.prepare(`
        INSERT INTO factures (numero, devis_id, client_id, date_echeance, statut,
          sous_total_ht, total_tva_10, total_tva_20, total_ttc, solde_restant, notes, conditions)
        VALUES (?, ?, ?, ?, 'brouillon', ?, ?, ?, ?, ?, ?, ?)
      `).run(
        numero, id, devis.client_id,
        echeance.toISOString().split('T')[0],
        devis.sous_total_ht, devis.total_tva_10, devis.total_tva_20, devis.total_ttc,
        devis.total_ttc, devis.notes, devis.conditions
      )

      const factureId = factureResult.lastInsertRowid
      const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(id) as Record<string, any>[]

      const insertLigne = db.prepare(`
        INSERT INTO lignes_facture
          (facture_id, produit_id, designation, unite_calcul, largeur_m, hauteur_m,
           quantite, quantite_calculee, prix_unitaire_ht, taux_tva, total_ht, total_ttc, ordre)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `)

      for (const l of lignes) {
        insertLigne.run(
          factureId, l.produit_id, l.designation, l.unite_calcul,
          l.largeur_m, l.hauteur_m, l.quantite, l.quantite_calculee,
          l.prix_unitaire_ht, l.taux_tva, l.total_ht, l.total_ttc, l.ordre
        )
      }

      db.prepare('UPDATE devis SET statut = ?, facture_id = ?, modifie_le = CURRENT_TIMESTAMP WHERE id = ?').run('converti', factureId, id)
      return { factureId, numero }
    } catch (err) {
      console.error('[devis:convertToFacture]', err)
      throw err
    }
  })
}
