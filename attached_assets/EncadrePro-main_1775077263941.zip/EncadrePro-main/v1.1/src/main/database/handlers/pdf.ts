// PDF handler: Main process collecte les données SQLite et les envoie
// au renderer via webContents.send. Le renderer génère le PDF (car React-PDF
// ne peut pas fonctionner dans le main process avec electron-vite).
// Le renderer retourne les bytes via 'pdf:bytes-ready', le main les écrit sur disk.

import { ipcMain, shell, app, BrowserWindow } from 'electron'
import * as path from 'path'
import * as fs from 'fs'
import { getDB } from '../db'

function ensurePdfDir(): string {
  const dir = path.join(app.getPath('userData'), 'EncadrePro', 'pdf')
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  return dir
}

// Helper: envoyer les données au renderer pour génération PDF, recevoir les bytes
function renderPdfInRenderer(type: 'devis' | 'facture', data: Record<string, unknown>): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const win = BrowserWindow.getAllWindows()[0]
    if (!win) return reject(new Error('Aucune fenêtre disponible'))

    const requestId = `${Date.now()}-${Math.random()}`

    // Listen once for the renderer's response
    ipcMain.once(`pdf:bytes-ready:${requestId}`, (_, result: { error?: string; bytes?: number[] }) => {
      if (result.error) return reject(new Error(result.error))
      if (!result.bytes) return reject(new Error('Aucun bytes reçu'))
      resolve(Buffer.from(result.bytes))
    })

    // Timeout safety
    const timeout = setTimeout(() => {
      ipcMain.removeAllListeners(`pdf:bytes-ready:${requestId}`)
      reject(new Error('Timeout: la génération PDF a pris trop de temps'))
    }, 30000)

    ipcMain.once(`pdf:bytes-ready:${requestId}`, () => clearTimeout(timeout))

    // Ask renderer to generate PDF
    win.webContents.send('pdf:generate-request', { requestId, type, data })
  })
}

export function registerPdfHandlers(): void {
  // Renderer sends back the PDF bytes
  ipcMain.on('pdf:bytes-response', (_, payload: { requestId: string; error?: string; bytes?: number[] }) => {
    ipcMain.emit(`pdf:bytes-ready:${payload.requestId}`, null, payload)
  })

  ipcMain.handle('pdf:generateDevis', async (_, devisId: number) => {
    const db = getDB()
    const devis = db.prepare(`
      SELECT d.*, c.nom as client_nom, c.prenom as client_prenom,
             c.email as client_email, c.telephone as client_telephone,
             c.adresse as client_adresse, c.code_postal as client_cp, c.ville as client_ville
      FROM devis d LEFT JOIN clients c ON d.client_id = c.id WHERE d.id = ?
    `).get(devisId) as Record<string, unknown> | undefined

    if (!devis) throw new Error('Devis introuvable')

    const lignes = db.prepare('SELECT * FROM lignes_devis WHERE devis_id = ? ORDER BY ordre').all(devisId)
    const atelier = db.prepare('SELECT * FROM atelier WHERE id = 1').get() as Record<string, unknown>

    const pdfBytes = await renderPdfInRenderer('devis', { ...devis, lignes, atelier })

    const dir = ensurePdfDir()
    const pdfPath = path.join(dir, `Devis_${devis.numero}.pdf`)
    fs.writeFileSync(pdfPath, pdfBytes)

    await shell.openPath(pdfPath)
    return { success: true, path: pdfPath }
  })

  ipcMain.handle('pdf:generateFacture', async (_, factureId: number) => {
    const db = getDB()
    const facture = db.prepare(`
      SELECT f.*, c.nom as client_nom, c.prenom as client_prenom,
             c.email as client_email, c.telephone as client_telephone,
             c.adresse as client_adresse, c.code_postal as client_cp, c.ville as client_ville
      FROM factures f LEFT JOIN clients c ON f.client_id = c.id WHERE f.id = ?
    `).get(factureId) as Record<string, unknown> | undefined

    if (!facture) throw new Error('Facture introuvable')

    const lignes = db.prepare('SELECT * FROM lignes_facture WHERE facture_id = ? ORDER BY ordre').all(factureId)
    const acomptes = db.prepare('SELECT * FROM acomptes WHERE facture_id = ? ORDER BY date_paiement').all(factureId)
    const atelier = db.prepare('SELECT * FROM atelier WHERE id = 1').get() as Record<string, unknown>

    const pdfBytes = await renderPdfInRenderer('facture', { ...facture, lignes, acomptes, atelier })

    const dir = ensurePdfDir()
    const pdfPath = path.join(dir, `Facture_${facture.numero}.pdf`)
    fs.writeFileSync(pdfPath, pdfBytes)

    await shell.openPath(pdfPath)
    return { success: true, path: pdfPath }
  })
}
