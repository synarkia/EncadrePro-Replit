import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerAtelierHandlers(): void {
  ipcMain.handle('atelier:get', () => {
    try {
      return getDB().prepare('SELECT * FROM atelier WHERE id = 1').get()
    } catch (err) {
      console.error('[atelier:get]', err)
      throw err
    }
  })

  ipcMain.handle('atelier:save', (_, data: Record<string, unknown>) => {
    console.log('[atelier:save] data:', JSON.stringify(data))
    try {
      const db = getDB()
      
      // Explicit mapping for security and better-sqlite3 compatibility
      db.prepare(`
        UPDATE atelier SET
          nom = @nom,
          adresse = @adresse,
          ville = @ville,
          code_postal = @code_postal,
          telephone = @telephone,
          email = @email,
          siret = @siret,
          tva_intracom = @tva_intracom,
          iban = @iban,
          bic = @bic,
          prefixe_devis = @prefixe_devis,
          prefixe_facture = @prefixe_facture,
          modifie_le = CURRENT_TIMESTAMP
        WHERE id = 1
      `).run({
        nom: data.nom ?? '',
        adresse: data.adresse ?? null,
        ville: data.ville ?? null,
        code_postal: data.code_postal ?? null,
        telephone: data.telephone ?? null,
        email: data.email ?? null,
        siret: data.siret ?? null,
        tva_intracom: data.tva_intracom ?? null,
        iban: data.iban ?? null,
        bic: data.bic ?? null,
        prefixe_devis: data.prefixe_devis ?? 'DEV',
        prefixe_facture: data.prefixe_facture ?? 'FAC'
      })

      return db.prepare('SELECT * FROM atelier WHERE id = 1').get()
    } catch (err) {
      console.error('[atelier:save] ERROR:', err)
      throw err
    }
  })
}
