import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerClientsHandlers(): void {
  ipcMain.handle('clients:list', (_, search?: string) => {
    try {
      const db = getDB()
      if (search) {
        return db.prepare(`
          SELECT * FROM clients
          WHERE nom LIKE ? OR prenom LIKE ? OR email LIKE ? OR telephone LIKE ?
          ORDER BY nom ASC
        `).all(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`)
      }
      return db.prepare('SELECT * FROM clients ORDER BY nom ASC').all()
    } catch (err) {
      console.error('[clients:list]', err)
      throw err
    }
  })

  ipcMain.handle('clients:get', (_, id: number) => {
    try {
      return getDB().prepare('SELECT * FROM clients WHERE id = ?').get(id)
    } catch (err) {
      console.error('[clients:get]', err)
      throw err
    }
  })

  ipcMain.handle('clients:create', (_, data: Record<string, unknown>) => {
    console.log('[clients:create] data:', JSON.stringify(data))
    try {
      const db = getDB()
      const result = db.prepare(`
        INSERT INTO clients (nom, prenom, email, telephone, adresse, ville, code_postal, notes)
        VALUES (@nom, @prenom, @email, @telephone, @adresse, @ville, @code_postal, @notes)
      `).run({
        nom: data.nom ?? '',
        prenom: data.prenom ?? null,
        email: data.email ?? null,
        telephone: data.telephone ?? null,
        adresse: data.adresse ?? null,
        ville: data.ville ?? null,
        code_postal: data.code_postal ?? null,
        notes: data.notes ?? null,
      })
      const created = db.prepare('SELECT * FROM clients WHERE id = ?').get(result.lastInsertRowid)
      console.log('[clients:create] created:', created)
      return created
    } catch (err) {
      console.error('[clients:create] ERROR:', err)
      throw err
    }
  })

  ipcMain.handle('clients:update', (_, id: number, data: Record<string, unknown>) => {
    console.log('[clients:update] id:', id, 'data:', JSON.stringify(data))
    try {
      const db = getDB()
      db.prepare(`
        UPDATE clients SET
          nom = @nom, prenom = @prenom, email = @email,
          telephone = @telephone, adresse = @adresse, ville = @ville,
          code_postal = @code_postal, notes = @notes,
          modifie_le = CURRENT_TIMESTAMP
        WHERE id = @id
      `).run({
        nom: data.nom ?? '',
        prenom: data.prenom ?? null,
        email: data.email ?? null,
        telephone: data.telephone ?? null,
        adresse: data.adresse ?? null,
        ville: data.ville ?? null,
        code_postal: data.code_postal ?? null,
        notes: data.notes ?? null,
        id
      })
      return db.prepare('SELECT * FROM clients WHERE id = ?').get(id)
    } catch (err) {
      console.error('[clients:update] ERROR:', err)
      throw err
    }
  })

  ipcMain.handle('clients:delete', (_, id: number) => {
    try {
      getDB().prepare('DELETE FROM clients WHERE id = ?').run(id)
      return { success: true }
    } catch (err) {
      console.error('[clients:delete]', err)
      throw err
    }
  })

  ipcMain.handle('clients:getStats', (_, id: number) => {
    try {
      const db = getDB()
      const devisCount = (db.prepare('SELECT COUNT(*) as n FROM devis WHERE client_id = ?').get(id) as { n: number }).n
      const facturesCount = (db.prepare('SELECT COUNT(*) as n FROM factures WHERE client_id = ?').get(id) as { n: number }).n
      const caTotal = (db.prepare(`
        SELECT COALESCE(SUM(total_ttc), 0) as total FROM factures
        WHERE client_id = ? AND statut IN ('envoyee', 'partiellement_payee', 'soldee')
      `).get(id) as { total: number }).total
      const devis = db.prepare('SELECT * FROM devis WHERE client_id = ? ORDER BY cree_le DESC').all(id)
      const factures = db.prepare('SELECT * FROM factures WHERE client_id = ? ORDER BY cree_le DESC').all(id)
      return { devisCount, facturesCount, caTotal, devis, factures }
    } catch (err) {
      console.error('[clients:getStats]', err)
      throw err
    }
  })
}
