import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerProduitsHandlers(): void {
  ipcMain.handle('produits:list', (_, categorie?: string) => {
    try {
      const db = getDB()
      if (categorie) {
        return db.prepare('SELECT * FROM produits WHERE categorie = ? ORDER BY designation ASC').all(categorie)
      }
      return db.prepare('SELECT * FROM produits ORDER BY categorie, designation ASC').all()
    } catch (err) {
      console.error('[produits:list]', err)
      throw err
    }
  })

  ipcMain.handle('produits:get', (_, id: number) => {
    try {
      return getDB().prepare('SELECT * FROM produits WHERE id = ?').get(id)
    } catch (err) {
      console.error('[produits:get]', err)
      throw err
    }
  })

  ipcMain.handle('produits:create', (_, data: Record<string, unknown>) => {
    console.log('[produits:create] data:', JSON.stringify(data))
    try {
      const db = getDB()
      const result = db.prepare(`
        INSERT INTO produits (reference, designation, categorie, unite_calcul, prix_ht, taux_tva, notes, actif)
        VALUES (@reference, @designation, @categorie, @unite_calcul, @prix_ht, @taux_tva, @notes, @actif)
      `).run({
        reference: data.reference ?? null,
        designation: data.designation ?? '',
        categorie: data.categorie ?? 'baguettes',
        unite_calcul: data.unite_calcul ?? 'metre_lineaire',
        prix_ht: data.prix_ht ?? 0,
        taux_tva: data.taux_tva ?? 20.0,
        notes: data.notes ?? null,
        actif: data.actif ?? 1
      })
      const created = db.prepare('SELECT * FROM produits WHERE id = ?').get(result.lastInsertRowid)
      console.log('[produits:create] created:', created)
      return created
    } catch (err) {
      console.error('[produits:create] ERROR:', err)
      throw err
    }
  })

  ipcMain.handle('produits:update', (_, id: number, data: Record<string, unknown>) => {
    console.log('[produits:update] id:', id, 'data:', JSON.stringify(data))
    try {
      const db = getDB()
      db.prepare(`
        UPDATE produits SET
          reference = @reference, designation = @designation,
          categorie = @categorie, unite_calcul = @unite_calcul,
          prix_ht = @prix_ht, taux_tva = @taux_tva, notes = @notes,
          actif = @actif
        WHERE id = @id
      `).run({
        reference: data.reference ?? null,
        designation: data.designation ?? '',
        categorie: data.categorie ?? 'baguettes',
        unite_calcul: data.unite_calcul ?? 'metre_lineaire',
        prix_ht: data.prix_ht ?? 0,
        taux_tva: data.taux_tva ?? 20.0,
        notes: data.notes ?? null,
        actif: data.actif ?? 1,
        id
      })
      return db.prepare('SELECT * FROM produits WHERE id = ?').get(id)
    } catch (err) {
      console.error('[produits:update] ERROR:', err)
      throw err
    }
  })

  ipcMain.handle('produits:delete', (_, id: number) => {
    try {
      getDB().prepare('DELETE FROM produits WHERE id = ?').run(id)
      return { success: true }
    } catch (err) {
      console.error('[produits:delete]', err)
      throw err
    }
  })

  ipcMain.handle('produits:toggleActif', (_, id: number) => {
    try {
      const db = getDB()
      db.prepare('UPDATE produits SET actif = CASE WHEN actif = 1 THEN 0 ELSE 1 END WHERE id = ?').run(id)
      return db.prepare('SELECT * FROM produits WHERE id = ?').get(id)
    } catch (err) {
      console.error('[produits:toggleActif]', err)
      throw err
    }
  })
}
