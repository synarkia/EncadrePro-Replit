import { ipcMain } from 'electron'
import { getDB } from '../db'

export function registerDashboardHandlers(): void {
  ipcMain.handle('dashboard:getStats', () => {
    const db = getDB()
    try {
      const now = new Date()
      const firstOfMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`

      const caMois = (db.prepare(`
        SELECT COALESCE(SUM(total_ttc), 0) as total FROM factures
        WHERE date_creation >= ? AND statut NOT IN ('brouillon', 'annulee')
      `).get(firstOfMonth) as { total: number }).total

      const devisEnAttente = db.prepare(`
        SELECT COUNT(*) as n, COALESCE(SUM(total_ttc), 0) as montant
        FROM devis WHERE statut IN ('envoye', 'brouillon')
      `).get() as { n: number; montant: number }

      const facturesImpayees = db.prepare(`
        SELECT COUNT(*) as n, COALESCE(SUM(solde_restant), 0) as montant
        FROM factures WHERE statut IN ('envoyee', 'partiellement_payee')
      `).get() as { n: number; montant: number }

      const nouveauxClients = (db.prepare(`
        SELECT COUNT(*) as n FROM clients WHERE cree_le >= ?
      `).get(firstOfMonth) as { n: number }).n

      const res = { caMois, devisEnAttente, facturesImpayees, nouveauxClients }
      console.log('[Main] Returning dashboard:getStats:', res)
      return res
    } catch (err) {
      console.error('[dashboard:getStats]', err)
      return {
        caMois: 0,
        devisEnAttente: { n: 0, montant: 0 },
        facturesImpayees: { n: 0, montant: 0 },
        nouveauxClients: 0
      }
    }
  })

  ipcMain.handle('dashboard:getCAMensuel', () => {
    console.log('[Main] Received dashboard:getCAMensuel request')
    const db = getDB()
    try {
      // Last 12 months of CA
      const rows = db.prepare(`
        SELECT strftime('%Y-%m', date_creation) as mois, COALESCE(SUM(total_ttc), 0) as total
        FROM factures
        WHERE statut NOT IN ('brouillon', 'annulee')
          AND date_creation >= date('now', '-12 months')
        GROUP BY mois
        ORDER BY mois ASC
      `).all()
      return rows
    } catch (err) {
      console.error('[dashboard:getCAMensuel]', err)
      return []
    }
  })

  ipcMain.handle('dashboard:getRecentDevis', () => {
    const db = getDB()
    try {
      return db.prepare(`
        SELECT d.id, d.numero, d.statut, d.total_ttc, d.cree_le,
               c.nom as client_nom, c.prenom as client_prenom
        FROM devis d
        LEFT JOIN clients c ON c.id = d.client_id
        ORDER BY d.cree_le DESC LIMIT 5
      `).all()
    } catch (err) {
      console.error('[dashboard:getRecentDevis]', err)
      return []
    }
  })

  ipcMain.handle('dashboard:getRecentFactures', () => {
    const db = getDB()
    try {
      return db.prepare(`
        SELECT f.id, f.numero, f.statut, f.total_ttc, f.cree_le,
               c.nom as client_nom, c.prenom as client_prenom
        FROM factures f
        LEFT JOIN clients c ON c.id = f.client_id
        ORDER BY f.cree_le DESC LIMIT 5
      `).all()
    } catch (err) {
      console.error('[dashboard:getRecentFactures]', err)
      return []
    }
  })
}
