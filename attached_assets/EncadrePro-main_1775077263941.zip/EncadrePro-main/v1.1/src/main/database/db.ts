import { app } from 'electron'
import { join } from 'path'
import { existsSync, mkdirSync } from 'fs'
import { createRequire } from 'module'
import type DatabaseType from 'better-sqlite3'

// Hide the require string from Rollup so it doesn't aggressively bundle the native module
const dynamicRequire = createRequire(import.meta.url)
const dbModuleName = 'better-sqlite3'
const Database = dynamicRequire(dbModuleName)

export let db: DatabaseType.Database

export function getDB(): DatabaseType.Database {
  if (!db) throw new Error('Database not initialized')
  return db
}

export function initDatabase(): void {
  const userDataPath = app.getPath('userData')
  const dbDir = join(userDataPath, 'EncadrePro')
  if (!existsSync(dbDir)) mkdirSync(dbDir, { recursive: true })

  const dbPath = join(dbDir, 'encadrepro.db')
  db = new Database(dbPath)
  db.pragma('journal_mode = WAL')
  db.pragma('foreign_keys = ON')

  createTables()
  seedDefaultData()
}

function createTables(): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS atelier (
      id INTEGER PRIMARY KEY DEFAULT 1,
      nom TEXT NOT NULL DEFAULT 'Mon Atelier',
      siret TEXT,
      adresse TEXT,
      telephone TEXT,
      email TEXT,
      logo_path TEXT,
      conditions_generales TEXT DEFAULT 'Devis valable 30 jours. Acompte de 30% à la commande.',
      prefixe_devis TEXT DEFAULT 'DEV',
      prefixe_facture TEXT DEFAULT 'FAC',
      compteur_devis INTEGER DEFAULT 0,
      compteur_facture INTEGER DEFAULT 0,
      tva_defaut REAL DEFAULT 20.0,
      email_template TEXT,
      smtp_host TEXT,
      smtp_port INTEGER DEFAULT 587,
      smtp_user TEXT,
      smtp_pass TEXT,
      rib TEXT
    );

    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nom TEXT NOT NULL,
      prenom TEXT,
      email TEXT,
      telephone TEXT,
      adresse TEXT,
      ville TEXT,
      code_postal TEXT,
      notes TEXT,
      cree_le DATETIME DEFAULT CURRENT_TIMESTAMP,
      modifie_le DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS produits (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      reference TEXT UNIQUE,
      designation TEXT NOT NULL,
      categorie TEXT NOT NULL,
      unite_calcul TEXT NOT NULL,
      prix_ht REAL NOT NULL,
      taux_tva REAL DEFAULT 20.0,
      actif INTEGER DEFAULT 1,
      notes TEXT,
      cree_le DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS devis (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero TEXT UNIQUE NOT NULL,
      client_id INTEGER NOT NULL,
      date_creation DATE DEFAULT CURRENT_DATE,
      date_validite DATE,
      statut TEXT DEFAULT 'brouillon',
      sous_total_ht REAL DEFAULT 0,
      total_tva_10 REAL DEFAULT 0,
      total_tva_20 REAL DEFAULT 0,
      total_ttc REAL DEFAULT 0,
      notes TEXT,
      conditions TEXT,
      facture_id INTEGER,
      cree_le DATETIME DEFAULT CURRENT_TIMESTAMP,
      modifie_le DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (client_id) REFERENCES clients(id)
    );

    CREATE TABLE IF NOT EXISTS lignes_devis (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      devis_id INTEGER NOT NULL,
      produit_id INTEGER,
      designation TEXT NOT NULL,
      unite_calcul TEXT NOT NULL,
      largeur_m REAL,
      hauteur_m REAL,
      quantite REAL DEFAULT 1,
      quantite_calculee REAL,
      prix_unitaire_ht REAL NOT NULL,
      taux_tva REAL NOT NULL,
      total_ht REAL NOT NULL,
      total_ttc REAL NOT NULL,
      ordre INTEGER DEFAULT 0,
      FOREIGN KEY (devis_id) REFERENCES devis(id) ON DELETE CASCADE,
      FOREIGN KEY (produit_id) REFERENCES produits(id)
    );

    CREATE TABLE IF NOT EXISTS factures (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      numero TEXT UNIQUE NOT NULL,
      devis_id INTEGER,
      client_id INTEGER NOT NULL,
      date_creation DATE DEFAULT CURRENT_DATE,
      date_echeance DATE,
      statut TEXT DEFAULT 'brouillon',
      sous_total_ht REAL DEFAULT 0,
      total_tva_10 REAL DEFAULT 0,
      total_tva_20 REAL DEFAULT 0,
      total_ttc REAL DEFAULT 0,
      total_paye REAL DEFAULT 0,
      solde_restant REAL DEFAULT 0,
      notes TEXT,
      conditions TEXT,
      cree_le DATETIME DEFAULT CURRENT_TIMESTAMP,
      modifie_le DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (devis_id) REFERENCES devis(id),
      FOREIGN KEY (client_id) REFERENCES clients(id)
    );

    CREATE TABLE IF NOT EXISTS lignes_facture (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      facture_id INTEGER NOT NULL,
      produit_id INTEGER,
      designation TEXT NOT NULL,
      unite_calcul TEXT NOT NULL,
      largeur_m REAL,
      hauteur_m REAL,
      quantite REAL DEFAULT 1,
      quantite_calculee REAL,
      prix_unitaire_ht REAL NOT NULL,
      taux_tva REAL NOT NULL,
      total_ht REAL NOT NULL,
      total_ttc REAL NOT NULL,
      ordre INTEGER DEFAULT 0,
      FOREIGN KEY (facture_id) REFERENCES factures(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS acomptes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      facture_id INTEGER NOT NULL,
      numero_facture_acompte TEXT UNIQUE,
      montant REAL NOT NULL,
      date_paiement DATE NOT NULL,
      mode_paiement TEXT,
      notes TEXT,
      cree_le DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (facture_id) REFERENCES factures(id)
    );
  `)
}

function seedDefaultData(): void {
  // Insert default atelier row if missing
  const atelierExists = db.prepare('SELECT id FROM atelier WHERE id = 1').get()
  if (!atelierExists) {
    db.prepare(`INSERT INTO atelier (id, nom) VALUES (1, 'Mon Atelier')`).run()
  }

  // Seed sample products if empty
  const prodCount = (db.prepare('SELECT COUNT(*) as n FROM produits').get() as { n: number }).n
  if (prodCount === 0) {
    const insert = db.prepare(`
      INSERT INTO produits (reference, designation, categorie, unite_calcul, prix_ht, taux_tva)
      VALUES (?, ?, ?, ?, ?, ?)
    `)
    const prods = [
      ['BAG-DORE-22', 'Baguette dorée classique 22mm', 'baguettes', 'metre_lineaire', 3.80, 20.0],
      ['BAG-NOIR-30', 'Baguette noire mate 30mm', 'baguettes', 'metre_lineaire', 4.20, 20.0],
      ['BAG-CHENE', 'Baguette chêne naturel 40mm', 'baguettes', 'metre_lineaire', 5.50, 20.0],
      ['VER-ANTI-REF', 'Verre anti-reflets', 'verres', 'metre_carre', 28.00, 20.0],
      ['VER-STAND', 'Verre standard clair', 'verres', 'metre_carre', 12.00, 20.0],
      ['PP-BLANC', 'Passe-partout blanc', 'passe_partout', 'metre_carre', 15.00, 20.0],
      ['PP-CREME', 'Passe-partout crème', 'passe_partout', 'metre_carre', 16.50, 20.0],
      ['QUI-CRO', 'Crochet + fil', 'quincaillerie', 'unitaire', 1.50, 20.0],
      ['MO-ENCAD', 'Main d\'œuvre encadrement', 'main_oeuvre', 'heure', 45.00, 10.0],
      ['MO-ASSEM', 'Assemblage et finitions', 'main_oeuvre', 'heure', 40.00, 10.0],
    ]
    prods.forEach(p => insert.run(...p))
  }

  // Seed sample client if empty
  const clientCount = (db.prepare('SELECT COUNT(*) as n FROM clients').get() as { n: number }).n
  if (clientCount === 0) {
    db.prepare(`INSERT INTO clients (nom, prenom, email, ville) VALUES (?, ?, ?, ?)`).run('Garnier', 'Jean', 'jean.garnier@example.com', 'Paris')
    const clientId = (db.prepare('SELECT last_insert_rowid() as id').get() as { id: number }).id

    // Seed sample devis
    db.prepare(`INSERT INTO devis (numero, client_id, statut, total_ttc, date_creation) VALUES (?, ?, ?, ?, ?)`).run('DEV-2024-001', clientId, 'envoye', 245.50, '2024-03-15')
    
    // Seed sample facture for current month stats
    const now = new Date()
    const currentMonthDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-05`
    db.prepare(`INSERT INTO factures (numero, client_id, statut, total_ttc, solde_restant, date_creation) VALUES (?, ?, ?, ?, ?, ?)`).run('FAC-2024-001', clientId, 'envoyee', 1250.00, 1250.00, currentMonthDate)
  }
}
